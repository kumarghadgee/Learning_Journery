package com.demo.inventory.service;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.demo.inventory.custom_exceptions.ResourceNotFoundException;
import com.demo.inventory.dto.ApiResponse;
import com.demo.inventory.dto.InventoryResponse;
import com.demo.inventory.dto.StockRequest;
import com.demo.inventory.entity.InventoryItem;
import com.demo.inventory.repository.InventoryRepository;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@Transactional(readOnly = true)
@RequiredArgsConstructor
@Slf4j
public class InventoryServiceImpl {

	private final InventoryRepository inventoryRepository;
	private final ModelMapper mapper;

	/**
	 * Check if a single SKU is in stock with at least the requested quantity.
	 * 
	 */
	public InventoryResponse checkStock(String skuCode, int requestedQty) {
		log.info("Checking stock for SKU: {} | Requested: {}", skuCode, requestedQty);	
		return map(skuCode,requestedQty);
	}

	/**
	 * Bulk stock check — more efficient when an order has multiple line items.
	 * Returns one InventoryResponse per SKU.
	 */
	public List<InventoryResponse> checkStockBulk(List<String> skuCodes) {
		log.info("Bulk stock check for SKUs: {}", skuCodes);

		List<InventoryItem> items = inventoryRepository.findBySkuCodeIn(skuCodes);

		return items.stream().map(item -> map(item.getSkuCode(), 0)).collect(Collectors.toList());
	}

	/**
	 * Reduce stock when an order is confirmed. In a real system this would be in a
	 * distributed transaction / saga.
	 */
	@Transactional
	public ApiResponse deductStock(StockRequest request) {
		String skuCode=request.getSkuCode();
		int qty=request.getQuantity();
		InventoryItem item = inventoryRepository.findBySkuCode(skuCode)
				.orElseThrow(() -> new ResourceNotFoundException("SKU not found: " + skuCode));

		if (item.getQuantity() < qty) {
			throw new RuntimeException("Insufficient stock for SKU: " + skuCode);
		}

		item.setQuantity(item.getQuantity() - qty);		
		log.info("Deducted {} units from SKU {}. Remaining: {}", qty, skuCode, item.getQuantity());
		return new ApiResponse("Deducted stock - SkuCode"+skuCode, "Success");
	}

	private InventoryResponse map(String skuCode, int requestedQty) {
		InventoryItem inventoryItem = inventoryRepository.findBySkuCode(skuCode)
				.orElseThrow(() -> new ResourceNotFoundException("SKU not found: " + skuCode));
		InventoryResponse response = mapper.map(inventoryItem, InventoryResponse.class);
		if (inventoryItem.getQuantity() >= requestedQty)
			response.setInStock(true);
		return response;
	}
}
