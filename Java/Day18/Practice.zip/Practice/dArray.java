class d
{
    public void dArr()
    {
        int[][] a = {
            {1 , 2},
            {3 , 4}
        };

        int[][] b = {
            {5 , 6},
            {7 , 8}
        };

        int rows = a.length;
        int cols = a.length;

        int[][] result = new int[rows][cols];

        for(int i = 0 ; i < rows; i++)
        {
            for(int j = 0 ; j < cols; j++)
            {
                result[i][j] = a[i][j] + b[i][j];
            }
        }

        System.out.println("Resultant matrix after addition : ");
        for(int i = 0 ; i < rows ; i++)
        {
            for(int j = 0 ; j < cols ; j++)
            {
                System.out.println(result[i][j]);
            }
            System.out.println();
        }

    }
}

public class dArray {
    public static void main(String[] args)
    {
        d d = new d();
        d.dArr();
    }
}
