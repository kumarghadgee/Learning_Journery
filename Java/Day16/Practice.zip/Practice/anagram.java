import java.util.Scanner;

class anagra
{
    Scanner sc = new Scanner(System.in);
    public void anagram()
    {
        System.out.print("Please Enter the First Word : ");
        String s = sc.next().toLowerCase();

        System.out.print("Please Enter the Second Word : ");
        String t = sc.next().toLowerCase();

        if(s.length() != t.length())
        {
            System.out.println("Is not Anagram...");
            return;
        }

        int[] charCounts = new int[26];

        for(int i = 0 ; i < s.length() ; i++)
        {
            charCounts[s.charAt(i) - 'a']++;
            charCounts[t.charAt(i) - 'a']--;
        }

        for(int count : charCounts)
        {
            if(count != 0)
            {
                System.out.println("Is not Anagram....");
                return;
            }
            
        }
        System.out.println("IS ANAGRAM.....");

        sc.close();
    }
}

public class anagram {
    public static void main(String[] args) {
        anagra a = new anagra();
        a.anagram();
    }
}
