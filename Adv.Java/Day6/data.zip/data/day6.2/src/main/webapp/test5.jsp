<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<%@ taglib uri="jakarta.tags.core" prefix="c"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
	<%-- Iterate over the product list  --%>
	<table style="background-color: lightgrey; margin: auto">
		<caption>Product List</caption>
		<tr>
			<th>Product ID</th>
			<th>Product Name</th>
			<th>Product Price</th>
		</tr>
		<c:forEach var="p" items="${sessionScope.product_list}">
		<tr>
			<td>${p.id}</td>
			<td>${p.name}</td>			
			<td>${p.price}</td>
		</tr>
		</c:forEach>
	</table>
	
</body>
</html>