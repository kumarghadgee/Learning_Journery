package com.product.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.product.entities.Product;
import com.product.utilis.DButilis;

public class ProductDaoImpl implements ProductDao{
	private Connection connection;
	private PreparedStatement pst1;
	
	public ProductDaoImpl() throws SQLException{
		connection=DButilis.getConnection();
		pst1=connection.prepareStatement("SELECT * FROM products WHERE category_id=?");
	}
	
	public void cleanUp() throws SQLException{
		if(pst1 != null) {
			pst1.close();
		}
		
		if(connection != null) {
			connection.close();
		}
		
		System.out.println("ProductDao is Closed");
	}
	
	public List<Product> getProductsByCategory(long categoryId){
		List<Product> productList = new ArrayList<>();
		
		try {
			
			pst1.setLong(1,categoryId);
			
			ResultSet rs = pst1.executeQuery();
			
			while (rs.next()) {
				
				Product product = new Product();
				
				product.setProductId(rs.getLong("product_id"));
				product.setProductName(rs.getString("product_name"));
				product.setPrice(rs.getDouble("price"));
				product.setStock(rs.getInt("stock"));
				product.setCategoryId(rs.getInt("category_id"));
				
				productList.add(product);
				
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}		
		return productList;
	}
}
