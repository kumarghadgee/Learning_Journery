package com.backend.dtos;

import com.backend.entities.CompanyEntity;
import com.backend.entities.JobType;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class JobDTO {
	private String title;
	private String description;
	private double salary;
	private String location;
	private JobType jobType; 
	private Long companyId;
}
