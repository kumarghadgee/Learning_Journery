# Ollama ChatBot

import os
from dotenv import load_dotenv

load_dotenv()
# qroq model
# from langchain_groq import ChatGroq
# GROQ_API_KEY = os.getenv("GROQ_API_KEY")
# llm = ChatGroq(model="llama-3.1-8b-instant", api_key=GROQ_API_KEY)

# ollama model
# from langchain_ollama import ChatOllama
# llm = ChatOllama(model="llama3.2")

# any model -- langchain v1
from langchain.chat_models import init_chat_model
MODEL="groq:llama-3.1-8b-instant" # "ollama:llama3.2"
API_KEY=os.getenv("GROQ_API_KEY") # "not-required"
llm = init_chat_model(model=MODEL, api_key=API_KEY)

while True:
    user_prompt = input("Ask anything: ")
    if user_prompt == "exit":
        break
    # response = llm.invoke(input=[
    #     {"role": "user", "content": user_prompt}
    # ])
    # print("Answer:", response.content)
    response = llm.stream(input=[
        {"role": "user", "content": user_prompt}
    ])
    print("Answer: ")
    for chunk in response:
        print(chunk.content, end="")
    print("\n")
