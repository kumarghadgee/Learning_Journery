import os

from dotenv import load_dotenv
from langchain.chat_models import init_chat_model
from langchain.agents import create_agent
from langchain.agents.middleware import HumanInTheLoopMiddleware
from langchain.tools import tool
from langgraph.checkpoint.memory import InMemorySaver
from langgraph.types import Command
import json
from typing import Optional, Literal
from pydantic import BaseModel, Field

load_dotenv()

if not os.getenv("GROQ_API_KEY"):
    raise ValueError("GROQ_API_KEY not found.")

checkpointer = InMemorySaver()

ORDERS = {
    "1001": {
        "customer": "Alice",
        "status": "Shipped"
    },
    "1002": {
        "customer": "Bob",
        "status": "Processing"
    }
}


@tool
def lookup_order(order_id: str) -> str:
    """Look up an order by its ID."""

    order = ORDERS.get(order_id)

    if order is None:
        return "Order not found."

    return (
        f"Customer: {order['customer']}\n"
        f"Status: {order['status']}"
    )


@tool
def send_email(
    recipient: str,
    subject: str,
    body: str
) -> str:
    """Send an email."""

    print("\n=== EMAIL ===")
    print(f"To: {recipient}")
    print(f"Subject: {subject}")
    print(body)
    print("=============\n")

    return "Email sent."

# Guard model
guard = init_chat_model(
    "groq:meta-llama/Llama-Prompt-Guard-2-22M"
)

def is_safe(text: str) -> bool:
    result = guard.invoke(text)
    unsafe_prompt = float(result.content)
    # Replace with the model's actual output format
    return unsafe_prompt > 0.6

def validate_user_prompt(prompt: str) -> None:
    if is_safe(prompt):
        raise ValueError(
            "Prompt injection detected."
        )

middleware = [
    HumanInTheLoopMiddleware(
        interrupt_on={
            "send_email": True
        }
    )
]

class SupportResponse(BaseModel):
    intent: Literal[
        "order_status",
        "order_details",
        "email_sent"
    ] = Field(description="What the assistant completed.")

    message: str = Field(
        description="Natural language response for the user."
    )

    order_id: Optional[int] = None
    customer: Optional[str] = None
    status: Optional[str] = None

    email_sent: bool = False
    recipient: Optional[str] = None

llm = init_chat_model("groq:openai/gpt-oss-20b")

agent = create_agent(
    model=llm,
    tools=[
        lookup_order,
        send_email
    ],
    system_prompt="You are a helpful customer support assistant.",
    middleware=middleware,
    checkpointer=checkpointer,
    # response_format=SupportResponse # supported by OpenAI "with tools", but not by Groq models.
)

struct_llm = llm.with_structured_output(SupportResponse)

while True:
    try:
        question = input("\nHow can I help you: ")
        if question == "exit":
            break
        validate_user_prompt(question)
        config={
                "configurable": {
                    "thread_id": "unique-chat-id"
                }
            }
        response = agent.invoke(
            {
                "messages": [
                    {
                        "role": "user",
                        "content": question
                    }
                ]
            },
            config=config
        )
        # print("Full Response: ", response)
        
        # Check for interrupt
        if "__interrupt__" in response:
            interrupt = response["__interrupt__"][0]
            interrupt_action = interrupt.value["action_requests"][0]
            print(f"\nThe {interrupt_action['name']} waiting for your approval: ")
            for key, value in interrupt_action["args"].items():
                print(key, ": ", value)
            answer = input("\nDo you approve (y) or reject(n): ")
            decision = "approve" if answer.lower() == "y" else "reject"
            response = agent.invoke(
                            Command(resume={
                                "decisions": [ 
                                    { "type": decision }
                                ]
                            }),
                            config=config
                        )
        
        resp: SupportResponse = struct_llm.invoke(
            f"""
            Convert the following customer support response into the SupportResponse schema.
            {response["messages"][-1].content}
            """
        )
        # You can display individual fields like resp.intent, resp.message, ...
        print("Final Answer:\n", resp.model_dump_json(indent=2), "\n")
    except Exception as e:
        print("ERROR:\n", e)