import java.util.Stack;

class paren
{
    public void check()
    {
        String s = "(,{,),{,},[,},]";

        Stack<Character> stack = new Stack<>();

        for(int i = 0 ; i < s.length() ; i++)
        {
            char c = s.charAt(i);

            if(c == '(' || c == '{' || c == '['){
                stack.push(c);
            }

            else{
                if(stack.isEmpty())
                {
                    System.out.println("False");
                    return;
                }

                char top = stack.pop();

                if(c == ')' && top != '(') 
                {
                    System.out.println("False"); 
                    return;
                }    
                if(c == '}' && top != '{') 
                {
                    System.out.println("False"); 
                    return;
                }
                if(c == ']' && top != '[') 
                {
                    System.out.println("False"); 
                    return;
                }
            }
        }
        if(stack.isEmpty())
        {
            System.out.println("True");
        }
        else{
            System.out.println("False");
        }
        
    }
}

public class valid{
    public static void main(String[] args) {
        paren p = new paren();
        p.check();
    }
}