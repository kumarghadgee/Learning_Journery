package com.healthcare.service;

import java.util.List;

import com.healthcare.dtos.ApiResponse;
import com.healthcare.dtos.PatientRegDTO;
import com.healthcare.dtos.PatientResp;

public interface PatientService {
//add a method to get patient's specific details
	PatientResp getPatientDetails(Long patientId);

	List<PatientResp> getAllPatients();

	// method to sign up
	ApiResponse registerNewPatient(PatientRegDTO reqDTO);
}
