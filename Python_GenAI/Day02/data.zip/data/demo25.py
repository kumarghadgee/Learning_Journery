
import streamlit as st

# check if the data is already present in session state.
# if not initialize it with some default value
if "conversation" not in st.session_state:
    st.session_state.conversation = list()
if "curoption" not in st.session_state:
    st.session_state.curoption = "Upper"

options = ["Upper", "Lower", "Capitalize", "SwapCase"]

st.title("Sunbeam Fake Chatbot")
with st.sidebar:
    st.header("Settings")
    st.session_state.curoption = st.selectbox("Choose One:", options, 0)
    if st.session_state.curoption:
        st.write(f"You selected: {st.session_state.curoption}")

user_text = st.chat_input("Enter text...")
if user_text:
    ai_text = ""
    if st.session_state.curoption == "Upper":
        ai_text = user_text.upper()
    elif st.session_state.curoption == "Lower":
        ai_text = user_text.lower()
    elif st.session_state.curoption == "Capitalize":
        ai_text = user_text.capitalize()
    elif st.session_state.curoption == "SwapCase":
        ai_text = user_text.swapcase()
    else:
        ai_text = "Sorry! I can't."

    # store data into variable in the session_state
    st.session_state.conversation.append({"role": "user", "content": user_text})
    st.session_state.conversation.append({"role": "ai", "content": ai_text})

# use data from session_state variable and display
for msg in st.session_state.conversation:
    with st.chat_message(msg["role"]):
        st.write(msg["content"])
