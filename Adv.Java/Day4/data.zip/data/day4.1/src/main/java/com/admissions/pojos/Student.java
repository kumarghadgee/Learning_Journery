package com.admissions.pojos;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
public class Student {
	private String firstName;
	private String lastName;
	private Course selectedCourse;
	private int marks;
	private boolean admitted;
}
