import java.util.Scanner;

class automorphic
{
    Scanner sc = new Scanner(System.in);
    public void auto()
    {
        System.out.print("Enter the number checking whether it is Automorphic : ");
        int n = sc.nextInt();

        int m = n * n;
        int rem = m % 10;

        if(rem == n){
            System.out.println("Number is Automorphic");
        }
        else
        {
            System.out.println("Number is Not Automorphic");
        }
    }
}

public class demo04 {
    public static void main(String[] args) {
        automorphic at = new automorphic();
        at.auto();
    }
}
