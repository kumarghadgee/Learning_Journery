package com.healthcare.dao;

import java.time.LocalDate;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.healthcare.dtos.UserDTO;
import com.healthcare.entities.User;
import com.healthcare.entities.UserRole;
import com.healthcare.utils.HibernateUtils;

public class UserDaoImpl implements UserDao {

	@Override
	public String registerUser(User newUser) {
		// newUser - TRANSIENT (exists ONLY in heap)
		String message = "User reg failed !!!!!";
		// 1. Get Session from SessionFactory
		Session session = HibernateUtils.getSessionFactory().getCurrentSession();
		// 2. Begin Transacion
		Transaction tx = session.beginTransaction();
		try {
			session.persist(newUser);
			// newUser - PERSISTENT (exists in L1 cache , no rec inserted )
			tx.commit();// DML - insert
			message = "registered new user with ID" + newUser.getId();
		} catch (RuntimeException e) {
			// roll back Tx
			if (tx != null) {
				tx.rollback();
			}
			// re throw same exception to the caller
			throw e;
		}
		// newUser - DETACHED (from L1 cache , exists in DB)
		return message;
	}

	@Override
	public User getUserDetailsById(Long userId) {
		User user = null;// user - does not exist in heap
		// 1. Get Session from SessionFactory
		Session session = HibernateUtils.getSessionFactory().getCurrentSession();
		Session session2 = HibernateUtils.getSessionFactory().getCurrentSession();
		System.out.println(session == session2);// t

		// 2. Begin a Tx
		Transaction tx = session.beginTransaction();
		System.out.println("is connected " + session.isConnected());
		try {
			// valid user id
			user = session.find(User.class, userId);// select
			// user - PERSISTENT (exists in L1 & DB)
			user = session.find(User.class, userId);
			user = session.find(User.class, userId);
			user = session.find(User.class, userId);
			tx.commit();
			System.out.println("after commit - is connected " + session.isConnected());// f
		} catch (RuntimeException e) {
			// rollback tx
			if (tx != null) {
				tx.rollback();
				System.out.println("after rollback -is connected " + session.isConnected());// f
			}
			// re throw the same exception to the caller - to inform
			throw e;
		}
		return user;
	}

	@Override
	public List<User> getAllUsers() {
		List<User> users = null;
		String jpql = "select u from User u";
		// 1. Get Session from SessionFactory
		Session session = HibernateUtils.getSessionFactory().getCurrentSession();
		// 2. Begin a Tx
		Transaction tx = session.beginTransaction();
		try {
			users = session.createQuery(jpql, User.class).getResultList();// select -> RST -> iterates -> RST ->
																			// List<User>
			// users - List of PERSISTENT entities
			tx.commit();
		} catch (RuntimeException e) {
			// rollback tx
			if (tx != null) {
				tx.rollback();
			}
			// re throw the same exception to the caller - to inform
			throw e;
		}
		return users;// users - List of DETACHED entities
	}

	@Override
	public List<User> getUserDetailsByRoleAndDob(UserRole role, LocalDate date) {
		List<User> users = null;
		String jpql = "select u from User u where u.userRole=:rl and u.dob > :dt";
		// 1. Get Session from SessionFactory
		Session session = HibernateUtils.getSessionFactory().getCurrentSession();
		// 2. Begin a Tx
		Transaction tx = session.beginTransaction();
		try {
			users = session.createQuery(jpql, User.class).setParameter("rl", role).setParameter("dt", date)
					.getResultList();
			tx.commit();
		} catch (RuntimeException e) {
			// rollback tx
			if (tx != null) {
				tx.rollback();
			}
			// re throw the same exception to the caller - to inform
			throw e;
		}
		return users;
	}

	@Override
	public User signIn(String email1, String password1) {
		User user = null;
		String jpql = "select u from User u where u.email=:em and u.password=:pass";
		// 1. Get Session from SessionFactory
		Session session = HibernateUtils.getSessionFactory().getCurrentSession();
		// 2. Begin a Tx
		Transaction tx = session.beginTransaction();
		try {
			user = session.createQuery(jpql, User.class).setParameter("em", email1).setParameter("pass", password1)
					.getSingleResult();
			// in case of valid credentials ->user : PERSISTENT
			// throws NoResultException
			user.setRegAmount(user.getRegAmount() + 100);
			user.setPassword("22345");
			// un comment line below to understand Detached vs Persistent
			// session.evict(user);//user - DETACHED
			tx.commit();// session.flush() -> auto dirty checking -> DML - update -> session.close() ->
						// db cn rets to DBCP, L1 cache is destroyed , session : GC
		} catch (RuntimeException e) {
			// rollback tx
			if (tx != null) {
				tx.rollback();
			}
			// re throw the same exception to the caller - to inform
			throw e;
		}
		// user - DETACHED
		user.setRegAmount(user.getRegAmount() + 100);
		user.setPassword("9999999999999999999");
		return user;
	}

	@Override
	public List<String> getUserLastNamesByRole(UserRole role1) {
		List<String> lastNames = null;
		String jpql = "select u.lastName from User u where u.userRole=:role";
		// 1. Get Session from SessionFactory
		Session session = HibernateUtils.getSessionFactory().getCurrentSession();
		// 2. Begin a Tx
		Transaction tx = session.beginTransaction();
		try {
			lastNames = session.createQuery(jpql, String.class).setParameter("role", role1).getResultList();
			tx.commit();
		} catch (RuntimeException e) {
			// rollback tx
			if (tx != null) {
				tx.rollback();
			}
			// re throw the same exception to the caller - to inform
			throw e;
		}
		return lastNames;
	}

	@Override
	public List<UserDTO> getSelectedUserDetailsByRole(UserRole role) {
		List<UserDTO> list = null;
		String jpql = "select new com.healthcare.dtos.UserDTO(u.firstName,u.lastName,u.dob) from User u where u.userRole=:rl";
		// 1. Get Session from SessionFactory
		Session session = HibernateUtils.getSessionFactory().getCurrentSession();
		// 2. Begin a Tx
		Transaction tx = session.beginTransaction();
		try {
			list = session.createQuery(jpql, UserDTO.class).setParameter("rl", role).getResultList();
			tx.commit();
		} catch (RuntimeException e) {
			// rollback tx
			if (tx != null) {
				tx.rollback();
			}
			// re throw the same exception to the caller - to inform
			throw e;
		}
		return list;
	}

	@Override
	public String applyDiscount(UserRole role, int discount) {
		String message = "Applying discount failed....";
		String jpql = "select u from User u where u.userRole=:rl";
		// 1. Get Session from SessionFactory
		Session session = HibernateUtils.getSessionFactory().getCurrentSession();
		// 2. Begin a Tx
		Transaction tx = session.beginTransaction();
		try {
			List<User> users = session.createQuery(jpql, User.class).setParameter("rl", role).getResultList();
			// users - List of persistent User
			users.forEach(user -> user.setRegAmount(user.getRegAmount() - discount)); // MODIFYING state of PERSISTENT
																						// entities
			tx.commit(); // session.flush() -> dirty checking -> DML -> update -> sesison.close()
			message = "applied discount successfully !";
		} catch (RuntimeException e) {
			// rollback tx
			if (tx != null) {
				tx.rollback();
			}
			// re throw the same exception to the caller - to inform
			throw e;
		}
		return message;
	}

	@Override
	public String applyBulkDiscount(UserRole role, int discount) {
		String message = "Bulk Applying discount failed....";
		String updateJpql = "update User u set u.regAmount=u.regAmount-:disc where u.userRole=:rl";
		// 1. Get Session from SessionFactory
		Session session = HibernateUtils.getSessionFactory().getCurrentSession();
		// 2. Begin a Tx
		Transaction tx = session.beginTransaction();
		try {
			int rowCount = session.createMutationQuery(updateJpql).setParameter("disc", discount)
					.setParameter("rl", role).executeUpdate();
			tx.commit();
			message = "Applied discount to " + rowCount + " no of users ....";
		} catch (RuntimeException e) {
			// rollback tx
			if (tx != null) {
				tx.rollback();
			}
			// re throw the same exception to the caller - to inform
			throw e;
		}
		return message;
	}

	@Override
	public String deleteUserDetailsById(Long userId) {
		User user=null;
		String message="Deletion failed!!!!!";
		// 1. Get Session from SessionFactory
		Session session = HibernateUtils.getSessionFactory().getCurrentSession();
		// 2. Begin a Tx
		Transaction tx = session.beginTransaction();
		try {
//3. get user details by id
			user=session.find(User.class, userId);
			//4. null checking
			if(user != null)
			{
				//user - PERSISTENT
				session.remove(user); //user - REMOVED (simply marked for removal - exists in L1 & DB)
				message="Deletion success";
			}		
			tx.commit();//sesison.flush-> auto dirty checking -> DML - delete -> session.close-> L1 cache destroyed , db cn rets to DBCP
		} catch (RuntimeException e) {
			// rollback tx
			if (tx != null) {
				tx.rollback();
			}
			// re throw the same exception to the caller - to inform
			throw e;
		}
		//user - TRANSIENT
		return message;
	}
	//user - GC -> does not exist in heap !

}
