
# Python OOP -- class & object

# empty class
class Person:
    pass

# object of Person class
p1 = Person()
print("p1 type:", type(p1))
print("p1:", p1)
print("-" * 60)

class Student:
    # initializer method
    def __init__(self, roll=0, name="Anonymous", marks=0.0):
        self.roll = roll
        self.name = name
        self.marks = marks
    
    # string reprenetation method
    def __str__(self):
        return f"Roll: {self.roll}, Name: {self.name}, Marks: {self.marks}"

    def get_class(self):
        if self.marks >= 75:
            return "distinction"
        elif self.marks >= 60:
            return "first class"
        elif self.marks >= 50:
            return "second class"
        else:
            return "failed"


s1 = Student()
print("s1 =", s1)
print("s1 class =", s1.get_class())
s2 = Student(120, "John Galt", 98.9)
print("s2 =", s2)
print("s2 class =", s2.get_class())
print("s2 name =", s2.name)
# default access modifier of all fields is public.
# so fields can be accessed/modified within class as well as outside class -- obj.fieldname
s3 = Student()
s3.name = "James Bond"
s3.marks = 76
print("s3 =", s3)
print("-" * 60)

class Employee:
    def __init__(self, id=0, name="", salary=0.0):
        self.__id = id
        self.__name = name
        self.__salary = salary

    def set_salary(self, salary):
        if salary < 0:
            raise Exception("invalid salary") # throw exception
        self.__salary = salary

    def get_salary(self):
        return self.__salary

    def display(self):
        print(f"Id={self.__id}\nName={self.__name}\nSalary={self.__salary}")

e1 = Employee(1, "Sarang", 87000.0)
e1.display()
# "private" fields are prefixed with __. Such members cannot be called from outside class
# print("e1 Name:", e1.__name) # AttributeError: 'Employee' object has no attribute '__name'
# e1.set_salary(-30000.0) # throw exception
print("e1 Salary:", e1.get_salary())
