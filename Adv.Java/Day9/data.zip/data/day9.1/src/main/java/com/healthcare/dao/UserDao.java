package com.healthcare.dao;

import java.time.LocalDate;
import java.util.List;

import com.healthcare.dtos.UserDTO;
import com.healthcare.entities.User;
import com.healthcare.entities.UserRole;

public interface UserDao {
//add new user
	String registerUser(User newUser);

	User getUserDetailsById(Long nextLong);

	List<User> getAllUsers();

	List<User> getUserDetailsByRoleAndDob(UserRole role, LocalDate date);

	User signIn(String email, String password);

	List<String> getUserLastNamesByRole(UserRole role);

	List<UserDTO> getSelectedUserDetailsByRole(UserRole role);

	String applyDiscount(UserRole role, int discount);

	String applyBulkDiscount(UserRole role, int discount);

	String deleteUserDetailsById(Long userId);
}
