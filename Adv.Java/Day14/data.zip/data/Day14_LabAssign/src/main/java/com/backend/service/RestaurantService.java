package com.backend.service;

import java.util.List;

import com.backend.entities.Restaurants;

public class RestaurantService {
	List<Restaurants> getAllRestaurant();
}
