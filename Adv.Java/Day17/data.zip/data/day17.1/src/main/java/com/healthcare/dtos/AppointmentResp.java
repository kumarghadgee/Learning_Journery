package com.healthcare.dtos;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class AppointmentResp {
	private Long id; //appointments
	//for patient dashboard - doc's name
	//for doc's dashbaord - patient's name
	private String firstName;
	private String lastName;
	private LocalDateTime appointmentDateTime;
}
