package com.healthcare.dao;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.healthcare.entities.Doctor;
import com.healthcare.utils.HibernateUtils;

public class DoctorDaoImpl implements DoctorDao {

	@Override
	public String registerDoctor(Doctor doctor) {
		String mesg = "doc reg failed !!!!";
		// 1. Get Session from SessionFactory
		Session session = HibernateUtils.getSessionFactory().getCurrentSession();
		// 2. Begin Tx
		Transaction tx = session.beginTransaction();
		try {
			session.persist(doctor);
			tx.commit();
			/*
			 * doc -> user @MapsId doc.getUserDetails -> insert a rec users table using the
			 * SAME id -> inserts a child rec docs table
			 */
			mesg = "doctor reg successful";
		} catch (RuntimeException e) {
			if (tx != null) {
				tx.rollback();
			}
			// re throw the same exception to the caller
			throw e;
		}
		return mesg;
	}

	@Override
	public String deleteDoctorDetailsById(Long doctorId) {
		String mesg = "Deletion Failed ";
		String deleteJpql = "delete from Appointment a where a.myDoctor.id=:docId";
		// 1. Get Session from SessionFactory
		Session session = HibernateUtils.getSessionFactory().getCurrentSession();
		// 2. Begin Tx
		Transaction tx = session.beginTransaction();
		try {
			// get doc details by id
			Doctor doctor = session.find(Doctor.class, doctorId);
			if (doctor != null) {
				// 3. delete all appointments for the doctor
				int rows = session.createMutationQuery(deleteJpql).setParameter("docId", doctor.getId())
						.executeUpdate();
				// doctor : persistent
				session.remove(doctor);// doctor : REMOVED
				// delete associated user details
				session.remove(doctor.getUserDetails());
				mesg = "deleted doc details along with appointments & user";
			}
			tx.commit();// delete query
		} catch (RuntimeException e) {
			if (tx != null) {
				tx.rollback();
			}
			// re throw the same exception to the caller
			throw e;
		}
		return mesg;
	}

	@Override
	public String deleteDoctorDetailsByIdWithCascade(Long doctorId) {
		String mesg = "Deletion Failed ";
		// 1. Get Session from SessionFactory
		Session session = HibernateUtils.getSessionFactory().getCurrentSession();
		// 2. Begin Tx
		Transaction tx = session.beginTransaction();
		try {
			// get doc details by id
			Doctor doctor = session.find(Doctor.class, doctorId);
			if (doctor != null) {
				// doctor : persistent
				session.remove(doctor);// doctor : REMOVED
				mesg = "deleted doc details along with appointments & user";
			}
			tx.commit();// delete query
		} catch (RuntimeException e) {
			if (tx != null) {
				tx.rollback();
			}
			// re throw the same exception to the caller
			throw e;
		}
		return mesg;
	}

	@Override
	public Doctor getDoctorDetailsById(Long doctorId) {
		Doctor doctor = null;
		// 1. Get Session from SessionFactory
		Session session = HibernateUtils.getSessionFactory().getCurrentSession();
		// 2. Begin Tx
		Transaction tx = session.beginTransaction();
		try {
			doctor = session.find(Doctor.class, doctorId);
			// access the size of the List - before closing the session
			doctor.getAppointments().size();// Hint -> hibernate to load appointments
			tx.commit();
		} catch (RuntimeException e) {
			if (tx != null) {
				tx.rollback();
			}
			// re throw the same exception to the caller
			throw e;
		}
		return doctor;// doctor - detached - session scope- over !!!!!
	}

	@Override
	public Doctor getDoctorDetailsByIdWithJoinFetch(Long doctorId) {
		Doctor doctor = null;
		String jpql = "select d from Doctor d left join fetch d.appointments where d.id=:docId";
		// 1. Get Session from SessionFactory
		Session session = HibernateUtils.getSessionFactory().getCurrentSession();
		// 2. Begin Tx
		Transaction tx = session.beginTransaction();
		try {
			doctor=session.createQuery(jpql, Doctor.class)
					.setParameter("docId",doctorId)
					.getSingleResult();
			tx.commit();
		} catch (RuntimeException e) {
			if (tx != null) {
				tx.rollback();
			}
			// re throw the same exception to the caller
			throw e;
		}
		return doctor;// doctor - detached - session scope- over !!!!!
	}

}
