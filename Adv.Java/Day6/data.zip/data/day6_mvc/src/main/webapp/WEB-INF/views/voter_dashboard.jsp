<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<%@ taglib uri="jakarta.tags.core" prefix="c"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Voter Dash Board</title>
</head>
<body>
	<c:set var="user" value="${sessionScope.user_details}" />
	<h5>Hello , ${user.firstName} ${user.lastName}</h5>
	<%-- <h5>Candidate List - ${requestScope.candidate_list}</h5> --%>
	<form action="user_logout" method="post">
		<table style="background-color: lightgrey; margin: auto">
			<c:forEach var="candidate" items="${requestScope.candidate_list}">
				<tr>
					<td><input type="radio" name="cid"
						value="${candidate.candidateId}" /></td>
					<td>${candidate.candidateName}</td>
					<td>${candidate.partyName}</td>
				</tr>
			</c:forEach>
			<tr>
				<td><input type="submit" value="Vote" /></td>
			</tr>
		</table>
	</form>
</body>
</html>