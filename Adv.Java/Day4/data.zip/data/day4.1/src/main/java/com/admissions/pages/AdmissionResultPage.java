package com.admissions.pages;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

import com.admissions.pojos.Student;

/**
 * Servlet implementation class AdmissionResultPage
 */
@WebServlet("/admission_result")
public class AdmissionResultPage extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//1. set cont type
		response.setContentType("text/html");
		//2 get writer
		try(PrintWriter pw=response.getWriter()) {
			//3. Get student details from request scoped attribute(object)
			Student s1=(Student) request.getAttribute("student_details");
			pw.print("<h5> Hello "+s1.getFirstName()+" "+s1.getLastName()+"</h5>");
			if(s1.isAdmitted())
			{
				pw.print("<h5> Congratulations !  You are admitted in the course "+s1.getSelectedCourse()+" </h5>");
			} else {
				pw.print("<h5> Sorry !  You can't be  admitted in the course "+s1.getSelectedCourse()+" </h5>");
			}
		}
	} //doPost method returns

}
