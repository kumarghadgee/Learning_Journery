package com.ems.service;

import java.util.List;

import com.ems.entities.Employee;

public interface EmployeeService {
//list all available emps by dept id
	List<Employee> getAvailableEmpsByDeptId(Long deptId);

	//Add method to soft delete(Disable status) emp details by empid
	String deleteEmpDetailsById(Long empId);
}
