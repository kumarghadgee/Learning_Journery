import pandas as pd
import pandasql as ps

file_path="products.csv"
df = pd.read_csv(file_path)
print(df)

while True:
    sql = input("\nSQL> ")
    if sql == "exit":
        break
    try:
        result_df = ps.sqldf(sql, {"products": df})
        print(result_df)
    except Exception as e:
        print("ERROR:", e)
