# Simple RAG a.k.a. RAG pipeline

import chromadb
from langchain.embeddings import init_embeddings
from langchain.chat_models import init_chat_model
import json

llm = init_chat_model(model="groq:llama-3.1-8b-instant")
embed_model = init_embeddings(model="ollama:nomic-embed-text")

try:
    DB_DIR_PATH="my_chroma_db"
    db = chromadb.PersistentClient(DB_DIR_PATH)

    COLLECTION="science-book-ix"
    collection = db.get_collection(COLLECTION)

    while True:
        question = input("\nAsk Anything? ")
        if question == "exit":
            break

        question_embedding = embed_model.embed_query(question)
        print("=" * 60)

        search_results = collection.query(question_embedding, n_results=3)
        # print(json.dumps(search_results))
        # for search_result in search_results["documents"]:
        #     print(search_result)
        #     print("=" * 60)

        user_prompt = f"""
            You are helpful assistant. Answer the user question as per given context only.
            Do not use your internal knowledge for answering user question.

            User question: {question}

            Context:
            {json.dumps(search_results)}

            If you can answer the question based on given context,
            respond as following:
            Referenced Pages: page x, y, ...
            Answer: <final answer>

            If you cannot answer the question based on given context,
            respond as following:
            Reference: Not available
            Answer: Cannot answer the question.
        """
        response = llm.invoke([{"role": "user", "content": user_prompt}])
        print("FINAL ANSWER:\n", response.content)

except Exception as e:
    print("ERROR:\n", e)
