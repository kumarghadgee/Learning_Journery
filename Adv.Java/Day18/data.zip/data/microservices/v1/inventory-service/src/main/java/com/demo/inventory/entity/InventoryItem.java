package com.demo.inventory.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Version;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "inventory")

@NoArgsConstructor
@Getter
@Setter
public class InventoryItem {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false)
    private String skuCode;       // Stock Keeping Unit — product unique identifier
    private String productName;
    private Integer quantity;     // 0 = out of stock
    private Integer price;
    @Version
    private int version;
    
	public InventoryItem(String skuCode, String productName, Integer quantity, Integer price) {
		super();
		this.skuCode = skuCode;
		this.productName = productName;
		this.quantity = quantity;
		this.price = price;
	} 

	
    
}
