package com.healthcare.service;

import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.healthcare.custom_exceptions.ApiException;
import com.healthcare.custom_exceptions.ResourceNotFoundException;
import com.healthcare.dtos.ApiResponse;
import com.healthcare.dtos.DoctorDTO;
import com.healthcare.dtos.DoctorRegDTO;
import com.healthcare.entities.Doctor;
import com.healthcare.entities.User;
import com.healthcare.entities.UserRole;
import com.healthcare.repository.DoctorRepository;
import com.healthcare.repository.UserRepository;

import lombok.RequiredArgsConstructor;

@Service
@Transactional
@RequiredArgsConstructor
public class DoctorServiceImpl implements DoctorService {
	private final DoctorRepository doctorRepository;	
	private final UserRepository userRepository;
	private final ModelMapper modelMapper;

	@Override
	public List<DoctorDTO> getAllDoctors() {
		// TODO Auto-generated method stub
		return doctorRepository.getAllDoctorDetails();
	}

	@Override
	public DoctorDTO getDoctorDetailsByUserId(Long userId) {
		// TODO Auto-generated method stub
		return doctorRepository.getDoctorDetails(userId)
				.orElseThrow(() -> new ResourceNotFoundException("Invalid user id for doctor"));
	}
	
	public ApiResponse registerNewDoctor(DoctorRegDTO reqDTO) {
		// 1. validate for dup email or phone
		if(userRepository.existsByEmailOrPhone(reqDTO.getUserDetails().getEmail(),reqDTO.getUserDetails().getPhone()))
			throw new ApiException("Email alread Exists !!!!!");
		// 2. in case of no dup email -> dto -> entity (deep copy- highlight)
		Doctor entity = modelMapper.map(reqDTO, Doctor.class);	
		User userDetails = entity.getUserDetails();
		//3. assign doctor role
		userDetails.setUserRole(UserRole.ROLE_PATIENT);
		//4. later encrypt password	
		//3. save doctor entity (highlight - JPA cascade)
		Doctor persistentEntity=doctorRepository.save(entity);//users : insert -> PK -> child rec -> doctors : FK		
		//4. ret api resp dto
		return new ApiResponse("New Doctor Registered with ID="+persistentEntity.getId(), "Success");
	}


}
