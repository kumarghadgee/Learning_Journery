package com.healthcare.dao;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.healthcare.entities.Patient;
import com.healthcare.utils.HibernateUtils;

public class PatientDaoImpl implements PatientDao {

	@Override
	public String registerPatient(Patient patient) {
		String mesg="Registering patient failed....";
		// 1. Get Session from SessionFactory
		Session session = HibernateUtils.getSessionFactory().getCurrentSession();
		// 2. Begin Tx
		Transaction tx = session.beginTransaction();
		try {
			
			tx.commit();			
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			// re throw the exception to the caller
			throw e;
		}

		return mesg;
	}

	@Override
	public Patient getPatientDetails(Long userId) {
		Patient patient=null;
		// 1. Get Session from SessionFactory
		Session session = HibernateUtils.getSessionFactory().getCurrentSession();
		// 2. Begin Tx
		Transaction tx = session.beginTransaction();
		try {
			
			tx.commit();
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			// re throw the exception to the caller
			throw e;
		}
		return null;
	}
	
	

}
