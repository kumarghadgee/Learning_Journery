## Inference & Generation Parameters
When using **Groq-hosted LLMs**, most inference parameters are the same as those used by OpenAI-compatible APIs. 
The important ones are:

| Parameter                                   | What it does                                                                                               | Typical values             |
| ------------------------------------------- | ---------------------------------------------------------------------------------------------------------- | -------------------------- |
| **temperature**                             | Controls randomness. Lower = more deterministic, higher = more creative.                                   | `0–1` (sometimes >1)       |
| **max_completion_tokens** (or `max_tokens`) | Maximum number of tokens the model can generate.                                                           | `100–4000+`                |
| **top_p**                                   | Nucleus sampling. Chooses from the smallest set of likely tokens whose cumulative probability reaches `p`. | `0.8–1.0`                  |
| **stop**                                    | Stops generation when specified sequence(s) appear.                                                        | `["\nUser:", "</answer>"]` |
| **stream**                                  | Returns output token-by-token instead of waiting for the full response.                                    | `true` / `false`           |
| **seed**                                    | Makes outputs more reproducible (if supported by the model/API).                                           | Any integer                |
| **presence_penalty**                        | Encourages introducing new topics by penalizing repeated concepts.                                         | `-2` to `2`                |
| **frequency_penalty**                       | Reduces repeated words or phrases.                                                                         | `-2` to `2`                |

### Which ones matter the most?

1. **temperature** ⭐⭐⭐⭐⭐
   * `0` → deterministic, factual
   * `0.2` → coding, math
   * `0.7` → general chat
   * `1.0+` → creative writing

2. **max_completion_tokens** ⭐⭐⭐⭐⭐
   * Prevents responses from being cut off.
   * Set according to the expected response length.

3. **top_p** ⭐⭐⭐⭐☆
   * Alternative to temperature.
   * Usually leave at **1.0** when using temperature.
   * Change either `temperature` or `top_p`, not both unless you have a specific reason.

4. **stop** ⭐⭐⭐☆
   * Useful for structured outputs or chat agents.

5. **stream** ⭐⭐⭐☆
   * Improves perceived speed by showing tokens as they're generated.

### Using them with Groq

Example using the OpenAI-compatible Python client:

```python
from openai import OpenAI

client = OpenAI(
    api_key="YOUR_GROQ_API_KEY",
    base_url="https://api.groq.com/openai/v1"
)

response = client.chat.completions.create(
    model="llama-3.3-70b-versatile",
    messages=[
        {"role": "user", "content": "Explain AI in one paragraph."}
    ],
    temperature=0.3,
    max_completion_tokens=200,
    top_p=1,
    stream=False
)

print(response.choices[0].message.content)
```

---

## Recommended settings by use case

| Task             | Temperature | Top_p   | Max tokens |
| ---------------- | ----------- | ------- | ---------- |
| Coding           | `0–0.2`     | `1`     | 500–2000   |
| Math             | `0`         | `1`     | 500–1500   |
| RAG / QA         | `0.1–0.3`   | `1`     | 300–1000   |
| Chatbot          | `0.5–0.8`   | `1`     | 500–1500   |
| Creative writing | `0.8–1.2`   | `0.9–1` | 1000–4000  |
| Summarization    | `0–0.3`     | `1`     | 200–800    |

### tips

* Start with:
  ```text
  temperature = 0.2
  top_p = 1
  max_completion_tokens = 1024
  ```
  This is a good default for most applications.

* Increase `temperature` only if responses feel too rigid or repetitive.
* Increase `max_completion_tokens` if responses are getting truncated.
* Use `stream=True` for interactive apps to reduce perceived latency.
* Add `stop` sequences when you need the model to stop at specific markers, such as the end of a JSON object or before another speaker's turn.
