
# Stateful Chatbot

import os
from groq import Groq
from dotenv import load_dotenv

load_dotenv()
GROQ_MODEL = "llama-3.1-8b-instant"
GROQ_API_KEY = os.getenv("GROQ_API_KEY")
client = Groq(api_key=GROQ_API_KEY)

conversation = []
while True:
    user_prompt = input("\n\nAsk anything: ")
    if user_prompt == "exit":
        break
    conversation.append({"role": "user", "content": user_prompt})
    response = client.chat.completions.create(
                        model=GROQ_MODEL,
                        messages=conversation,
                        temperature=1.0,
                        max_completion_tokens=1000,
                        stream=True
                    )
    ai_answer = ""
    for chunk in response:
        if chunk.choices[0].delta.content:
            ai_answer += chunk.choices[0].delta.content
            print(chunk.choices[0].delta.content, end="")
    conversation.append({"role": "assistant", "content": ai_answer})
