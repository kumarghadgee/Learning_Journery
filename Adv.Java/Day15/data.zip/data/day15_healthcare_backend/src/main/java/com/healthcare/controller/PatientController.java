package com.healthcare.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.healthcare.service.PatientService;
import com.healthcare.service.UserServiceImpl;
import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/patients")
@RequiredArgsConstructor
public class PatientController {  
	//depcy - ctor based D.I
	private final PatientService patientService; 
	/*
	 * URI - /patients/{patientId}
	 * Method - GET
	 * I/P - patientId : path var
	 * Success resp - SC 200 , + patient resp dto
	 * Error resp - SC 404
	 */
	@GetMapping("/{patientId}")
	public ResponseEntity<?> getPatientDetails(@PathVariable Long patientId)
	{
		System.out.println("in get patient "+patientId);
		try {
			return ResponseEntity.ok(patientService.getPatientDetails(patientId));		
		}catch (RuntimeException e) {
			return ResponseEntity.notFound().build();//SC 404
		}
	}

}
