package com.demo.order.service;

import java.util.List;
import java.util.UUID;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.jaxb.SpringDataJaxb.OrderDto;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;

import com.demo.order.OrderServiceApplication;
import com.demo.order.custom_exceptions.ApiException;
import com.demo.order.dto.InventoryResponse;
import com.demo.order.dto.OrderRequest;
import com.demo.order.dto.OrderResponse;
import com.demo.order.entity.Order;
import com.demo.order.repository.OrderRepository;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service

@Slf4j
@Transactional
@RequiredArgsConstructor
public class OrderServiceImpl implements OrderService {

	private final OrderServiceApplication orderServiceApplication;
	private final OrderRepository orderRepository;
	private final ModelMapper mapper;
	private final RestTemplate restTemplate;
	@Value("${inventory.stock.check}")
	private String url;

	public OrderResponse placeOrder(OrderRequest request) {
		// generate random UUID (Universally unique identifier) - 36 characters
		String orderNum = "ORD-" + UUID.randomUUID().toString();
		log.info("Processing order {} for SKU: {}", orderNum, request.getSkuCode());

		String skuCode = request.getSkuCode();
		int quantity = request.getOrderQuantity();
		String custName = request.getCustomerName();
		

		/*
		 * 1. MS call to Inventory Service to check the stock (RestTemplate) url
		 * -http://localhost:8080/check/{skuCode}/{quantity}
		 */
		InventoryResponse inventoryResponse = restTemplate.getForObject(url, InventoryResponse.class, skuCode,
				quantity);
		/*
		 * 2. If inventory item is in stock , then create Order
		 */
		if (inventoryResponse.isInStock()) {
			Order order = mapper.map(inventoryResponse, Order.class);
			// transfers skuCode , productName, ....
			order.setOrderNumber(orderNum);
			order.setCustomerName(custName);
			order.setQuantity(quantity);
			order.setTotalPrice(quantity*inventoryResponse.getPrice());

			/*
			 * 3. Set customer name , order number , quantity , product sku code 4. From
			 * Inventory response - set product name - compute & set total price 5. Set
			 * order status - Confirmed 6. Make another call to Inventory MS -> to deduct
			 * the stock 7. Save the order in DB
			 */
			orderRepository.save(order);
			/*
			 * 8. Map Order entity -> DTO & send it to controller.
			 */
			return mapper.map(order, OrderResponse.class);
		}
		// order not placed - out of stock
		throw new ApiException("Order can't be placed - Inventory Item Out of Stock!!!!");
	}

	public List<OrderResponse> getAllOrders() {
		return orderRepository.findAll().stream().map(order -> mapper.map(order, OrderResponse.class)).toList();
	}

	public OrderResponse getOrderById(Long id) {

		Order order = orderRepository.findById(id).orElseThrow(() -> new RuntimeException("Order not found: " + id));
		return mapper.map(order, OrderResponse.class);
	}
}
