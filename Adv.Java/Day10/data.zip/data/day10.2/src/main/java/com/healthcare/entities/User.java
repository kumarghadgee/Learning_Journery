package com.healthcare.entities;

import java.time.LocalDate;

import com.healthcare.value_types.AdhaarCard;

import jakarta.persistence.AttributeOverride;
import jakarta.persistence.Column;
import jakarta.persistence.Embedded;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;


//lombok 
@NoArgsConstructor
@Getter
@Setter
@ToString(exclude = "password")
@Entity 
@Table(name = "users") // to declare table name
//to override the PK col name as user_id
@AttributeOverride(name="id",column = @Column(name="user_id"))
public class User extends BaseClass{
	@Column(name="first_name",length = 20)//varchar(20)
	private String firstName;	
	@Column(name="last_name",length = 30)//varchar(30)
	private String lastName;
	@Column(length = 50,unique = true)//adds UNIQUE constraint
	private String email;
	@Column(nullable = false)//NOT NULL constraint
	private String password;
	private LocalDate dob;
	@Column(length = 14,unique = true)
	private String phone;
	@Column(name="user_role")
	@Enumerated(EnumType.STRING) 
	private UserRole userRole;
	@Column(name="reg_amount")
	private Integer regAmount;
	//User HAS-A (composition) AdhaarCard
	@Embedded //optional !
	private AdhaarCard card;
	
	public User(String firstName, String lastName, String email, String password, LocalDate dob, String phone,
			UserRole userRole, Integer regAmount) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.password = password;
		this.dob = dob;
		this.phone = phone;
		this.userRole = userRole;
		this.regAmount = regAmount;
	}
	
}
