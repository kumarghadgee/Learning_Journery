# decorator

class Rectangle:
    def __init__(self, len=0, br=0):
        self.len = len
        self.br = br

    # static methods do not receive "self"
    # they are called on class name
    @staticmethod
    def calc_area(r):
        area = r.len * r.br
        print(f"area = {area}")


r1 = Rectangle(len=10, br=4)
Rectangle.calc_area(r1)
