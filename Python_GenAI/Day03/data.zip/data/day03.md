# Agenda
1. Type hinting
2. Pydantic
3. Decorator
4. FastAPI
5. Pandas
6. Pandasql

## Type hinting
- Python is dynamic typing language. The types detected at runtime.
- Types: variables, function args, function return types, ...

```python
x = 10      # type detected at runtime
y:int = 20  # type-hint is given in code, type detected at runtime
```

### Advantage
- Improves code readability
- Better IDE intellisense
- Detect logical mistakes during development -- using tools like pylint
- Used by some Python libraries for certain features e.g. fastapi, ...

## Pydantic
- Python library used to define structured data using Python classes.

### Advantage/Use
- validation
- auto conversion (if compatible)
- readable error message
- increase code maintainability
- used by python libraries for type understanding/documenting

### Installation

> pip install pydantic

## Decorators
- To modify/extend behaviour of a function, without modifying its source code.
- Used to associate some metadata/info with a function.

## FastAPI
- Modern Python framework for building REST APIs quickly and efficiently.

### Advanatges
- High performance
- Simple syntax
- Auto request validation
- Auto API documentation

### Installation
> pip install fastapi uvicorn

## Pandas
* Pandas is a library to work with datasets.
* Pandas Dataframe represents data in tabular format -- rows & columns -- in memory.

### Installation
> pip install pandas

### Usage
```python
import pandas as pd
df = pd.read_csv(csv_path)
print(df)
```

## Pandasql
- Python library to execute SQL queries on pandas dataframes.
- Useful for data filtering, cleaning -- SELECT queries.
- Very simple APIs

### Installation
> pip install pandasql
