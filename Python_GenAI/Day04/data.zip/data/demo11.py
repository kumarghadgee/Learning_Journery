import os
import pandas as pd
import pandasql as ps
import streamlit as st
from langchain.messages import SystemMessage, HumanMessage
from langchain.chat_models import init_chat_model
from dotenv import load_dotenv

load_dotenv()

llm = init_chat_model(
        model="groq:llama-3.1-8b-instant",
        api_key=os.getenv("GROQ_API_KEY")
    )
SYSTEM_PROMPT = """
You are expert SQL developer. You have 5 years of experience in MySQL database.
Write a SQL query corresponding to given user question.
The query should target the given table and schema.
Only write SQL query and nothing else. No markdown/markers.
"""
st.title("Products Explorer")

file_path="products.csv"
df = pd.read_csv(file_path)
st.dataframe(df)

try:
    user_prompt = st.chat_input("What you want to know about the products?")
    if user_prompt:
        response = llm.invoke(input=[
            SystemMessage(content=SYSTEM_PROMPT),
            HumanMessage(content=f"""
                Table: products

                Table schema: {df.dtypes}

                User question: {user_prompt}
            """)
        ])
        sql = response.content
        st.write(f"SQL: {sql}")
        result_df = ps.sqldf(sql, {"products": df})
        st.dataframe(result_df)

except Exception as e:
    st.markdown(f"**{str(e)}**")
