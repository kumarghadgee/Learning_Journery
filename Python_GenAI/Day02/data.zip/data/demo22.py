# Python OOP inheritanbce

class Animal:
    def speak(self):
        print("Animal - sounds")

class Dog(Animal):
    def speak(self):
        print("Dog - bark")
    
class Cat(Animal):
    def speak(self):
        print("Cat - Meow")

class SomeAnimal(Animal):
    pass

a1 = Animal()
a1.speak() # sound
d1 = Dog()
d1.speak() # bark
c1 = Cat()
c1.speak() # meow
s1 = SomeAnimal()
s1.speak() # sound