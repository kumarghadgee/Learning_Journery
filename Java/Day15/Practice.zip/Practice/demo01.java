import java.util.Scanner;

class reverse
{
    public void rev()
    {
        Scanner sc = new Scanner(System.in);

        System.out.print("Please Enter the Number to reverse it : ");
        int n = sc.nextInt();
        int m = 0;
        int o = 0;

        while(n > 0)
        {
            m = n % 10;
            o = (o * 10) + m;
            n /= 10;
        }

        System.out.println("Reversed Number is : "+o);

        sc.close();
    }
}

public class demo01{
    public static void main(String[] args) {
        reverse r = new reverse();
        r.rev();
    }
}