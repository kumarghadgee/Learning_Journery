package com.voting.controller;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Servlet implementation class FrontControllerServlet - Centralized Dispatcher
 * - Global interceptor
 */
@WebServlet("/")
public class FrontControllerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		/*
		 * 1. Use HttpServletRequest API To Get incoming url pattern - String
		 * getServletPath();
		 */
		String path = request.getServletPath();
		System.out.println("in front controller , do-get " + path);
		String outcome = null;
		switch (path) {
		case "/":
			outcome = "/WEB-INF/views/login.jsp";
			break;
		case "/authenticate":
			outcome = "/auth";
			break;
		case "/voter":
			outcome = "/voter_dashboard";
			break;
		case "/user_logout":
			outcome = "/logout";
			break;
			
		default:
			outcome = "/WEB-INF/views/login.jsp";
			break;
		}
		// forward the request to the outcome
		RequestDispatcher rd = request.getRequestDispatcher(outcome);
		rd.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
