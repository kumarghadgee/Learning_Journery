
sample_text = """
Python is a high-level, general-purpose programming language that emphasizes code readability, simplicity, and ease-of-writing with the use of significant indentation, an extensive ("batteries-included") standard library, and garbage collection. Python supports multiple programming paradigms but with an emphasis on object-oriented programming and dynamic typing.

Guido van Rossum began working on Python in the late 1980s as a successor to the ABC programming language. Python 3.0, released in 2008, was a major revision and not completely backward-compatible with earlier versions. 
"""

file_name = "demo.txt"

# basic file write operation. file opened & closed explicitly
# open() modes = "w" for write, "a" for append, "r" for read (default)
# file1= open(file_name, "w")
# file1.write(sample_text)
# print(f"File saved: {file_name}")
# file1.close()

# file write operation. "with" block will auto-close the file at the end.
with open(file_name, "w") as file1:
    file1.write(sample_text)
    print(f"File saved: {file_name}")

# file read operation.
with open(file_name) as file2:
    text = file2.read()
    print(f"File read: {file_name}\n")
    print(text)
