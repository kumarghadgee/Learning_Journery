package PracticePatterns;

import java.util.Scanner;

class pattern3
{
	public void star()
	{
		Scanner sc = new Scanner(System.in);
		System.out.print("Please Enter the value of n : ");
		int n = sc.nextInt();
		
		for(int i = 1 ; i <= n ; i++) {
			for(int j = 1 ; j <= n - i ; j++) {
				System.out.print(" ");
			}
			
			for(int j = 1 ; j <= i ; j++) {
				System.out.print("*");
			}
			
			System.out.println();
		}
		
		sc.close();
	}
}


public class demo03 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		pattern3 pt = new pattern3();
		pt.star();
	}

}
