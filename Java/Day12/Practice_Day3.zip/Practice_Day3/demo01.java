import java.util.Scanner;

class swap
{
    public void swapping()
    {
        Scanner sc = new Scanner(System.in);
        try{
            System.out.print("Please the First Number : ");
            int a = sc.nextInt();
            System.out.print("Please the First Number : ");
            int b = sc.nextInt();

            System.out.println("Values Before Swapping : " + "a = " + a + ", b = "+ b );

            a = a + b;
            b = a - b;
            a = a - b;

            System.out.println("Values After Swapping : " + "a = " + a + ", b = "+ b );

        }
        catch(Exception e)
        {
            System.out.println("Error you given values incorrect......");
        }
        
        sc.close();
    }
}

public class demo01
{
    public static void main(String[] args) {
        swap sp = new swap();
        sp.swapping();
    }
}