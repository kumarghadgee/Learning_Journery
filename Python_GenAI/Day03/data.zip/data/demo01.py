# type-hinting

from typing import Any, Literal

def ex01():
    x = 10
    y: int = 20
    print(f"x = {x} of type {type(x)}")
    print(f"y = {y} of type {type(y)}")
    y = "Nilesh" # can still assign value of different type - no problem at runtime
                    # however python tools/ide may generate warning
    print(f"y = {y} of type {type(y)}")

# ex01()

def ex02():
    print("Type hinting syntax")
    a: int = 10
    b: float = 3.14
    c: str = "Sunbeam"
    d: bool = False

    e: list[str] = [ "India", "Africa", "England", "New zealand" ]
    f: tuple[int,int,int] = (10, 20, 30)
    g: dict[str, Any] = {
        "name": "James",
        "addr": "London",
        "age": 65
    }

# ex02()

def ex03(arg:str):
    # in the fn intellisense on "arg" is available only if type-hint is provided
    print(f"arg in upper case: {arg.upper()}")

# ex03("cdac")

# the fn takes two args -- each of type int or float
# it returns float or None
def ex04(a:int | float, b:int | float) -> float | None:
    if b == 0:
        return None
    return a / b

# res1 = ex04(22, 7)
# print(f"ex04 div result: {res1}")
# res2 = ex04(2.2, 7)
# print(f"ex04 div result: {res2}")
# res3 = ex04(22, 0)
# print(f"ex04 div result: {res3}")

def ex05(marks:float) -> Literal["pass", "fail"]:
    if marks < 40:
        return "fail"
    else:
        return "pass"

status = ex05(65.0)
print(f"ex05({65.0}) -> {status}")
