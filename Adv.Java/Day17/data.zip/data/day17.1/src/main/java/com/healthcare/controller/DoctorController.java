package com.healthcare.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.healthcare.dtos.ApiResponse;
import com.healthcare.dtos.DoctorRegDTO;
import com.healthcare.service.DoctorService;

import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/doctors")
@RequiredArgsConstructor
@CrossOrigin(origins = "http://localhost:3000")
public class DoctorController {
	// depcy
	private final DoctorService doctorService;

	/*
	 * Design API end point in Doctor controller Desc -Get Doctor Specific Details
	 * URI -/doctors/{doctorId} Method - GET path variable(URI template var)
	 * Response - ResponseEntity<?> error resp - SC 404 (in case of invalid user id)
	 * + Api resp (DTO) - err mesg success - SC 200 + DoctorDTO
	 */
	@GetMapping("/docId")
	@Operation(description = "Get Doctor Specific Details by doc id")
	public ResponseEntity<?> getDoctorDetails(@PathVariable Long docId) {

		System.out.println("in get doctor details");
		
			return ResponseEntity.ok(doctorService.getDoctorDetailsByUserId(docId));
		
	}

	/*
	 * Design API end point in Doctor controller Desc -Get all doctor details URI
	 * -/doctors Method - GET
	 * 
	 * Response - ResponseEntity<?>
	 * 
	 * success - SC 200 + List<DoctorDTO>
	 */
	@GetMapping
	@Operation(description = "Get All Doctor Details ")
	public ResponseEntity<?> getAllDoctorDetails() {
		System.out.println("in get all doctor details - " + doctorService.getClass());
		return ResponseEntity.ok(doctorService.getAllDoctors());
	}

	/*
	 * Desc - Doctor Registration URL - http://host:port/doctors/signup Method -
	 * POST Payload - request dto Success resp - api resp + SC 201 Failed - api resp
	 * + SC 400
	 */
	@PostMapping("/signup")
	public ResponseEntity<?> registerDoctor(@RequestBody @Valid DoctorRegDTO dto) {
		System.out.println("in doc reg " + dto);

		return ResponseEntity.status(HttpStatus.CREATED).body(doctorService.registerNewDoctor(dto));

	}

}
