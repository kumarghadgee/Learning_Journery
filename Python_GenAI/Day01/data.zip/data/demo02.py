
# Variables and Data types
#   - Python follows dynamic typing i.e. types are detected at runtime.
#   - Variables are not declared before their use. Just assign value & start using variable.

# variable initialization
name = "Nilesh"
age = 42
can_vote = True     # False
salary = 50000.20 

# print variable values and types
print("name=", name, " -- type=", type(name))
print("age=", age, " -- type=", type(age))
print("can_vote=", can_vote, " -- type=", type(can_vote))
print("salary=", salary, " -- type=", type(salary))

# the variables can be reassigned to another value/object
#   of same type or different type
name = "Nilesh Ghule"
print("name=", name, " -- type=", type(name))
age = 42.5
print("age=", age, " -- type=", type(age))
salary = "1 lac"
print("salary=", salary, " -- type=", type(salary))
