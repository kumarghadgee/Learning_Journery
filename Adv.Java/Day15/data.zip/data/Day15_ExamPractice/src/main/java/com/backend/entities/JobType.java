package com.backend.entities;

public enum JobType {
	FULL_TIME , PART_TIME , CONTRACT;
}
