package com.healthcare.service;

import java.util.List;

import com.healthcare.dtos.ApiResponse;
import com.healthcare.dtos.DoctorDTO;
import com.healthcare.dtos.DoctorRegDTO;

public interface DoctorService {
	// add a method to get doc details by user id
	DoctorDTO getDoctorDetailsByUserId(Long userId);

	// get all doctors details
	List<DoctorDTO> getAllDoctors();

	// method to sign up
	ApiResponse registerNewDoctor(DoctorRegDTO reqDTO);
}
