package myPractice;

import java.util.Scanner;

class pattern5
{
	public void star()
	{
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter the max number of stars you want : ");
		int k = sc.nextInt();
		for(int i = k ; i > 0 ; i--) {
			for(int j = i ; j > 0 ; j--) {
				System.out.print("* ");
			}
			System.out.println();
		}
		
		for(int i = 1; i <= k ; i++) {
			for(int j = 1 ; j <= i ; j++) {
				System.out.print("* ");
			}
			System.out.println();
		}
		sc.close();
	}
}
 
public class demo06 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		pattern5 pt = new pattern5();
		pt.star();
	}

}
