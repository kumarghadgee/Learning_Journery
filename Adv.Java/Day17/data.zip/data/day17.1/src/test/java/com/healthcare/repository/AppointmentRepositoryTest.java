package com.healthcare.repository;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import com.healthcare.dtos.AppointmentResp;
import com.healthcare.entities.Status;

//data layer test
@DataJpaTest
@AutoConfigureTestDatabase(replace = Replace.NONE)
class AppointmentRepositoryTest {
	@Autowired
	private AppointmentRepository appointmentRepository;

	@Test
	void testGetPatientUpcomingAppointments() {
		List<AppointmentResp> upcomingAppointments = appointmentRepository.getPatientUpcomingAppointments(5l,Status.SCHEDULED);
		//1st arg - expected 2nd arg - actual
		assertEquals(2, upcomingAppointments.size());
	}

}
