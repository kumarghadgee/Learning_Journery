<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<%--import JSTL core tag lib --%>
<%@ taglib uri="jakarta.tags.core" prefix="c"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
	<%--create session scoped attribute to store product id n price --%>
	<c:set var="product_details" value="Product Id : ${param.id} - Price : ${param.price}"
		scope="session" />
	<%-- redirect client to next page , render product details from the next page --%>
	<c:remove var="product_details" scope="session"/>
	<c:redirect url="test2.jsp">
		<c:param name="p_name" value="T shirt"></c:param>
	</c:redirect>
</body>
</html>