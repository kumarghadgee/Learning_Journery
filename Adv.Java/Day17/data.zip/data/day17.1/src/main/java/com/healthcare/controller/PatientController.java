package com.healthcare.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.healthcare.dtos.PatientRegDTO;
import com.healthcare.service.PatientService;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/patients")
@RequiredArgsConstructor
@Validated
public class PatientController {  
	//depcy - ctor based D.I
	private final PatientService patientService; 
	/*
	 * URI - /patients/{patientId}
	 * Method - GET
	 * I/P - patientId : path var
	 * Success resp - SC 200 , + patient resp dto
	 * Error resp - SC 404
	 */
	@GetMapping("/{patientId}")
	public ResponseEntity<?> getPatientDetails(@PathVariable @Min(5) @Max(80)
			Long patientId)
	{
		System.out.println("in get patient "+patientId);
		
			return ResponseEntity.ok(patientService.getPatientDetails(patientId));		
		
	}
	/*
	 * URI - /patients
	 * Method - GET	 
	 *  resp - SC 200 + List<dto>	 
	 */
	@GetMapping
	public ResponseEntity<?> getAllPatients() {
		return ResponseEntity.ok(patientService.getAllPatients());
	}
	
	/*
	 * Desc - Patient Registration 
	 * URL - http://host:port/patients/signup 
	 * Method - POST 
	 * Payload - req dto 
	 * Success resp - api resp + SC 201 
	 * Failed - api resp + SC 400
	 */
	@PostMapping("/signup")
	public ResponseEntity<?> registerPatient(@RequestBody @Valid
			PatientRegDTO dto) {
		System.out.println("in patient reg " + dto);
		
			return ResponseEntity.status(HttpStatus.CREATED)
					.body(patientService.registerNewPatient(dto));		
		
	}


}
