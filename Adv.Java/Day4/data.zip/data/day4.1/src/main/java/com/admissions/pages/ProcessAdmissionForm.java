package com.admissions.pages;

import java.io.IOException;
import java.io.PrintWriter;

import com.admissions.pojos.Course;
import com.admissions.pojos.Student;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ProcessAdmissionForm
 */
@WebServlet("/process_admission")
public class ProcessAdmissionForm extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//1. set cont type - only for checking
		response.setContentType("text/html");
		//2. get PW
		try(PrintWriter pw=response.getWriter())
		{
			//3. read request params
			String firstName=request.getParameter("fn");
			String lastName=request.getParameter("ln");
			int marks=Integer.parseInt(request.getParameter("score"));
			Course chosenCourse=Course.valueOf(request.getParameter("course").toUpperCase());
			boolean flag=false;
			if(marks >= chosenCourse.getMinScore())
				flag=true;
			//4 encapsulate the info in Student pojo
			Student student=new Student(firstName, lastName, chosenCourse, marks, flag);
			pw.print("from 1st page ....");
	//		pw.flush();
			//5. add student details under request scope
			request.setAttribute("student_details", student);
			//6. Get RequestDispatcher to dispatch SAME request to the next page
			RequestDispatcher rd=request.getRequestDispatcher("admission_result");
			rd.include(request, response);
			System.out.println("control came back.....");	
			
		}
	}

}
