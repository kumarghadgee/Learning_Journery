# pydantic

from pydantic import BaseModel, Field

# pydantic model
class Student(BaseModel):
    roll: int
    name: str
    marks: float

s1 = Student(roll=123, name="Nilesh", marks=76.5)
print(s1)
print(f"s1 roll={s1.roll} {type(s1.roll)}, name={s1.name} {type(s1.name)}, marks={s1.marks} {type(s1.marks)}")

s2 = Student(roll="123", name="Nilesh", marks="76.5")
print(s2)
print(f"s2 roll={s2.roll} {type(s2.roll)}, name={s2.name} {type(s2.name)}, marks={s2.marks} {type(s2.marks)}")

# s3 = Student(roll="One", name="Nilesh", marks="76.5") # ValidationError: Input should be a valid integer, unable to parse string as an integer
# print(s3)

# Field -- applies validation/constraints
# Optional attribute (default arg) -- If not given, default value used
class Teacher(BaseModel):
    id: int = Field(gt=0)
    name: str = Field(min_length=2)
    age: int = Field(ge=18, lt=100)
    salary: float = 0.0
    subjects: list[str]

t1 = Teacher(id=4, name="Nilesh", age=42, subjects=["Python", "AI", "Java"])
print("t1:", t1)

t2 = Teacher(id=5, name="Rohan", age=32, salary=30000.0, subjects=["MERN", "DBT"])
print("t2:", t2)
