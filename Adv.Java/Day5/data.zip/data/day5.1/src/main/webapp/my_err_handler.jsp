<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8" isErrorPage="true"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Error Handling Page</title>
</head>
<body>
	<h5 style="color: red;">
		Error Message Via Expression-
		<%=exception.getMessage()%></h5>
	<h5 style="color: red;">Error Message Via EL Syntax -
		${pageContext.exception.message}</h5>
	<h5 style="color: red;">Error Causing Page
		${pageContext.errorData.requestURI}</h5>

	<h5 style="color: red;">Error Status Code
		${pageContext.errorData.statusCode}</h5>
		<h5 style="color: red;">Exception
		${pageContext.exception}</h5>

</body>
</html>