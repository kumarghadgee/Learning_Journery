package com.healthcare.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.healthcare.dtos.AppointmentResp;
import com.healthcare.service.AppointmentService;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/appointments")
@RequiredArgsConstructor
public class AppointmentController {
	//depcy
	private final AppointmentService appointmentService;
	/*
	 * URI - /appointments/patients/{patientId}/upcoming
	 * Method - GET
	 * Input - patient id : path var
	 * Successful Resp - SC 200 + List<dto>
	 * No appointments - SC 204,No body content
	 */
	@GetMapping("/patients/{patientId}/upcoming")
	public ResponseEntity<?> getPatientsScheculedAppointments(@PathVariable Long patientId )
	{
		System.out.println("in patient upcoming apps "+patientId);
		List<AppointmentResp> list = appointmentService.getPatientsScheduledAppointments(patientId);
		if(list.isEmpty()) {
			return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
		}
		return ResponseEntity.ok(list);
	}

}
