package com.demo.inventory.custom_exceptions;

public class InsufficientStockException extends RuntimeException {
	public InsufficientStockException(String mesg) {
		super(mesg);
	}
}
