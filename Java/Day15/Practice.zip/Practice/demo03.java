import java.util.HashSet;
import java.util.Scanner;

class removeDuplicates
{
    public void remove()
    {
        Scanner sc = new Scanner(System.in);

        System.out.print("Please Enter the values of the array  : ");
        int size = sc.nextInt();

        int[] nums = new int[size];

        System.out.println("Enter " + size + "integer value : ");
        for(int i = 0 ; i < size ; i++)
        {
            System.out.print("Enter the Element at " + i + "th index : ");
            nums[i] = sc.nextInt();
        }
        
        HashSet<Integer> dups = new HashSet<>();

        for(int num : nums)
        {
            if(!dups.add(num))
            {
                System.out.println("Duplicate Number in the array = "+num);
            }
        }

        sc.close();
    }
}

public class demo03 {
    public static void main(String[] args) {
        removeDuplicates rd = new removeDuplicates();
        rd.remove();
    }
}
