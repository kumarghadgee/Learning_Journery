package com.voting.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBUtils {

	// add static method to return DB connection to the caller
	public static Connection getConnection(String dbURL, String userName, String password) throws SQLException {
		return DriverManager.getConnection(dbURL, userName, password);
	}

}
