<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
<h5>From 1st page ....</h5>
	<%
	//out.flush();
	pageContext.setAttribute("nm1", 100);
	request.setAttribute("nm2", 200);
	session.setAttribute("nm3", 300);
	application.setAttribute("nm4", 400);
	//client pull -> discard resp buffer -> WC sends redirect resp -> we browser sends redirect request
	response.sendRedirect("test2.jsp");
/* 	RequestDispatcher rd=request.getRequestDispatcher("test2.jsp");
	rd.include(request, response); */
	%>
	<h5>main page generating contents post include</h5>
</body>
</html>