package com.demo.inventory.exception_handler;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.orm.ObjectOptimisticLockingFailureException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.demo.inventory.custom_exceptions.InsufficientStockException;
import com.demo.inventory.custom_exceptions.ResourceNotFoundException;
import com.demo.inventory.dto.ApiResponse;

@RestControllerAdvice
public class GlobalExceptionHandler {
	@ExceptionHandler(ResourceNotFoundException.class)
	    public ResponseEntity<?> handleNotFound(
	            ResourceNotFoundException ex) {
	
	        return ResponseEntity.status(HttpStatus.NOT_FOUND)
	                .body(new ApiResponse(ex.getMessage(),"Failed"));
	    }
	
	    @ExceptionHandler(InsufficientStockException.class)
	    public ResponseEntity<?> handleStockException(
	            InsufficientStockException ex) {
	
	        return ResponseEntity.status(HttpStatus.CONFLICT)
	                .body(new ApiResponse(ex.getMessage(),"Failed"));
	    }
	    
	    @ExceptionHandler(ObjectOptimisticLockingFailureException.class)
	    public ResponseEntity<?> handleObjectOptimisticLockingFailureException(
	    		ObjectOptimisticLockingFailureException ex) {
	
	        return ResponseEntity.status(HttpStatus.CONFLICT)
	                .body(new ApiResponse(ex.getMessage(),"Failed"));
	    }
	    
	
}

