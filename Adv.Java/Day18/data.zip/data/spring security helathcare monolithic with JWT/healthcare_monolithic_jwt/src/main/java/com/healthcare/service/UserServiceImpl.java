package com.healthcare.service;

import org.modelmapper.ModelMapper;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.healthcare.dtos.ApiResponse;
import com.healthcare.dtos.AuthRequest;
import com.healthcare.dtos.AuthResponse;
import com.healthcare.repository.UserRepository;
import com.healthcare.security.CustomUserDetailsImpl;
import com.healthcare.security.JwtUtils;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@Transactional(readOnly = true)
@RequiredArgsConstructor //init final fields
@Slf4j
public class UserServiceImpl implements UserService {
	//depcy - using constr based D.I
	private final UserRepository userRepository;
	//depcy - ModelMapper
	private final ModelMapper mapper;
	private final PasswordEncoder encoder;
	private final AuthenticationManager authenticationManager;
	private final JwtUtils jwtUtils;
	

	@Override
	public AuthResponse authenticate(AuthRequest request) {
		/*1. Create instance of UsernamePasswordAuthenticationToken 
		 * to hold email & password
		 * UsernamePasswordAuthenticationToken implements Authentication i/f
		 * public UsernamePasswordAuthenticationToken(Object email,Object password)
		 */
		UsernamePasswordAuthenticationToken authentication=new UsernamePasswordAuthenticationToken(request.getEmail(), request.getPassword());
		/*
		 * 2. Simply call AuthenticationManager's authenticate method
		 * Method of AuthenticationManager
		 * public Authentication authenticate(Authentication auth)
		 * - throws AuthenticationException in case of failed auth
		 * - otherwise returns Authentication obj  - user details 
		 * 
		 */
		log.info("******* Before Auth - {}"+authentication.isAuthenticated());//f
		Authentication fullyAuthenticated = authenticationManager.authenticate(authentication);
		log.info("******* After Auth - {}"+fullyAuthenticated.isAuthenticated());//t
		log.info("***** Authetication {} ",fullyAuthenticated.getPrincipal().getClass());//CustomUserDetailsImpl
		log.info("***** Authetication {} ",fullyAuthenticated.getCredentials());//null
		/*
		 *3. Create signed JWT -> send it to client
		 * 
		 */
		CustomUserDetailsImpl userDetails=(CustomUserDetailsImpl) fullyAuthenticated.getPrincipal();		
		return new AuthResponse(userDetails.getUserId(),  userDetails.getCompleteName(), userDetails.getRole(), jwtUtils.generateJwt(userDetails));
	}

	@Override
	@Transactional
	public ApiResponse encryptPasswords() {
		userRepository.findAll() //List<User>
		.stream() //Stream<User>
		.forEach(user -> user.setPassword(encoder.encode(user.getPassword())));
		return new ApiResponse("Success", "Password encoded");
	}
	

}
