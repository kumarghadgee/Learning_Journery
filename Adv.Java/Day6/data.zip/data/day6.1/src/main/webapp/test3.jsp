<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<%!//declaration block - 
	int visits;//instance var - cuurent page only
	//overriding jsp life cycle method

	public void jspInit() {
		System.out.println("in jspInit " + Thread.currentThread());
	}

	//java method 
	int refresh() {
		return ++visits;
	}%>

<body>
	<h5>
		Visits -
		<%=refresh()%></h5>
	<%
	System.out.println("in _jspService " + Thread.currentThread());
	%>
</body>
<%!public void jspDestroy() {
		System.out.println("in jspDestory " + Thread.currentThread());
	}%>

</html>