
# Ollama Chatbot (Stateless)

from ollama import chat
OLLAMA_MODEL = "llama3.2"

while True:
    user_prompt = input("Ask anything: ")
    if user_prompt == "exit":
        break
    response = chat(model=OLLAMA_MODEL, messages=[
        {"role": "user", "content": user_prompt}
    ])
    print("Answer:", response.message.content)
