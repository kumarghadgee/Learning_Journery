package com.empDept.tester;

import com.empDept.dao.DepartmentDao;
import com.empDept.dao.DepartmentDaoImpl;
import com.empDept.entities.Department;

import static com.empDept.utils.HibernateUtils.getSessionFactory;

import java.util.Scanner;

import org.hibernate.SessionFactory;

public class addDepartment {

	public static void main(String[] args) {
		try(Scanner sc = new Scanner(System.in); SessionFactory sf = getSessionFactory()){
			DepartmentDao deptDao = new DepartmentDaoImpl();
			
			System.out.println("Enter the Department Name & Location : ");
			String name = sc.next();
			String location = sc.next();
			
			System.out.println(deptDao.addNewDepartment(name,location));
		}
		catch(Exception e) {
			e.printStackTrace();
		}

	}

}
