package com.demo.inventory.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class StockRequest {
	private String skuCode;
    private int quantity;
}
