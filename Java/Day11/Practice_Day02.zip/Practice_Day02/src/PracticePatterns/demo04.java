package PracticePatterns;

import java.util.Scanner;

class pattern4
{
	public void star()
	{
		Scanner sc = new Scanner(System.in);
		System.out.print("Please Enter the value of n : ");
		int n = sc.nextInt();
		
		for(int i = n ; i > 0 ; i--) {
			for(int j = n ; j > 0 ; j--) {
				System.out.print("*");
			}
			
			for(int j = n ; j > i - n ; j--) {
				System.out.print(" ");
			}
			
			System.out.println();
		}
		sc.close();
	}
}

public class demo04 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		pattern4 pt = new pattern4();
		pt.star();
	}

}
