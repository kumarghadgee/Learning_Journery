package myPractice;

import java.util.Scanner;

class pattern6
{
	public void star()
	{
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter the numbers you want : ");
		int k = sc.nextInt();
		for(int i = 1 ; i <= k ; i++) {
			for(int j = 1 ; j <= i ; j++) {
				System.out.print(i + " ");
			}
			System.out.println();
		}
		
		sc.close();
	}
}

public class demo07 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		pattern6 pt = new pattern6();
		pt.star();
	}

}
