<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
<h5>Product Name - ${sessionScope.product_details.name}</h5>
<h5>Product Price - ${product_details.price}</h5>
</body>
</html>