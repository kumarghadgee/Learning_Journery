package myPractice;

import java.util.Scanner;

class pattern4
{
	public void star4()
	{
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter the number of stars you want in triangle : ");
		int k = sc.nextInt();
		for(int i = 1; i <= k ; i++) {
			for(int j = 1; j <= i; j++) {
				System.out.print("* ");
			}
			System.out.println();
		}
		
		for(int i = k - 1; i > 0; i--) {
			for(int j = i; j > 0 ; j--) {
				System.out.print("* ");
			}
			System.out.println();
		}
		
		sc.close();
	}
}

public class demo05 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		pattern4 pt4 = new pattern4();
		pt4.star4();
	}
}
