package com.backend.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.backend.entities.CompanyEntity;
import com.backend.entities.JobType;

public interface CompanyRepository extends JpaRepository<CompanyEntity, Long>{
	
}
