# control structs: loops

num = int(input("Enter a number: "))
# while loop
print("table using while loop: ")
i=1
while i <= 10:
    val = num * i
    print(f"{num} * {i} = {val}")
    i += 1   # i++ not supported in python. += is in-place addition operator

print("-" * 60) # repeatition operator -- string is repeated multiple times
# for loop -- for-each loop -- to access elems one by one from a collection
#   range(n) --> creates a seq (collection) --> 0, 1, 2, ..., n-1
#   range(m,n) --> creates a seq (collection) --> m, m+1, m+2, ..., n-1
print("table using for loop: ")
for i in range(1, 11):
    val = num * i
    print(f"{num} * {i} = {val}")

# nested loops are allowed
# in general, nested control structures are allowed (like C, Java, etc)
