package com.backend.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;

import com.backend.entities.Job;
import com.backend.entities.JobType;

public interface JobRepository extends JpaRepository<Job, Long> {

	List<Job> findByLocation(String location);

	@Modifying
	int deleteAllByJobTypeAndMyCompanyName(JobType jobType, String name);

	@Modifying
	int deleteByMyCompanyCompanyId(Long id);
}
