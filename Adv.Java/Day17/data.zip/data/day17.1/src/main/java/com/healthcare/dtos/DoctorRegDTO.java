package com.healthcare.dtos;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
@Getter
@Setter
@ToString
public class DoctorRegDTO {
	@Valid //IMPORTANT - to enable cascading of validations
	private UserRegDTO userDetails;
	@NotNull
	private int experienceInYears;
	private int fees;	
	private String speciality;
	private String qualifications;
	
}
