package com.product.dao;

import java.util.List;

import com.product.entities.Product;

public interface ProductDao extends BaseDao {
	List<Product> getProductsByCategory(long categoryId);
}	
