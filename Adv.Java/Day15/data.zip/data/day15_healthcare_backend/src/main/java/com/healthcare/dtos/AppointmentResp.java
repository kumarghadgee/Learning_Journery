package com.healthcare.dtos;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class AppointmentResp {  
	private Long id;  //appointments Table
	//For Patient's dashboard - Doctor's Name
	//For Doctor's dashboard - Patient's Name
	private String firstName;
	private String lastName;
	private LocalDateTime appointmentDateTime;
}
