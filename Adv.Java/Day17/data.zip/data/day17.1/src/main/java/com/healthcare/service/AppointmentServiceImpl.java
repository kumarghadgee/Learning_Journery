package com.healthcare.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Set;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.healthcare.custom_exceptions.AppointmentException;
import com.healthcare.custom_exceptions.InvalidInputException;
import com.healthcare.custom_exceptions.ResourceNotFoundException;
import com.healthcare.dms.repository.DiagTestRepository;
import com.healthcare.dtos.ApiResponse;
import com.healthcare.dtos.AppointmentResp;
import com.healthcare.dtos.BookAppointment;
import com.healthcare.dtos.CompleteAppointment;
import com.healthcare.dtos.CompleteAppointmentDetails;
import com.healthcare.entities.Appointment;
import com.healthcare.entities.DiagTest;
import com.healthcare.entities.Doctor;
import com.healthcare.entities.Patient;
import com.healthcare.entities.Status;
import com.healthcare.repository.AppointmentRepository;
import com.healthcare.repository.DoctorRepository;
import com.healthcare.repository.PatientRepository;

import lombok.RequiredArgsConstructor;

@Service
@Transactional(readOnly = true)
@RequiredArgsConstructor
public class AppointmentServiceImpl implements AppointmentService {
	// depcy - dao layer
	private final AppointmentRepository appointmentRepository;
	private final DoctorRepository doctorRepository;
	private final PatientRepository patientRepository;
	private final DiagTestRepository diagTestRepository;

	@Override
	public List<AppointmentResp> getPatientsScheduledAppointments(Long patientId) {
		// Invoke dao's method - custom query method with DTO projection
		return appointmentRepository.getPatientUpcomingAppointments(patientId, Status.SCHEDULED);
	}

	@Override
	@Transactional
	public ApiResponse bookNewAppointment(BookAppointment dto) {
		Long doctorId = dto.getDoctorId();
		Long patientId = dto.getPatientId();
		LocalDateTime start = dto.getAppointmentStart();
		// 1. Get doctor details by id
		Doctor doctor = doctorRepository.findById(doctorId)
				.orElseThrow(() -> new ResourceNotFoundException("Invalid doctor id !!!!"));
		// 2. Get patient details by id
		Patient patient = patientRepository.findById(patientId)
				.orElseThrow(() -> new ResourceNotFoundException("Invalid patient ID !!!"));
		// 3. set appointment end time
		LocalDateTime endTime = start.plusMinutes(doctor.getAppointmentTime());
		// 4. check doc's availability
		if (appointmentRepository.existsByMyDoctorIdAndStatusAndStartDateTimeLessThanAndEndDateTimeGreaterThan(doctorId,
				Status.SCHEDULED, endTime, start))
			throw new AppointmentException("Doctor un available !!!!");

		// 5. check patient's availability
		if (appointmentRepository.existsByMyPatientIdAndStatusAndStartDateTimeLessThanAndEndDateTimeGreaterThan(
				patientId, Status.SCHEDULED, endTime, start))
			throw new AppointmentException("Patient un available !!!!");
		// 6 no validation failures -> create appointment
		Appointment appointment = new Appointment(start, endTime);
		// 7.Appointment *<------>1 Doctor
		appointment.setMyDoctor(doctor);
		doctor.getAppointments().add(appointment);
		// 8. Appointment *------>1 Patient
		appointment.setMyPatient(patient);
		// NO need of calling explicitly appRepo.save(app) - doctor -> app :
		// CascadeType.ALL

		return new ApiResponse("Success", "Booked Patient's appointment!");
	}

	@Override
	@Transactional
	public ApiResponse completeAppointmentByDoctor(CompleteAppointment dto) {
		Long appointmentId = dto.getAppointmentId();
		Long doctorId = dto.getDoctorId();
		Set<Long> testIds = dto.getTestIds();
		Appointment appointment = appointmentRepository.findById(appointmentId)
				.orElseThrow(() -> new ResourceNotFoundException("Appointment not found : invalid id"));
		if (!appointment.getMyDoctor().getId().equals(doctorId))
			throw new InvalidInputException("Appointment does not belong to this doctor!!!");
		if (appointment.getStatus() != Status.SCHEDULED || appointment.getEndDateTime().isAfter(LocalDateTime.now()))
			throw new InvalidInputException(
					"Only scheduled appointments whose consultation is done , can be completed!!!");
		appointment.setStatus(Status.COMPLETED);		
		if (!testIds.isEmpty()) {
			// If any diag tests are prescribed - add the same
			List<DiagTest> prescribedTests = diagTestRepository.findAllById(testIds);
			appointment.getDiagTests().addAll(prescribedTests);
		}
		return new ApiResponse("Success", "Appointment Completed !!");
	}
	
	@Override
	public List<CompleteAppointmentDetails> getAllAppointments() {
		// TODO Auto-generated method stub
		return appointmentRepository.getAllAppointments();
	}

}
