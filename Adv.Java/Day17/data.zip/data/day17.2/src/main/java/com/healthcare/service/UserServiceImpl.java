package com.healthcare.service;

import org.modelmapper.ModelMapper;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.healthcare.custom_exceptions.AuthenticationException;
import com.healthcare.dtos.ApiResponse;
import com.healthcare.dtos.AuthRequest;
import com.healthcare.dtos.AuthResponse;
import com.healthcare.entities.User;
import com.healthcare.repository.UserRepository;

import lombok.RequiredArgsConstructor;

@Service
@Transactional(readOnly = true)
@RequiredArgsConstructor //init final fields
public class UserServiceImpl implements UserService {
	//depcy - using constr based D.I
	private final UserRepository userRepository;
	//depcy - ModelMapper
	private final ModelMapper mapper;
	private final PasswordEncoder encoder;

	@Override
	public AuthResponse authenticate(AuthRequest request) {
		//1. invoke repo's method -> get user
		User entity=userRepository.findByEmailAndPassword(request.getEmail(), request.getPassword()).orElseThrow(() -> new AuthenticationException("Invalid email or passwrd!!!!"));
		//2. => login successful -> entity -> dto
//		AuthResponse resp=new AuthResponse();
//		resp.setFirstName(entity.getFirstName());
//		resp.setLastName(entity.getLastName());
//		resp.setId(entity.getId());
//		resp.setUserRole(entity.getUserRole());
		AuthResponse resp = mapper.map(entity,AuthResponse.class);
		resp.setMessage("Successful login !!!!");
		return resp;
	}

	@Override
	@Transactional
	public ApiResponse encryptPasswords() {
		userRepository.findAll() //List<User>
		.stream() //Stream<User>
		.forEach(user -> user.setPassword(encoder.encode(user.getPassword())));
		return new ApiResponse("Success", "Password encoded");
	}
	

}
