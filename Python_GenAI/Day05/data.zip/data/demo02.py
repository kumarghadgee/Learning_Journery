from langchain.chat_models import init_chat_model
from langchain.agents import create_agent
from dotenv import load_dotenv
from langchain.tools import tool
import requests
import os
import json
from ollama import Client
from datetime import datetime

load_dotenv()

@tool
def get_current_weather(city: str) -> str:
    """
    Get the current weather for a specified city.

    Use this tool when you need the latest weather conditions for a city.
    The input should be the city name (optionally including the country code,
    e.g., "London,GB" or "Paris,FR") to avoid ambiguity.
    Returns weather in JSON format.
    """
    try:
        api_key = os.getenv("OPENWEATHER_API_KEY")
        url = f"https://api.openweathermap.org/data/2.5/weather?appid={api_key}&units=metric&q={city}"
        response = requests.get(url)
        response.raise_for_status()
        return response.text
    except Exception as e:
        return json.dumps({"ERROR": str(e)})

@tool
def solve_arithmetic_expression(expr: str) -> str:
    """
    Evaluate a basic arithmetic expression and return the result.

    Use this tool to perform arithmetic calculations involving numbers and
    standard operators such as +, -, *, /, %, **, and parentheses.

    Note: This tool is intended only for arithmetic expressions and should NEVER
        be used for executing arbitrary Python code.
    """
    try:
        res = eval(expr)
        return str(res)
    except:
        return "Error"

# answer = solve_arithmetic_expression("2 + 3 * (4 - 1)")
# print("arithmetic expr answer:", answer)

@tool
def web_search(query: str) -> str:
    """
    Search the live web using Ollama's official search engine. 
    Use this tool to find real-time facts, current events, or updated documentation.
    Tool returns result in JSON format.
    """
    try:
        client = Client()
        response = client.web_search(query, max_results=2)
        results = []
        for result in response.results:
            results.append({
                "title": result.title,
                "url": result.url,
                "content": result.content
            })
        return json.dumps(results)
    except Exception as e:
        return json.dumps({"ERROR", str(e)})

@tool
def get_current_date_time() -> str:
    """
    Get the current local date and time.

    Use this tool whenever you need information about the current date or time,
    including today's date, current time, day of the week, week number, month,
    year, timezone, or to determine whether a date is in the past or future.

    This tool should also be used for queries such as:
    - "What is today's date?"
    - "What day of the week is it?"
    - "What month is it?"
    - "What year is it?"
    - "What week of the year is this?"
    - "What is the current time?"
    - "What time zone am I in?"

    Returns date & time related fields in JSON format.
    """
    now = datetime.now().astimezone()
    iso = now.isocalendar()

    return json.dumps(
        {
            "iso_datetime": now.isoformat(),
            "date": now.strftime("%Y-%m-%d"),
            "time": now.strftime("%H:%M:%S"),
            "weekday": now.strftime("%A"),
            "day": now.day,
            "month": now.month,
            "month_name": now.strftime("%B"),
            "year": now.year,
            "week_of_year": iso.week,
            "day_of_year": now.timetuple().tm_yday,
            "timezone": now.tzname(),
        }
    )

SYSTEM_PROMPT="""
    You are helpful assistant. You have given access to a few useful tools.
    Prefer a tool only if it directly answers the user's request.
    If no suitable tool found, then answer using your internal knowledge.
"""
llm = init_chat_model("groq:openai/gpt-oss-120b")
TOOLS = [
    solve_arithmetic_expression,
    get_current_weather,
    web_search,
    get_current_date_time
]
agent = create_agent(model=llm, tools=TOOLS, system_prompt=SYSTEM_PROMPT)

while True:
    user_prompt = input("\nAsk anything: ")
    if user_prompt == "exit":
        break
    result = agent.invoke({
        "messages": [
            {"role": "user", "content": user_prompt}
        ]
    })
    for msg in result["messages"]:
        print(msg, "\n", "-" * 60)
    ai_msg = result["messages"][-1]
    print("Answer:", ai_msg.content)
    print("=" * 60)
