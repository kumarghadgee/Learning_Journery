Inter MS communication
- synchronus communication
- Open Feign Client + Client side load balancing with Eureka Client
- Spring Cloud framework
 - ServiceRegistry

