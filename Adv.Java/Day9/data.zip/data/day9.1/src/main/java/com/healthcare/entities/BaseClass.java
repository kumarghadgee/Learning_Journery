package com.healthcare.entities;

import java.time.LocalDate;
import java.time.LocalDateTime;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import jakarta.persistence.Column;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.MappedSuperclass;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
/*
 * @MappedSuperclass
 * - Declares a supe class
 * - not an entity
 * - no table
 * - all entities will extend from this base class
 */
@MappedSuperclass  
@Getter
@Setter
@ToString
public class BaseClass {
	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Long id;
	@CreationTimestamp
	@Column(name = "created_on")
	private LocalDate createdOn;
	@Column(name = "last_updated")
	@UpdateTimestamp
	private LocalDateTime lastUpdated;

}
