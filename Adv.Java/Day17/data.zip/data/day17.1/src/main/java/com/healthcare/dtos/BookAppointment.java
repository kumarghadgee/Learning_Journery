package com.healthcare.dtos;

import java.time.LocalDateTime;

import jakarta.validation.constraints.Future;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor //given only for testing purpose
public class BookAppointment {
	@NotNull(message = "Patient id is required")
	private Long patientId;
	@NotNull(message = "Doctor id is required")
	private Long doctorId;
	@NotNull(message = "appointment start date time is required")
	@Future(message ="start date time must be in future" )
	private LocalDateTime appointmentStart;
}
