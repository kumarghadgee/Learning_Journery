# variable scope

num1 = 10 # global var -- accessible outside fn and inside fn (in that file)
def func1():
    print("func1() --> num1 =", num1)

func1()
print("global access --> num1 = ", num1)

def func2():
    num2 = 20 # local var -- accessible only inside fn
    print("func2() --> num2 =", num2)

func2()
# print("global access --> num2 = ", num2) # NameError: name 'num2' is not defined

num3 = 30   # global var
def func3():
    num3 = 40 # create a new local var -- do not modify global var directly
    print("func3() --> num3 =", num3) # 40

func3()
print("global access --> num3 = ", num3) # 30


num4 = 50   # global var
def func4():
    global num4 # we want to modify global var inside fn
    num4 = 60 # modify the global var num4
    print("func4() --> num4 =", num4) # 60

func4()
print("global access --> num4 = ", num4) # 60
