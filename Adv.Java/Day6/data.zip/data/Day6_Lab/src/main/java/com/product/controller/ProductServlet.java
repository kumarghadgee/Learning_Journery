package com.product.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

import com.product.dao.ProductDao;
import com.product.dao.ProductDaoImpl;
import com.product.entities.Product;

/**
 * Servlet implementation class ProductServlet
 */
@WebServlet("/products")
public class ProductServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
  
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String categoryIdParam = request.getParameter("categoryId");
		long categoryId = Long.parseLong(request.getParameter(categoryIdParam));
		
		ProductDao dao = null;
		try {
			dao = new ProductDaoImpl();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
		List<Product> products = dao.getProductsByCategory(categoryId);
		
		request.setAttribute("products", products);
		
		request.getRequestDispatcher("/WEB-INF/views/product.jsp").forward(request, response);
	}
	
	@Override
	protected void doGet(HttpServletRequest request,HttpServletResponse response) throws ServletException,IOException{
		doPost(request,response);
	}

}
