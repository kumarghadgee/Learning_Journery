package com.cdac.dependent;

import com.cdac.dependency.Coach;
import com.cdac.dependency.Teacher;

/*
 * School
 * - mandatory dependencies
 *  - funds (long)
 *  - Teacher
 *  
 * - optional dependency
 *  - Sports coach
 */
public class PublicSchool implements School {
	private Teacher subjectTeacher;
	private Coach sportsCoach;
	private long funds;

	// constructor based D.I
	public PublicSchool(long funds,Teacher myTeacher) {
		System.out.println("In constructor - " + getClass());
		this.funds=funds;
		this.subjectTeacher = myTeacher;
	}

	// B.L method
	@Override
	public void manageAcademics() {
		System.out.println("Managing academics here -");
		subjectTeacher.teach();
	}

	@Override
	public void organizeSportsEvent() {
		System.out.println("Organizing Sports Event - ");
		System.out.println(sportsCoach.getDailyWorkout());		
	}
	
	

	@Override
	public void checkFunds() {
		System.out.println("School funds - "+this.funds);
		
	}

	public void myInit() {
		System.out.println("in init");
	}

	public void myDestroy() {
		System.out.println("in destroy");
	}
	//setter Based D.I

	public void setSportsCoach(Coach myCoach) {
		System.out.println("in setter - coach");
		this.sportsCoach = myCoach;
	}
	
	
	

}
