import java.util.Scanner;

class mul
{
    Scanner sc = new Scanner(System.in);
    public void tab()
    {
        System.out.print("Please Enter the Number of Table you want : ");
        int n = sc.nextInt();
        int m = 1;

        for(int i = 1 ; i <= 10 ; i++)
        {
            m = n * i;
            System.out.println(n + " x " + i + " = " + m);
        }
    }
}

public class table {
    public static void main(String[] args) {
        mul m = new mul();
        m.tab();
    }
}
