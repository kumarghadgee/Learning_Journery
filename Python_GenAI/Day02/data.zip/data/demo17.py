
# input a path from user and display its contents.

def ex01():
    try:
        path = input("enter file path: ")
        with open(path) as file:
            text = file.read()
            print(text)
    except:
        print("Some error occured!")

# ex01()


def ex02():
    try:
        path = input("enter file path: ")
        with open(path) as file:
            text = file.read()
            print(text)
    except Exception as e:
        print("ERROR type:", type(e))
        print("ERROR:", str(e))

# ex02()

def ex03():
    try:
        path = input("enter file path: ")
        with open(path) as file:
            text = file.read()
            print(text)
    except FileNotFoundError as e:
        print(f"File Not Found: {path}")
    except Exception as e:
        print("ERROR type:", type(e))
        print("ERROR:", str(e))
    finally:
        print("Bye!")

ex03()
