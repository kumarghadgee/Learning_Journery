package com.demo.inventory.service;

import java.util.List;

import com.demo.inventory.dto.InventoryResponse;
import com.demo.inventory.dto.StockRequest;

public interface InventoryService {
	InventoryResponse checkStock(String skuCode, int requestedQty);

	List<InventoryResponse> checkStockBulk(List<String> skuCodes);

	void deductStock(StockRequest request);

}
