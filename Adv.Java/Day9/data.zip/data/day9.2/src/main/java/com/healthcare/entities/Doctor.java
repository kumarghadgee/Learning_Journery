package com.healthcare.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.MapsId;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "doctors")
//@AttributeOverride(name = "id", column = @Column(name = "doctor_id"))
//Lombok
@NoArgsConstructor
@Getter
@Setter
@ToString(exclude ="userDetails" ,callSuper = true)
public class Doctor extends BaseClass {
//doctor specific fields
	private String qualifications;
	private String speciality;
	@Column(name = "experience_in_years")
	private int experienceInYears;
	@Column(name = "appointment_time")
	private int appointmentTime;// in minutes
	private int fees;
	// Doctor 1------>1 User (uni dir one to one association)
	@OneToOne // mandatory - otherwise - MappingException
	@JoinColumn(name = "doctor_id")
	@MapsId
	private User userDetails;
	public Doctor(String qualifications, String speciality, int experienceInYears, int appointmentTime, int fees) {
		super();
		this.qualifications = qualifications;
		this.speciality = speciality;
		this.experienceInYears = experienceInYears;
		this.appointmentTime = appointmentTime;
		this.fees = fees;
	}
	
}
