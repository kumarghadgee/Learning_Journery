package com.healthcare.dtos;

import com.healthcare.entities.BloodGroup;
import com.healthcare.entities.Gender;

import lombok.Getter;
import lombok.Setter;
@Getter
@Setter
public class PatientResp {
	private Gender gender;
	private BloodGroup bloodGroup;
	private String familyHistory;

}
