package com.demo.order.service;

import java.util.List;
import java.util.UUID;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.demo.order.dto.OrderRequest;
import com.demo.order.dto.OrderResponse;
import com.demo.order.entity.Order;
import com.demo.order.repository.OrderRepository;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@RequiredArgsConstructor
@Slf4j
@Transactional
public class OrderServiceImpl implements OrderService {
	private final OrderRepository orderRepository;
	private final ModelMapper mapper;
	
	

	public OrderResponse placeOrder(OrderRequest request) {
		// generate random UUID (Universally unique identifier) - 36 characters
		String orderNum = "ORD-" + UUID.randomUUID().toString();
		log.info("Processing order {} for SKU: {}", orderNum, request.getSkuCode());

		/*
		 * 0. Create new order with OrderRequest details & status=Pending
		 *  1. Check stock
		 * by making a call to Inventory Service (MS call) 2. If available - set status
		 * : Confirmed , compute total price deduct the stock (by making another call to
		 * Inventory MS) 3. If un available - Create new Order - with status -Out Of
		 * Stock
		 */
		String skuCode = request.getSkuCode();
		int quantity = request.getQuantity();
		
		/*
		 * 1. MS call to Inventory Service to check the stock
		 * 2. If inventory item is in stock , then create Order
		 * 3. Set customer name , order number , quantity , product sku code
		 * 4. From Inventory response 
		 *  - set product name
		 *  - compute & set total price
		 *  5. Set order status - Confirmed
		 *  6. Make another call to  Inventory MS
		 *   -> to deduct the stock
		 *  7. Save the order in DB
		 *  8. Map Order entity -> DTO & send it to controller.
		 */
		
		
		return null;

	}

	public List<OrderResponse> getAllOrders() {
		return orderRepository.findAll()
				.stream()
				.map(order -> mapper.map(order, OrderResponse.class))
				.toList();
	}

	public OrderResponse getOrderById(Long id) {

		Order order = orderRepository.findById(id)
				.orElseThrow(() -> new RuntimeException("Order not found: " + id));
		return mapper.map(order, OrderResponse.class);
	}
}
