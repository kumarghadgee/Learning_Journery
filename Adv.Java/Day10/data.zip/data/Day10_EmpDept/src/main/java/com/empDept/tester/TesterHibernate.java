package com.empDept.tester;

import org.hibernate.SessionFactory;

import com.empDept.utils.HibernateUtils;

public class TesterHibernate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try(SessionFactory sf = HibernateUtils.getSessionFactory())
		{
			System.out.println("Hibernate up & running....");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}
