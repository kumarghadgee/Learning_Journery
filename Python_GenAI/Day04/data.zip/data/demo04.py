
# UI Chatbot

import os
from groq import Groq
import streamlit as st
from dotenv import load_dotenv

load_dotenv()
GROQ_MODEL = "llama-3.1-8b-instant"
GROQ_API_KEY = os.getenv("GROQ_API_KEY")
client = Groq(api_key=GROQ_API_KEY)

st.title("Sunbeam Chatbot")

user_prompt = st.chat_input("Ask anything?")
if user_prompt:
    response = client.chat.completions.create(
                        model=GROQ_MODEL,
                        messages=[{"role": "user", "content": user_prompt}],
                        temperature=1.0,
                        max_completion_tokens=1000,
                        stream=True
                    )
    with st.chat_message(name="user"):
        st.write(user_prompt)
    with st.chat_message(name="assistant"):
        answer = (chunk.choices[0].delta.content for chunk in response if chunk.choices[0].delta.content)
        st.write_stream(answer)
