# collections
#   list -- [ e1, e2, e3, ... ] -- ordered collection -- may have duplicates -- can modify elems
def ex01():
    nums = [11, 22, 33, 22, 44]
    print("nums =", nums, " -- type =", type(nums)) # class 'list'
    print("nums size = ", len(nums)) # 5
    nums.append(55)
    for val in nums:
        print(val, end=", ")
    nums.remove(33)
    print("\nnums =", nums)

# ex01() # fn call

def ex02():
    # python collection may have values of different types 
    values = [11, 3.14, "Python", False, None]
    # modify element by position
    values[0] = 22
    # display elements using index -- collection[index]
    for i in range(len(values)):
        print(f"ele {i} =", values[i])

# ex02()

#   tuple -- ( e1, e2, e3, ... ) -- ordered collection -- may have duplicates -- cannot modify elems i.e. immutable

def ex03():
    # tuple
    names = ("India", "USA", "Africa", "Spain")
    print("names =", names, " -- of type ", type(names))
    print("0th elem of tuple =", names[0]) # India
    # names[0] = "Bharat" # tuples are immutable -- cannot modify -- TypeError

# ex03()

#   set -- { e1, e2, e3, ... } -- unordered collection -- cannot have duplicates -- can modify elems
def ex04():
    fruits = {"Orange", "Banana", "Mango", "Watermelon", "Orange"}
    print("fruits =", fruits, " -- type =", type(fruits))
    fruits.add("Grapes")
    print("fruits =", fruits)
    # print("0th fruit =", fruits[0]) # cannot access/modify elems by index
    for item in fruits:
        print(item)

# ex04()

#   dict -- { k1:v1, k2:v2, ... } -- key-value pairs i.e. hash table -- faster searching -- key cannot be duplicated
def ex05():
    info = {
        "llm_name": "GPT-5.0",
        "llm_provider": "OpenAI",
        "temperature": 0.7,
        "max_tokens": 1000
    }
    print("llm info =", info, " -- type =", type(info))
    info["temperature"] = 1.0 # modify value of the key
    print("llm temperature =", info["temperature"]) # access value of the key
    # print("provider =", info["provider"]) # KeyError -- when key is not found
    print("provider =", info.get("provider")) # returns None when key is not found
    print("provider =", info.get("provider", "unknown")) # returns given default value when key is not found 
    info["params"] = "120b" # add new key-value pair, if key is not available
    # for kv in info.items(): # kv is tuple (key,value)
        # print(kv[0], " --> ", kv[1])
    # for kv in info.items():
        # key, value = kv  # tuple destructuring -- key<=kv[0], value=kv[1]
        # print(key, " --> ", value)
    for k, v in info.items():
        print(k, "=>", v)

ex05()