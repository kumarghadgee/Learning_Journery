# Python Web Programming -- Simplest option = streamlit
# activate venv and install streamlit
#   cmd> pip install streamlit
# to execute the program
#   cmd> streamlit run app.py

import streamlit as st
import requests
import os
from dotenv import load_dotenv

load_dotenv() # read settings from .env file as OS env variables
WEATHER_API_KEY = os.getenv("WEATHER_API_KEY")
INPUT_PROMPT = os.getenv("INPUT_PROMPT")

def get_weather(city):
    try:
        url = "https://api.openweathermap.org/data/2.5/weather"
        params = {
            "q": city,
            "appid": WEATHER_API_KEY,
            "units": "metric"
        }
        resp = requests.get(url, params)
        resp.raise_for_status()
        return resp.text
    except Exception as e:
        print("ERROR:", e)
        return str(e)

st.title("Sunbeam Weather")
st.subheader("Sunbeam Karad Feb 2026")
city = st.chat_input("Tell me your city.")
if city:
    weather = get_weather(city)
    st.json(weather)
