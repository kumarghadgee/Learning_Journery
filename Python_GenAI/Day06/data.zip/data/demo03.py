# Knowledge Builder
#   Read PDF pages --> Embeddings --> Chromadb

from langchain_community.document_loaders import PyPDFLoader
from langchain.embeddings import init_embeddings
import chromadb

loader = PyPDFLoader("exploration-cbse-ix.pdf")
documents = loader.load()
print("Number of docs:", len(documents)) # 292 docs = 292 pages


embed_model = init_embeddings(model="ollama:nomic-embed-text")

pages = [doc.page_content for doc in documents]
page_infos = [doc.metadata for doc in documents]
page_ids = ["page-"+doc.metadata['page_label'] for doc in documents]
embeddings = embed_model.embed_documents(pages)

# sample = 20
# print("Page Id:", page_ids[sample])
# print("Page Metadata:", page_infos[sample])
# print("Page Content:", pages[sample])
try:
    DB_DIR_PATH="my_chroma_db"
    db = chromadb.PersistentClient(DB_DIR_PATH)

    COLLECTION="science-book-ix"
    collection = db.get_or_create_collection(COLLECTION)

    collection.add(ids=page_ids, embeddings=embeddings, metadatas=page_infos, documents=pages)
    print(f"Documents Saved in ChromaDb:", len(embeddings))
except Exception as e:
    print("ERROR:", e)
