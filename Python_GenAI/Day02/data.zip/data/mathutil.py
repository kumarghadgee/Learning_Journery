
PI = 3.14

def add(a, b):
    return a + b

def subtract(a, b):
    return a - b

def multiply(a, b):
    return a * b

if __name__ == "__main__":
    print("in mathutil module: module name =", __name__)
    res1 = add(22, 7)
    print(f"res1 = {res1}")
    res2 = subtract(22, 7)
    print(f"res2 = {res2}")
    res3 = multiply(22, 7)
    print(f"res3 = {res3}")
