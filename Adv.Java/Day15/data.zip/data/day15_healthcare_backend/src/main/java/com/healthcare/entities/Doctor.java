package com.healthcare.entities;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.MapsId;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "doctors")
//@AttributeOverride(name = "id", column = @Column(name = "doctor_id"))
//Lombok
@NoArgsConstructor
@Getter
@Setter
@ToString(exclude ={"userDetails","appointments"} ,callSuper = true)
public class Doctor extends BaseClass {
//doctor specific fields
	private String qualifications;
	private String speciality;
	@Column(name = "experience_in_years")
	private int experienceInYears;
	@Column(name = "appointment_time")
	private int appointmentTime;// in minutes
	private int fees;
	// Doctor 1------>1 User (uni dir one to one association)
	@OneToOne(cascade = CascadeType.ALL,fetch = FetchType.LAZY) // mandatory - otherwise - MappingException
	@JoinColumn(name = "doctor_id")
	@MapsId //doctor_id - PK + FK -> references PK of users table
	private User userDetails;
	//Doctor 1---->* Appointment(s)
	@OneToMany(mappedBy = "myDoctor", cascade = CascadeType.ALL/* ,fetch = FetchType.EAGER */) //mandatory - otherwise MappingException
	private List<Appointment> appointments=new ArrayList<>();
	
	public Doctor(String qualifications, String speciality, int experienceInYears, int appointmentTime, int fees) {
		super();
		this.qualifications = qualifications;
		this.speciality = speciality;
		this.experienceInYears = experienceInYears;
		this.appointmentTime = appointmentTime;
		this.fees = fees;
	}
	
}
