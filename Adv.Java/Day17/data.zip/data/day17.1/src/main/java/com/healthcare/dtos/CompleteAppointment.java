package com.healthcare.dtos;

import java.util.Set;

import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CompleteAppointment {
	@NotNull
	private Long appointmentId;
	@NotNull
	private Long doctorId;
	private Set<Long> testIds;

}
