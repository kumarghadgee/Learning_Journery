package com.healthcare.entities;

import jakarta.persistence.AttributeOverride;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name="diag_tests")
@AttributeOverride(name="id" ,column = @Column(name="test_id"))
//Lombok
@NoArgsConstructor
@Getter
@Setter
@EqualsAndHashCode(of="name",callSuper = false)
public class DiagTest extends BaseClass {
	@Column(unique = true)
	private String name;	
	private String description;
	private int cost;
	public DiagTest(String name, String description, int cost) {
		super();
		this.name = name;
		this.description = description;
		this.cost = cost;
	}	
}
