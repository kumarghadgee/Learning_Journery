package com.healthcare.service;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDateTime;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.healthcare.dtos.ApiResponse;
import com.healthcare.dtos.BookAppointment;

@SpringBootTest //scans all the components - controller , service & repos
class AppointmentServiceTest {
	@Autowired
	private AppointmentService appointmentService;

	@Test
	void testBookNewAppointment() {
		BookAppointment dto=new BookAppointment(6l,4l,LocalDateTime.parse("2026-07-23T16:00"));
		ApiResponse response = appointmentService.bookNewAppointment(dto);
		assertEquals(true, response.getMessage().contains("Booked"));
	}

}
