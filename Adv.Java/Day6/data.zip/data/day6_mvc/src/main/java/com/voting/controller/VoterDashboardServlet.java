package com.voting.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import com.voting.dao.CandidateDao;
import com.voting.dao.CandidateDaoImpl;
import com.voting.entities.Candidate;
import com.voting.entities.User;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

/**
 * Servlet implementation class VoterDashboardServlet
 */
@WebServlet(value = "/voter_dashboard", loadOnStartup = 2)
public class VoterDashboardServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private CandidateDao candidateDao;

	@Override
	public void init() throws ServletException {
		try {
			// create candidate dao instance
			candidateDao = new CandidateDaoImpl();
		} catch (Exception e) {
			throw new ServletException("err in init of " + getClass(), e);
		}

	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		try {

			// 1. Get HttpSession from WC
			HttpSession hs = request.getSession(false);
			if (hs != null) {
				// 2. invoke dao's method to get all candidates
				List<Candidate> candidates = candidateDao.getAllCandidates();
				//3. add candidate list under - request scope
				request.setAttribute("candidate_list", candidates);
				//4. forward the client to the view layer
				RequestDispatcher rd=request.getRequestDispatcher("/WEB-INF/views/voter_dashboard.jsp");
				rd.forward(request, response);
			} else {
				response.sendRedirect("/?message=" + "You have to accept the cookie to continue....");
			}
		} catch (Exception e) {
			throw new ServletException("err in doGet " + getClass(), e);
		}
	}

	@Override
	public void destroy() {
		try {
			candidateDao.cleanUp();
		} catch (Exception e) {
			System.out.println("err in destroy " + getClass() + " " + e);
		}
	}

}
