package PracticePatterns;

import java.util.Scanner;

class pattern 
{
	public void star()
	{
		Scanner sc = new Scanner(System.in);
		System.out.print("Please Enter the value of n : ");
		int n = sc.nextInt();
		System.out.print("Please Enter the value of m : ");
		int m = sc.nextInt();
		
		for(int i = 1 ; i <= n ; i++) {
			for(int j = 1 ; j <= m ; j++) {
				if(i == 1 || j == 1 || i == n || j == m) {
					System.out.print("*");
				}
				else {
					System.out.print(" ");
				} 
			}
			System.out.println();
		}
		sc.close();
	}
}

public class demo01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		pattern pt = new pattern();
		pt.star();
	}

}
