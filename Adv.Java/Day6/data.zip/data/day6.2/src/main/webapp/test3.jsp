<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<%@ taglib uri="jakarta.tags.core" prefix="c"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>For Loop</title>
</head>
<body>
	<c:forEach var="index" begin="10" end="20">
		<c:out value="${index}"></c:out>
	</c:forEach>
</body>
</html>