package com.user.pojo;

import java.time.LocalDate;
import java.time.Period;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
public class User {
	private String name;
	private String email;
	private String password;
	private LocalDate dob;
	
	public int getAge() {
		if(this.dob == null) {
			return 0;
		}
		return Period.between(this.dob,LocalDate.now()).getYears();
	}
}


