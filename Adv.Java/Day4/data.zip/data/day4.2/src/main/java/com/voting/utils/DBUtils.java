package com.voting.utils;

import java.sql.*;

public class DBUtils {
//	private  static String dbURL ;//= "jdbc:mysql://localhost:3306/voting";
//	private  static String userName;// = "root";
//	private  static String password;// = "root";
	
	//add static method to return DB connection to the caller
	public static Connection getConnection(String dbURL,String userName,String password) throws SQLException
	{
		return DriverManager.getConnection(dbURL, userName, password);
	}
	
}
