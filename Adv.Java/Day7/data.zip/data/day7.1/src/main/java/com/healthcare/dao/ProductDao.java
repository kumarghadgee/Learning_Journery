package com.healthcare.dao;
import com.healthcare.entities.Product;

public interface ProductDao {
	String addProduct(Product newProduct );
	
}
