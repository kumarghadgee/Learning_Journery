import java.util.PriorityQueue;
import java.util.Scanner;

class largest
{
    Scanner sc = new Scanner(System.in);
    public void kthLargest()
    {
        System.out.println("Please Enter the Size of Array : ");
        int size = sc.nextInt();

        int[] nums = new int[size];

        System.out.println("Please Enter the Element Of "+size + " Array");
        for(int i = 0 ; i < size ; i++)
        {
            System.out.print("Element at " + i + " index : ");
            nums[i] = sc.nextInt();
        }

        System.out.print("Give the Kth Term for finding the kthLargestTerm : ");
        int k = sc.nextInt();

        PriorityQueue<Integer> findKthLargestElement = new PriorityQueue<>();

        for(int num : nums)
        {
            findKthLargestElement.add(num);

            if(findKthLargestElement.size() > k)
            {
                findKthLargestElement.poll();
            }
        }

        System.out.println("The "+ k +" Largest Element "+findKthLargestElement.peek());

        sc.close();
    }
}

public class kThLargest {
    public static void main(String[] args) {
        largest kth = new largest();
        kth.kthLargest();
    }
}
