<%@page import="com.ecommerce.pojos.Product"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
	<h5>From 1st page....</h5>
	<%--Create Product class instance using req params --%>
	<%
	out.flush();
	Product p1 = new Product(Long.parseLong(request.getParameter("pid")), request.getParameter("name"),
			Integer.parseInt(request.getParameter("price")));
	//add product details under request scope
	request.setAttribute("product_details", p1);
	%>
	<%-- forward | include request to test10.jsp --%>
	<jsp:include page="test10.jsp">
		<jsp:param value="stationary" name="category" />
	</jsp:include>
	<h5>Contents from 1st page after include ...</h5>
</body>
</html>