# activate current venv.
# cmd> pip install requests

import requests
def ex01():
    try:
        url = "https://nilesh-g.github.io/learn-web/data/novels.json"
        resp = requests.get(url)
        resp.raise_for_status() # throw exception if status is not 2xx
        print(resp.content) # resp.content raw byte array response
    except Exception as e:
        print("ERROR:", e)

# ex01()

def ex02():
    try:
        url = "https://nilesh-g.github.io/learn-web/data/novels.json"
        resp = requests.get(url)
        resp.raise_for_status() # throw exception if status is not 2xx
        print(resp.text) # resp.text is text data response
    except Exception as e:
        print("ERROR:", e)

# ex02()

def ex03():
    try:
        url = "https://nilesh-g.github.io/learn-web/data/novels.json"
        resp = requests.get(url)
        resp.raise_for_status() # throw exception if status is not 2xx
        print(resp.json()) # resp.json() convert json response into python list, dict, or other suitable object
    except Exception as e:
        print("ERROR:", e)

ex03()

