import pandas as pd

file_path = r"D:\Nilesh\Feb26\K-PG-AC\gen-ai\day03\products.csv"
df = pd.read_csv(file_path)
print("df type:", type(df), "\n")

df.info() # print df metadata
print(f"\ndf columns info:\n{df.dtypes}")

print("\nproducts data:")
print(df)
