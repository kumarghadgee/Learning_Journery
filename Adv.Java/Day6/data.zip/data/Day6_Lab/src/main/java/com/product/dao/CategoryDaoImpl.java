package com.product.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.product.entities.Category;
import com.product.utilis.DButilis;

public class CategoryDaoImpl implements CategoryDao{
	private Connection connection;
	private PreparedStatement pst1;
	
	public CategoryDaoImpl() throws SQLException{
		connection=DButilis.getConnection();
		pst1=connection.prepareStatement("SELECT * FROM categories");
	}
	
	@Override
	public void cleanUp() throws SQLException{
		if(pst1 != null) {
			pst1.close();
		}
		
		if(connection != null) {
			connection.close();
		}
		
		System.out.println("CategoryDao is Closed");
	}
	
	@Override
	public List<Category> getAllProductsByCategories(){
		List<Category> categoryList = new ArrayList<>();
		try {
			
			ResultSet rs = pst1.executeQuery();
		
			while(rs.next()) {
				Category category = new Category();
				category.setCategoryId(rs.getLong("category_id"));
				category.setCategoryName(rs.getString("category_name"));
				category.setDescription(rs.getString("description"));
				
				categoryList.add(category);
			}
//			rs.close();
//			pst1.close();
		} 
		catch(Exception e) 
		{
			e.printStackTrace();
		}
		return categoryList;
	}
}
