package com.healthcare.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.healthcare.dtos.AppointmentResp;
import com.healthcare.entities.Status;
import com.healthcare.repository.AppointmentRepository;

import lombok.RequiredArgsConstructor;

@Service  //Mandatory 
@Transactional(readOnly = true)
@RequiredArgsConstructor
public class AppointmentServiceImpl implements AppointmentService {
	//depcy - dao layer
	private final AppointmentRepository appointmentRepository;

	@Override
	public List<AppointmentResp> getPatientsScheduledAppointments(Long patientId) {
		// Invoke Dao's Method - custom query method with DTO Projection
		return appointmentRepository.getPatientUpcomingAppointments(patientId,Status.SCHEDULED);
	}

}
