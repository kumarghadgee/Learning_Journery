package com.healthcare.service;

import java.util.List;

import com.healthcare.dtos.ApiResponse;
import com.healthcare.dtos.AppointmentResp;
import com.healthcare.dtos.BookAppointment;
import com.healthcare.dtos.CompleteAppointment;
import com.healthcare.dtos.CompleteAppointmentDetails;

public interface AppointmentService {
//add a method to list patient's upcoming(scheduled) appointments
	List<AppointmentResp> getPatientsScheduledAppointments(Long patientId);

	ApiResponse bookNewAppointment(BookAppointment dto);
	ApiResponse completeAppointmentByDoctor(CompleteAppointment dto);
	List<CompleteAppointmentDetails> getAllAppointments();
}
