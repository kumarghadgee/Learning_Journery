package myPractice;

class pattern1
{
	public void star()
	{
		for(int i = 1; i <= 5; i++) 
		{
			for(int j = 1; j <= i ; j++) {
				System.out.print("* ");
			}
			System.out.println();
		}
	}
}

public class demo02 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		pattern1 pt = new pattern1();
		pt.star();
	}

}
