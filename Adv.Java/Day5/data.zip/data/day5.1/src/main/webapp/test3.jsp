<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<%!int visits; //instance var - current page only
    //overriding jsp life cycle method
	public void jspInit() {
		System.out.println("in jspInit " + Thread.currentThread());
	}
	//java method
	int refresh() {
		return ++visits;
	}%>
	<h5>
	Visits -
	<%=refresh()%></h5>
	<%
	System.out.println("");	
	%>
	<!-- whatever we want to render need to put it in body -->
<body>
	<%
	System.out.println("in _jspService " + Thread.currentThread());
	%>
</body>
<%!public void jspDestroy() {
		System.out.println("in jspDestory " + Thread.currentThread());
	}%>

</html>