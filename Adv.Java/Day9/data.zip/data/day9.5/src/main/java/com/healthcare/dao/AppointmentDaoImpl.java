package com.healthcare.dao;

import java.time.LocalDateTime;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.healthcare.utils.HibernateUtils;

public class AppointmentDaoImpl implements AppointmentDao {

	@Override
	public String bookAppointment(Long patientId, Long doctorId, LocalDateTime appointmentStart) {
		String mesg = "Failed";
		// 1. Get Session from SessionFactory
		Session session = HibernateUtils.getSessionFactory().getCurrentSession();
		// 2. Begin a Transaction
		Transaction tx = session.beginTransaction();
		try {
			tx.commit();
			mesg = "Appointment booked with ID ";
		} catch (RuntimeException e) {
			if (tx != null) {
				tx.rollback();
			}
			// re throw the same exception to the caller
			throw e;
		}
		return mesg;
	}

}
