package com.healthcare.dtos;
import com.healthcare.entities.BloodGroup;
import com.healthcare.entities.Gender;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
@Getter
@Setter
@ToString
public class PatientRegDTO {
	@Valid //IMPORTANT - to enable cascading of validations
	private UserRegDTO userDetails;
	@NotNull
	private Gender gender;
	@NotNull
	private BloodGroup bloodGroup;
	@NotBlank
	@Size(max = 500)
	private String familyHistory;
}
