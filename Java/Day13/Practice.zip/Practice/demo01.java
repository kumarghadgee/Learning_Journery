import java.util.Scanner;

class Armstrong
{
    Scanner sc = new Scanner(System.in);
    public void arm()
    {
        System.out.print("Enter the number to whether the Number is Armstrong : ");
        int a = sc.nextInt();
        int b = a;
        int sum = 0;
        while(a > 0){
            int m = a % 10;
            sum += m*m*m;
            a /= 10;
        }

            if(sum == b)
            {
                System.out.println("Entered Number is ARMSTRONG...");
            }
            else
            {
                System.out.println("Entered Number is NOT ARMSTRONG...");
            }

        sc.close();
    }
}

public class demo01{
    public static void main(String[] args) {
        Armstrong as = new Armstrong();
        as.arm();
    }
}   