package com.ems.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ems.entities.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {
//derived Query
	List<Employee> findByMyDepartmentIdAndStatusTrue(Long deptId);
}
