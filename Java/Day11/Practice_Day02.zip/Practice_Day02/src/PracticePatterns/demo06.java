package PracticePatterns;

import java.util.Scanner;

class pattern6
{
	public void star()
	{
		Scanner sc = new Scanner(System.in);
		System.out.print("Please Enter the value of n : ");
		int n = sc.nextInt();
		
		for(int i = 1 ; i <= n ; i++) {
			for(int j = 1 ; j <= i ; j++) {
				if((i + j) % 2 == 0) {
					System.out.print("1");
				}
				else {
					System.out.print("0");
				}
			}
			System.out.println();
		}
		sc.close();
	}
}

public class demo06 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		pattern6 pt = new pattern6();
		pt.star();
	}

}
