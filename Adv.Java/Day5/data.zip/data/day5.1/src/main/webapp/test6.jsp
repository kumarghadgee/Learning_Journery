<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8" %>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
	<%
	int result = Integer.parseInt("asdfg12345");
	%>
</body>
<h5>
	Result -
	<%=result%></h5>
</html>