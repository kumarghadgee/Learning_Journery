# from langchain_ollama import OllamaEmbeddings
from langchain.embeddings import init_embeddings
from sklearn.metrics.pairwise import cosine_similarity

# init_embeddings() can load any embedding model
sentences = [
    "I love football",
    "Soccer is my favorite sports",
    "Messi talks Spanish"
]

embed_model = init_embeddings(model="ollama:nomic-embed-text")

embeddings = embed_model.embed_documents(sentences)
for i in range(len(embeddings)):
    print(sentences[i], f": vect len = {len(embeddings[i])} -> ", embeddings[i][:4])

print("stmt1 - stmt2 = ", cosine_similarity([embeddings[0]], [embeddings[1]]))
print("stmt1 - stmt3 = ", cosine_similarity([embeddings[0]], [embeddings[2]]))
print("stmt2 - stmt3 = ", cosine_similarity([embeddings[1]], [embeddings[2]]))
