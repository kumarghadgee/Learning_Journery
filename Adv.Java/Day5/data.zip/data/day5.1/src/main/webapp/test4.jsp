<%@page import="com.ecommerce.pojos.Product"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
	<%--Create Product class instance using req params --%>
	<%
	Product p1 = new Product(Long.parseLong(request.getParameter("pid")), request.getParameter("name"),
			Integer.parseInt(request.getParameter("price")));
	//add propduct details under session scope
	session.setAttribute("product_details", p1);
	//display product name & price from the REDIRECTED page
	String encUrl = response.encodeRedirectURL("test5.jsp");
	response.sendRedirect(encUrl);
	%>
</body>
</html>