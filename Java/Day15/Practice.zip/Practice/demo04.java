import java.util.Scanner;

class two
{
    public void pointer()
    {
        Scanner sc = new Scanner(System.in);

        System.out.print("Please Enter the Size of the Array : ");
        int size = sc.nextInt();

        int[] nums = new int[size];

        System.out.println("Enter " + size + " integer value");
        for(int i = 0 ; i < size ; i++)
        {
            System.out.print("Enter Element Value of " + i + "th index : ");
            nums[i] = sc.nextInt();
        }

        for(int i = 0 ; i < nums.length ; i++)
        {
            System.out.print(nums[i] + ", ");
        }
        System.out.println();
        System.out.print("Please Enter the target of sum : ");
        int target = sc.nextInt();

        int left = 0;
        int right = nums.length - 1;

        while(left < right)
        {
            int currentSum = nums[left] + nums[right];

            if(currentSum == target)
            {
                System.out.println(left+","+right);
                break;
            }
            else if(currentSum < target)
            {
                left++;
            }
            else
            {
                right--;
            }
        }
    }
}

public class demo04 {
    public static void main(String[] args) {
        two two = new two();
        two.pointer();
    }
}
