package com.backend.entities;

import jakarta.persistence.AttributeOverride;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
@Table(name="job")
@Entity
@AttributeOverride(name="id",column=@Column(name="job_id"))


public class Job extends BaseEntity {
	/*
	 * id (Long, PK)  - auto increment
-	title 
-	description
-	salary
-	location
-	jobType (enum FULL_TIME / PART_TIME / CONTRACT)
-	postedDate
-        status (enum - AVAILABLE | UNAVAILABLE)
-	company (Many-to-One)
	 */
	
	@Column(length = 30)
	private String title;
	
	@Column(length = 225)
	private String description;
	
	private double salary;
	
	@Column(name="job_type")
	@Enumerated(EnumType.STRING)
	private JobType jobType;
	
	@Column(name="status")
	@Enumerated(EnumType.STRING)
	private PostedDate status;
	
	@ManyToOne
	@JoinColumn(name="company_id",nullable = false)
	private CompanyEntity myCompany;
}
