package com.healthcare.tester;

import java.time.LocalDate;
import java.util.Scanner;

import org.hibernate.SessionFactory;

import com.healthcare.dao.PatientDao;
import com.healthcare.dao.PatientDaoImpl;
import com.healthcare.entities.BloodGroup;
import com.healthcare.entities.Gender;
import com.healthcare.entities.Patient;
import com.healthcare.entities.User;
import com.healthcare.entities.UserRole;
import com.healthcare.utils.HibernateUtils;

public class PatientRegistration {

	public static void main(String[] args) {
		try (Scanner sc = new Scanner(System.in); SessionFactory sf = HibernateUtils.getSessionFactory()) {

			PatientDao patientDao = new PatientDaoImpl();
			System.out
					.println("Enter user details - firstName,  lastName,  email,  password,  dob,  phone,  regAmount");
			// Create transient user (not yet persistent !)
			User user = new User(sc.next(), sc.next(), sc.next(), sc.next(), LocalDate.parse(sc.next()), sc.next(),
					UserRole.ROLE_PATIENT, sc.nextInt());

			System.out.println("Add Patient specific details - gender, BloodGroup bloodGroup");
			Gender gender = Gender.valueOf(sc.next().toUpperCase());
			BloodGroup bloodGroup = BloodGroup.valueOf(sc.next().toUpperCase());
			sc.nextLine();
			System.out.println("Enter Family History");
			Patient patient = new Patient(gender, bloodGroup, sc.nextLine());
			// establish Patient 1--->1 User
			

			System.out.println(patientDao.registerPatient(patient));

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
