package com.demo.order.inventory.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.demo.order.dto.ApiResponse;
import com.demo.order.dto.InventoryResponse;
import com.demo.order.dto.StockRequest;

@FeignClient(name="inventory-service",path="/inventory")
public interface InventoryClient {
//add method call - to check the stock
		 @GetMapping("/check/{skuCode}/{quantity}")
	    public InventoryResponse checkStock123(
	            @PathVariable String skuCode,
	            @PathVariable int quantity);
		//add method call - to reduce stock
		 @PutMapping("/deduct")
		    public ApiResponse deductStock123(
		            @RequestBody StockRequest request);
	 
}
