# RAG Pipeline
#   Question -> Retrieval --> Prompt with Context --> LLM answer

# RAG Agent
#   Agent = LLM + Tool for Retrieval
#   Question -> Agent -> Agent decide whether to call Retrival Tool
#       -> If Retrieval done --> Agent will use the context --> LLM answer

# Agentic RAG
#   Multi-agent system -- Simplest system with 2 Agents
#       Agent1 = Retrieval agent (call the tool to retrieve related pages)
#       Agent2 = Answerer agent (to answer user question)
