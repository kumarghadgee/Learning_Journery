package com.backend.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import com.backend.entities.Restaurants;
import com.backend.service.RestaurantService;

@Controller
public class RestaurantController {
	
	@Autowired
	private RestaurantService restService;
	
	public RestaurantController() {
		System.out.println("In the Ctor : "+getClass());
	}
	
	@GetMapping("/list")
	public List<Restaurants> getAllRestaurant(){
		return null;
		
	}
}
