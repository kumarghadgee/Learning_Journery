# function arguments -- positional args, keyword args

def print_info1(name, age, addr, email):
    print(f"Name: {name}, Age: {age}, Addr: {addr}, Email: {email}")
    # no explicit return -- like void fns in C/Java

# positional args: args are assigned to params by their positions
# print_info1("James Bond", 65, "London", "james@bond.com")

# keyword args: args are assigned to params by their names
# print_info1(name="Superman", addr="Crypton", email="superman@crypton.com", age=876)

# we can combine positional args and keyword args
# print_info1("Batman", 45, email="batman@avengers.com", addr="Gotham")

# we can combine positional args and keyword args --
#   but first give all positional args and then all keyword args
#   otherwise compiler error
# print_info1(name="Batman", 45, email="batman@avengers.com", "Gotham")

# / -- all params before / must passed as positional args
# * -- all params after * must passed as keyword args
def print_info2(name, age, /, *, addr, email):
    print(f"Name: {name}, Age: {age}, Addr: {addr}, Email: {email}")

# print_info2("Batman", 45, email="batman@avengers.com", addr="Gotham")
# Okay: first two args are positional and next 2 are keyword as per expectations -- / and *

# print_info2("Batman", 45, "batman@avengers.com", "Gotham") 
# TypeError: print_info2() takes 2 positional arguments but 4 were given

# print_info2(name="Batman", age=45, email="batman@avengers.com", addr="Gotham")
# TypeError: print_info2() got some positional-only arguments passed as keyword arguments: 'name, age'

# optional params -- like C++/C# default args
def print_info3(name, age, addr="Unknown", email="anonymous@gmail.com"):
    print(f"Name: {name}, Age: {age}, Addr: {addr}, Email: {email}")

print_info3(name="Batman", age=45, email="batman@avengers.com", addr="Gotham")
print_info3(name="Ironman", age=40, email="ironman@avengers.com")
print_info3(name="Hulk", age=75)
