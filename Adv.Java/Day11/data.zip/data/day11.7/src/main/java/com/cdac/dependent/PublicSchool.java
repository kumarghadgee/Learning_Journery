package com.cdac.dependent;

import com.cdac.dependency.Coach;
import com.cdac.dependency.Teacher;

/*
 * School
 * dependencies
 *  
 *  - Teacher 
 *  - Sports coach
 *  autowire=byName
 */
public class PublicSchool implements School {
	private Teacher[] subjectTeachers;
	private Coach[] sportsCoaches;

	public PublicSchool(Teacher[] subjectTeachers, Coach[] sportsCoaches) {
		System.out.println("in ctor " + getClass());
		this.subjectTeachers = subjectTeachers;
		this.sportsCoaches = sportsCoaches;
	}

	// B.L method
	@Override
	public void manageAcademics() {
		System.out.println("Managing academics here -");
		for (Teacher t : subjectTeachers)
			t.teach();
	}

	@Override
	public void organizeSportsEvent() {
		System.out.println("Organizing Sports Event - ");
		for(Coach c : sportsCoaches)
		 System.out.println(c.getDailyWorkout());
	}

	public void myInit() {
		System.out.println("in init");
	}

	public void myDestroy() {
		System.out.println("in destroy");
	}

}
