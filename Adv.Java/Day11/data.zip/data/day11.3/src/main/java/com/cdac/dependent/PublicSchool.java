package com.cdac.dependent;

import com.cdac.dependency.Coach;
import com.cdac.dependency.Teacher;

/*
 * School
 * dependencies
 *  - funds (long)
 *  - Teacher 
 *  - Sports coach
 */
public class PublicSchool implements School {
	private Teacher subjectTeacher;
	private Coach sportsCoach;
	private long funds;

	private PublicSchool() {
		System.out.println("In constructor - " + getClass());
	}

	// B.L method
	@Override
	public void manageAcademics() {
		System.out.println("Managing academics here -");
		subjectTeacher.teach();
	}

	@Override
	public void organizeSportsEvent() {
		System.out.println("Organizing Sports Event - ");
		System.out.println(sportsCoach.getDailyWorkout());
	}

	@Override
	public void checkFunds() {
		System.out.println("School funds - " + this.funds);

	}

	public void myInit() {
		System.out.println("in init");
	}

	public void myDestroy() {
		System.out.println("in destroy");
	}

	// Factory method based D.I
	public static PublicSchool myFactoryMethod(long funds, Teacher myTeacher, Coach myCoach) {
		System.out.println("in factory method");
		//dependent bean
		PublicSchool school=new PublicSchool();
		school.funds=funds;
		school.subjectTeacher=myTeacher;
		school.sportsCoach=myCoach;
		return school;		
	}

}
