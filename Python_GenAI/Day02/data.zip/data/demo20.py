# Python built-in "json" module is used to convert from JSON string to
#   python object (list, dict, str, etc.) and vice-versa.
# JSON string --> json.loads() --> Python object
# Python object --> json.dumps() --> JSON string

import json

BOOK_JSON = """{
    "srno": 1,
    "title": "Chhava",
    "author": "Shivaji Sawant",
    "category": "Historical",
    "price": 450
  }"""

book = json.loads(BOOK_JSON)
print("book type:", type(book))
print("book:", book)

person = {
    "name": "Nilesh",
    "age": 42,
    "address": "Pune"
}
person_json = json.dumps(person)
print("person_json type:", type(person_json))
print("person_json:", person_json)
