package com.product.dao;

import java.util.List;

import com.product.entities.Category;

public interface CategoryDao extends BaseDao {
	List<Category> getAllProductsByCategories();
}
