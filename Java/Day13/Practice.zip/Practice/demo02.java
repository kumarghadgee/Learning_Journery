import java.util.Scanner;

class Neon
{
    Scanner sc = new Scanner(System.in);
    public void neon()
    {
        System.out.print("Please Enter the Number to Check number is Neon : ");
        int a = sc.nextInt();
        int sum = 0;
        int b = a;
        a = a * a;

        while(a > 0)
        {
            int m = a % 10;
            sum += m;
            a /= 10;
        }
            if(sum == b)
            {
                System.out.println("Number is Neon...");
            }
            else
            {
                System.out.println("Number is Not Neon....");
            }
        sc.close();
    }
}

public class demo02 {
    public static void main(String[] args) {
        Neon ne = new Neon();
        ne.neon();
    }
}
