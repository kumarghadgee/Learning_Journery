<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
	<h4 align="center">User Details Via Scriptlet</h4>
	<%
	String email = request.getParameter("em");
	String pwd = request.getParameter("pass");
	out.print("Email " + email + " Password " + pwd);
	//adding page scoped attribute
	pageContext.setAttribute("test", 1000);
	%>
	<h4 align="center">User Details Via Expression</h4>
	<h5>
		Email -
		<%=request.getParameter("em")%></h5>
	<h5>
		Password -
		<%=request.getParameter("pass")%></h5>
	<h4 align="center">User Details Via EL Syntax</h4>
	<h5>Email - ${param.em}</h5>
	<h5>Password - ${param.pass}</h5>
	<h4>Guess the o/p</h4>
	<h5>param - ${param}</h5>
	<h5>cookie - ${cookie}</h5>
	<%--translated page class instance --%>
	<h5>page - <%= page %></h5>
	<h5>pageContext - <%= pageContext %></h5>
	<%-- pageContext.getAttribute("test") --%>
	<h5>page scoped attribute - ${test}</h5>
</body>
</html>