package PracticePatterns;

import java.util.Scanner;

class pattern5
{
	public void star()
	{
		Scanner sc = new Scanner(System.in);
		System.out.print("Please Enter the value of n : ");
		int n = sc.nextInt();
		int k = 1;
		for(int i = 1; i <= n ; i++) {
			for(int j = 1; j <= i ; j++) {
				System.out.print(k+" ");
				k++;
			}
			System.out.println();
		}
		
		sc.close();
	}
}

public class demo05 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		pattern5 pt = new pattern5();
		pt.star();
	}

}
