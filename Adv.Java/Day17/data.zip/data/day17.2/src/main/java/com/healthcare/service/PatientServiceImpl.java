package com.healthcare.service;

import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.healthcare.custom_exceptions.ApiException;
import com.healthcare.custom_exceptions.ResourceNotFoundException;
import com.healthcare.dtos.ApiResponse;
import com.healthcare.dtos.PatientRegDTO;
import com.healthcare.dtos.PatientResp;
import com.healthcare.entities.Patient;
import com.healthcare.entities.User;
import com.healthcare.entities.UserRole;
import com.healthcare.repository.PatientRepository;
import com.healthcare.repository.UserRepository;

import lombok.RequiredArgsConstructor;
@Service
@Transactional(readOnly = true)
@RequiredArgsConstructor
public class PatientServiceImpl implements PatientService {
	//depcy - repo
	private final PatientRepository patientRepository;
	private final ModelMapper mapper;
	private final UserRepository userRepository;
	private final PasswordEncoder passwordEncoder;

	@Override
	public PatientResp getPatientDetails(Long patientId) {
		// 1. Get patient details by id
		Patient entity=patientRepository.findById(patientId) //Optional
				.orElseThrow(() -> new ResourceNotFoundException("Invalid patient id !!!"));
		//2. map entity -> dto
		return mapper.map(entity, PatientResp.class);
				
	}

//	@Override
//	public List<Patient> getAllPatients() {
//		// TODO Auto-generated method stub
//		return patientRepository.findAll();
//	}

	@Override
	public List<PatientResp> getAllPatients() {
		/* Get List<Entity> : findAll - inherited API
		 * Convert  List<Entity> -> List<DTO> 
		 */
		return patientRepository.findAll() //List<Patient>
				    .stream() // Stream<Patient>
				    .map(patient -> mapper.map(patient,PatientResp.class))//Stream<DTO>
				    .toList();

	}
	@Transactional
	public ApiResponse registerNewPatient(PatientRegDTO reqDTO) {
		// 1. validate for dup email or phone
		if(userRepository.existsByEmailOrPhone(reqDTO.getUserDetails().getEmail(),reqDTO.getUserDetails().getPhone()))
			throw new ApiException("Email or Phone alread Exists !!!!!");
		// 2. in case of no dup email -> dto -> entity (deep copy- highlight)
		Patient entity = mapper.map(reqDTO, Patient.class);	
		User userDetails = entity.getUserDetails();
		//3. assign patient role
		userDetails.setUserRole(UserRole.ROLE_PATIENT);
		//4.  encrypt password
		userDetails.setPassword(passwordEncoder.encode(userDetails.getPassword()));
		//3. save patient entity (highlight - JPA cascade)
		Patient persistentEntity=patientRepository.save(entity);//users : insert -> PK -> child rec -> patients : FK		
		//4. ret api resp dto
		return new ApiResponse("New Patient Registered with ID="+persistentEntity.getId(), "Success");
	}

	
	
	

}
