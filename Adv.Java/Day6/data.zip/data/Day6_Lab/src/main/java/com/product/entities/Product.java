package com.product.entities;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString

public class Product {
	//productId,productName,price,stock,categoryId
	//long,String,double,int,int,
	private long productId;
	private String productName;
	private double price;
	private int stock;
	private int categoryId;
}
