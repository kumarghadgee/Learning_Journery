# list comprehension
#   results = [item_expr for item in collection]
#   results = [item_expr for item in collection if item_condition]

# list of dictionary
conversation = [
    {
        "role": "user",
        "content": "What is capital of France?"
    },
    {
        "role": "ai",
        "content": "Paris"
    },
    {
        "role": "user",
        "content": "What is famous there?"
    },
    {
        "role": "ai",
        "content": "Eifel Tower"
    }
]

# get all the prompts (only contents) in a separate list
prompts = list() # or [ ]
for msg in conversation:
    prompt = msg["content"]
    prompts.append(prompt)

print("only prompts:", prompts)

# list comprehension
prompts = [msg["content"] for msg in conversation]
print("only prompts:", prompts)

# get all prompt roles in capital case in another list
roles = [msg["role"].upper() for msg in conversation]
print("only roles:", roles)

# get all prompts only by "user" role
user_prompts = [ ]
for msg in conversation:
    if msg["role"] == "user":
        user_prompts.append(msg["content"])

print("user prompts:", user_prompts)

# get all prompts only by "ai" role
ai_prompts = [msg["content"] for msg in conversation if msg["role"] == "ai"]
print("ai prompts:", ai_prompts)
