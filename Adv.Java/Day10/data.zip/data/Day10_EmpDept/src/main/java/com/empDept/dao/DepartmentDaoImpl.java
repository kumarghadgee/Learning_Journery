package com.empDept.dao;

import org.hibernate.Session;

import com.empDept.entities.Department;
import com.empDept.utils.HibernateUtils;

import org.hibernate.Transaction;

public class DepartmentDaoImpl implements DepartmentDao{
	
	@Override
	public String addNewDepartment(String name,String location) {
		Session session = HibernateUtils.getSessionFactory().getCurrentSession();
		Transaction tx = session.beginTransaction();
		try {
			Department newDept = new Department(name,location);
			session.persist(newDept);
			tx.commit();
			return "Department " +name+" registered successfully";
		}
		catch(RuntimeException e) {
			if(tx != null) {
				tx.rollback();
			}
			throw e;
		}
	}
}
