import os
print("OS name:", os.name)
print("Current directory:", os.curdir)
print("CPU count:", os.cpu_count())

import math
print("PI:", math.pi)
