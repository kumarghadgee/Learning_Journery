package com.healthcare.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.healthcare.dtos.ApiResponse;
import com.healthcare.dtos.AuthRequest;
import com.healthcare.dtos.AuthResponse;
import com.healthcare.service.UserService;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/users")
@RequiredArgsConstructor
public class UserController {
	// depcy -constr based D.I
	private final UserService userService;

	/*
	 * Desc - User signin URI - /users/signin Method - POST Payload - request body -
	 * email , password (AuthRequest - DTO) Success Resp -SC 200 + Auth Resp (user
	 * id ,name, email , role , message) Failure Resp - SC 401 + ApiResp DTO(status
	 * : failure , timestamp , message)
	 */
	@PostMapping("/signin")
	public ResponseEntity<?> userSignIn(@RequestBody AuthRequest request) {
		System.out.println("in user sign in " + request);
		try {
			// call service layer method
			return ResponseEntity.ok(userService.authenticate(request));
		} catch (RuntimeException e) {
			return ResponseEntity.status(HttpStatus.UNAUTHORIZED)//SC 401
					.body(new ApiResponse("Failed", e.getMessage()));
		}
		
	}

}
