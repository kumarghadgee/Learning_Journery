package com.healthcare.dao;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.healthcare.entities.Doctor;
import com.healthcare.utils.HibernateUtils;

public class DoctorDaoImpl implements DoctorDao {

	@Override
	public String registerDoctor(Doctor doctor) {
		String mesg = "doc reg failed !!!!";
		// 1. Get Session from SessionFactory
		Session session = HibernateUtils.getSessionFactory().getCurrentSession();
		// 2. Begin Tx
		Transaction tx = session.beginTransaction();
		try {
			tx.commit();
			mesg = "doctor reg successful";
		} catch (RuntimeException e) {
			if (tx != null) {
				tx.rollback();
			}
			// re throw the same exception to the caller
			throw e;
		}
		return mesg;
	}

	@Override
	public String deleteDoctorDetailsById(Long doctorId) {
		String mesg = "Deletion Failed ";
		// 1. Get Session from SessionFactory
		Session session = HibernateUtils.getSessionFactory().getCurrentSession();
		// 2. Begin Tx
		Transaction tx = session.beginTransaction();
		try {

			tx.commit();
		} catch (RuntimeException e) {
			if (tx != null) {
				tx.rollback();
			}
			// re throw the same exception to the caller
			throw e;
		}
		return mesg;
	}

	@Override
	public Doctor getDoctorDetailsById(Long doctorId) {
		Doctor doctor = null;
		// 1. Get Session from SessionFactory
		Session session = HibernateUtils.getSessionFactory().getCurrentSession();
		// 2. Begin Tx
		Transaction tx = session.beginTransaction();
		try {
			tx.commit();
		} catch (RuntimeException e) {
			if (tx != null) {
				tx.rollback();
			}
			// re throw the same exception to the caller
			throw e;
		}
		return doctor;// doctor - detached - session scope- over !!!!!
	}

}
