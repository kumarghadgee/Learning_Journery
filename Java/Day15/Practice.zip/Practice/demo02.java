import java.util.Scanner;

class star
{
    public void star()
    {
        Scanner sc = new Scanner(System.in);

        System.out.print("Please Enter the number of row want to print : ");
        int n = sc.nextInt();

        for(int i = 0 ; i < n ; i++)
        {
            for(int j = 0 ; j < i ; j++)
            {
                System.out.print("* ");
            }
            System.out.println();
        }
        sc.close();
    }
}

public class demo02 {
    public static void main(String[] args) {
        star st = new star();
        st.star();
    }
}
