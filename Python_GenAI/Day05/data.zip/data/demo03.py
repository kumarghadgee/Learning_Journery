# Customer Assistant Agent

from dotenv import load_dotenv
from langchain.tools import tool
from langchain.agents import create_agent

load_dotenv()

# fake orders db
ORDERS = {
    "1001": {
        "customer": "Alice",
        "status": "Shipped",
        "amount": 30000.0
    },
    "1002": {
        "customer": "Bob",
        "status": "Processing",
        "amount": 25000.0
    }
}

@tool
def lookup_order(order_id: str) -> str:
    """
    Find the order by its ID.
    """
    order = ORDERS.get(order_id)
    if order is None:
        return "Order not found"
    return f"""
        Customer: {order["customer"]}
        Status: {order["status"]}
        BillAmount: {order["amount"]}
    """

@tool
def send_email(recipent: str, subject: str, body: str) -> str:
    """Send an Email."""

    print("\n========== Email ==========")
    print(f"To: {recipent}\nSubject: {subject}\n{body}")
    print("==========================")
    return "Email sent."

@tool
def refund_eligibility(order_id: str) -> str:
    """
    Check if the given order refund is valid.
    Returns "accepted" or "rejected".
    """
    order = ORDERS.get(order_id)
    if order is None:
        return "Order not found"
    if order["status"] == "Processing":
        return "accepted"
    else:
        return "rejected"

@tool
def refund(order_id: str, account_id: str) -> str:
    """
    Process the refund of the given order in given bank account.
    """
    order = ORDERS.get(order_id)
    if order is None:
        return "Order not found"
    print("\n========== Processing Refund ==========")
    print(f"Refund of Order {order_id}\nAmount: {order['amount']}\nTo account: {account_id}")
    print("=======================================")
    return "Refund processed"

agent = create_agent(
    model="groq:llama-3.3-70b-versatile",
    tools=[
        lookup_order,
        send_email,
        refund_eligibility,
        refund
    ],
    system_prompt="""
        You are a helpful customer support assistant.
        You can use the provided tools only to help the customer.
        Do not try to call any imaginary tool.
        Order refund processing to be done ONLY when user asked for the refund and
        the order is eligible for refund.
    """
)
while True:
    question = input("\nHow I can help you? ")
    if question == "exit":
        break
    result = agent.invoke({
        "messages": [ {"role": "user", "content": question} ]
    })
    print("Answer:", result["messages"][-1].content)
