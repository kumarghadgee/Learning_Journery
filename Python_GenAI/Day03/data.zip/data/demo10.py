import requests
import os
import json
from dotenv import load_dotenv

# API docs: https://console.groq.com/docs/api-reference#chat
# Assignment: Read multiple inputs from user one-by-one and display the output, until user enters 'exit'.

load_dotenv()
GROQ_URL = "https://api.groq.com/openai/v1/chat/completions"
GROQ_API_KEY = os.getenv("GROQ_API_KEY")
GROQ_MODEL = "llama-3.1-8b-instant"

user_prompt = input("Ask anything: ")
req_payload = {
    "model": GROQ_MODEL,
    "messages": [
        {"role": "user", "content": user_prompt}
    ]
}
req_headers = {
     "Content-Type": "application/json", 
     "Authorization": f"Bearer {GROQ_API_KEY}"
}
try:
    response = requests.post(GROQ_URL, data=json.dumps(req_payload), headers=req_headers)
    response.raise_for_status()
    # print(response.text)
    result = response.json()
    print("Answer:", result["choices"][0]["message"]["content"])
except Exception as e:
    print("ERROR:", e)
