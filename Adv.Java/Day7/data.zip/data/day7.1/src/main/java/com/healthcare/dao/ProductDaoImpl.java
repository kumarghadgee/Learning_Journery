package com.healthcare.dao;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.healthcare.entities.Product;
import com.healthcare.utils.HibernateUtils;

public class ProductDaoImpl implements ProductDao {

	@Override
	public String addProduct(Product newProduct) {
		// TODO Auto-generated method stub
		String message = "adding Product failed";
		Session session = HibernateUtils.getSessionFactory().getCurrentSession();
		Transaction tx = session.beginTransaction();
		try {
			session.persist(newProduct);
			tx.commit();
			message = "New Product added with ID"+newProduct.getProductId();
		} catch (RuntimeException e) {
			// TODO: handle exception
			if(tx != null) {
				tx.rollback();
			}
			throw e;
		}
		return message;
	}

}
