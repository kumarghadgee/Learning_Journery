package com.cdac.dependent;

import com.cdac.dependency.Coach;
import com.cdac.dependency.Teacher;

/*
 * School
 * dependencies
 *  
 *  - Teacher 
 *  - Sports coach
 *  autowire=byName
 */
public class PublicSchool implements School {
	private Teacher subjectTeacher;
	private Coach sportsCoach;
	

	public PublicSchool() {
		System.out.println("In constructor - " + getClass());
	}

	// B.L method
	@Override
	public void manageAcademics() {
		System.out.println("Managing academics here -");
		subjectTeacher.teach();
	}

	@Override
	public void organizeSportsEvent() {
		System.out.println("Organizing Sports Event - ");
		System.out.println(sportsCoach.getDailyWorkout());
	}

	

	public void myInit() {
		System.out.println("in init");
	}

	public void myDestroy() {
		System.out.println("in destroy");
	}
	//setter based D.I
	public void setSubjectTeacher(Teacher subjectTeacher) {
		this.subjectTeacher = subjectTeacher;
		System.out.println("in setter - teacher");
	}

	public void setSportsCoach(Coach sportsCoach) {
		this.sportsCoach = sportsCoach;
		System.out.println("in setter - coach");
	}

	
	

}
