package com.healthcare.tester;

import static com.healthcare.utils.HibernateUtils.getSessionFactory;

import java.util.Scanner;

import org.hibernate.SessionFactory;

import com.healthcare.dao.DoctorDao;
import com.healthcare.dao.DoctorDaoImpl;
import com.healthcare.entities.Doctor;

public class GetDoctorDetailsById {

	public static void main(String[] args) {
		try (Scanner sc = new Scanner(System.in);
				SessionFactory sf = getSessionFactory()) {
			//Create dao instance
			DoctorDao docDao=new DoctorDaoImpl();
			System.out.println("Enter doctor id to get  doctor details");
				//invoke dao's method
			Doctor doctor = docDao.getDoctorDetailsByIdWithJoinFetch(sc.nextLong());
			System.out.println("Doc details "+doctor);
			if(doctor != null)
			{
//				System.out.println("User details ");
//				System.out.println(doctor.getUserDetails());
				System.out.println("All Appointments - ");				
				doctor.getAppointments().forEach(System.out::println);
			}
		} // JVM -> sf.close() -> DBCP auto cleaned up !

	}

}
