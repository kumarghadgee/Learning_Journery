package com.backend.entities;

public enum Industry {
//- industry (enum - Education , Pharmaceutical , 
//Hospitality , Information Technology (IT)  Banking , Healthcare)
	Education , Pharmaceutical , Hospitality , InformationTechnology , Banking , Healthcare;
}
