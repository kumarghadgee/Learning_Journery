import java.util.Scanner;

class mm
{
    Scanner sc = new Scanner(System.in);
    public void mmi()
    {
        int[] nums = {2,3,4,5,1,6,7,8};
        int min = nums[0];
        int max = nums[0];

        for(int i = 0 ; i < nums.length ; i++)
        {
            for(int j = i ; j < nums.length ; j++)
            {
                if(nums[i] > max)
                {
                    max = nums[i];
                }
                
                if(nums[j] < min)
                {
                    min = nums[i];
                }
            }
            sc.close();
        }

        System.out.println("Min = " + min + " Max = " + max);
    }
}

public class minMax
{
    public static void main(String[] args) {
        mm m = new mm();
        m.mmi();
    }
}