package com.healthcare.dtos;

import com.healthcare.entities.UserRole;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

//(user id ,name, email , role , message)
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class AuthResponse {
	private Long id;
	private String completeName;
	private UserRole userRole;
	private String jwt;
}
