package com.backend.service;

import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.backend.custom_exceptions.ResourceNotFoundException;
import com.backend.dtos.JobDTO;
import com.backend.entities.CompanyEntity;
import com.backend.entities.Job;
import com.backend.entities.JobType;
import com.backend.repository.CompanyRepository;
import com.backend.repository.JobRepository;

import lombok.RequiredArgsConstructor;



@Service
@Transactional
@RequiredArgsConstructor
public class JobServiceImpl implements JobService {
	
	private final JobRepository jobRepository;
	private final ModelMapper mapper;
	private final CompanyRepository companyRepository;
	

	@Override
	public Job addNewJobOpening(JobDTO jobDto) {
		CompanyEntity company = companyRepository.findById(jobDto.getCompanyId())
				.orElseThrow(() -> new ResourceNotFoundException("Company Not Found"));
		Job job = mapper.map(jobDto,Job.class); 
		job.setMyCompany(company);
		return jobRepository.save(job);
	}


	@Override
	public List<Job> getListOfJobByLocation(String location) {
		return jobRepository.findByLocation(location);
	}


	@Override
	public int deleteAllJobOfSpecifiedTypeAndCompany(JobType jobType, String name) {
		return jobRepository.deleteAllByJobTypeAndMyCompanyName(jobType,name);
	}

	
}
