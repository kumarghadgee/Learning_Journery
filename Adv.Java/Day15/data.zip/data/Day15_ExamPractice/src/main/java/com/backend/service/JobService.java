package com.backend.service;

import java.util.List;

import com.backend.dtos.JobDTO;
import com.backend.entities.Job;
import com.backend.entities.JobType;

public interface JobService {

	Job addNewJobOpening(JobDTO jobDto);

	List<Job> getListOfJobByLocation(String location);

	int deleteAllJobOfSpecifiedTypeAndCompany(JobType jobType, String name);

}
