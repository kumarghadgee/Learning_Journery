package com.backend.service;

import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.backend.custom_exceptions.ResourceNotFoundException;
import com.backend.dtos.CompanyDTO;
import com.backend.entities.CompanyEntity;
import com.backend.repository.CompanyRepository;
import com.backend.repository.JobRepository;

import lombok.RequiredArgsConstructor;

@Service
@Transactional
@RequiredArgsConstructor
public class CompanyServiceImpl implements CompanyService {

	private final CompanyRepository companyRepository;
	private final ModelMapper mapper;
	private final JobRepository jobRepository;
	
	@Override
	public List<CompanyDTO> getAllCompanyDetails() {
		return companyRepository.findAll().stream()
				.map(company -> mapper.map(company,CompanyDTO.class))
				.toList();
	}

	@Override
	public String deleteCompanyDetailsById(Long id) {
		CompanyEntity company = companyRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Company Not Found"));
		jobRepository.deleteByMyCompanyCompanyId(id);
		companyRepository.delete(company);
		return "Company SuccessFully Deleted";
	}

}
