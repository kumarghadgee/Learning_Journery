import os
import requests
from dotenv import load_dotenv
from langchain.chat_models import init_chat_model
from langchain.messages import HumanMessage, SystemMessage

load_dotenv()
WEATHER_API_KEY = os.getenv("WEATHER_API_KEY")

def get_current_weather(city: str) -> str:
    # copied from day02 - demo19.py
    try:
        url = "https://api.openweathermap.org/data/2.5/weather"
        params = {
            "q": city,
            "appid": WEATHER_API_KEY,
            "units": "metric"
        }
        resp = requests.get(url, params)
        resp.raise_for_status()
        return resp.text
    except Exception as e:
        return {"ERROR": str(e)}


SYSTEM_PROMPT="""
You are a weather assistant. Analyze the given weather JSON and provide:
1. 2-3 sentense summary of current conditions
2. Key weather risks and/or alerts
3. Practical advice on the provided clothing, travel, and outdoor activities.
Base your response only on provided JSON in friendly tone.
If any data is missing, state that instead of guessing.
"""

llm = init_chat_model(
        model="groq:llama-3.1-8b-instant",
        api_key=os.getenv("GROQ_API_KEY")
    )
while True:
    city = input("\nEnter a city/village: ")
    if city == "exit":
        break
    weather_json = get_current_weather(city)
    messages = [
        SystemMessage(content=SYSTEM_PROMPT),
        HumanMessage(content=f"CITY: {city}\n\nWEATHER:\n{weather_json}")
    ]
    response = llm.invoke(input=messages)
    print(response.content)
