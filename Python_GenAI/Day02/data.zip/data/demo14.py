
# option1 -- to import another module
# import mathutil

# print("in demo14 appln!")
# res1 = mathutil.add(22, 7)
# print(f"res1 = {res1}")
# res2 = mathutil.subtract(22, 7)
# print(f"res2 = {res2}")
# res3 = mathutil.multiply(22, 7)
# print(f"res3 = {res3}")

# option2 -- to import another module with alias
import mathutil as m

print("in demo14 appln!")
res1 = m.add(22, 7)
print(f"res1 = {res1}")
res2 = m.subtract(22, 7)
print(f"res2 = {res2}")
res3 = m.multiply(22, 7)
print(f"res3 = {res3}")
print(f"PI = {m.PI}")

# option3 -- to import specific fns/vars from another module
# from mathutil import add, subtract, multiply
# from mathutil import PI

# print("in demo14 appln!")
# res1 = add(22, 7)
# print(f"res1 = {res1}")
# res2 = subtract(22, 7)
# print(f"res2 = {res2}")
# res3 = multiply(22, 7)
# print(f"res3 = {res3}")
