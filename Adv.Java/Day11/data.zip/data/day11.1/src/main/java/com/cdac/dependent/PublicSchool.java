package com.cdac.dependent;

import com.cdac.dependency.Teacher;

public class PublicSchool implements School {	
	private Teacher subjectTeacher;//=new EnglishTeacher();
	
	//constructor based D.I
	public PublicSchool(Teacher myTeacher) {
		System.out.println("In constructor - " + getClass());	
		this.subjectTeacher=myTeacher;
	}
	//B.L method
	@Override
	public void manageAcademics() {
		System.out.println("Managing academics here -");
		subjectTeacher.teach();
	}	
	public void myInit() {
		System.out.println("in init");
	}
	public void myDestroy() {
		System.out.println("in destroy");
	}

}
