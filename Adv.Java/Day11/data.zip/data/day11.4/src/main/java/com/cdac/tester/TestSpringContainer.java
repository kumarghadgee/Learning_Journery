package com.cdac.tester;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cdac.dependent.PublicSchool;

public class TestSpringContainer {

	public static void main(String[] args) {
		/*
		 * Start SC in stand alone manner
		 */
		try (ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext("bean-config.xml")) {
			System.out.println("SC up & running ....");
			//get ready to use spring bean from SC
			PublicSchool school1=ctx.getBean("public_school", PublicSchool.class);
			//invoke B.L - call manageAcademics on Public school
			school1.manageAcademics();
			school1.organizeSportsEvent();
			
			PublicSchool school2=ctx.getBean("public_school", PublicSchool.class);
			System.out.println(school1==school2);//t
			
		} //JVM -> ctx.close() -> SC calls destroy-method on singletons
		catch (Exception e) {
			e.printStackTrace();
		}

	}

}
