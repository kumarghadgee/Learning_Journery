package com.healthcare.service;

import com.healthcare.dtos.PatientResp;

public interface PatientService {
//add a method to get patient's specific details
	PatientResp getPatientDetails(Long patientId);
}
