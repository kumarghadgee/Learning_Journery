# calculator program -- menu driven program
#   break statement allowed in loops -- like C/Java
#   contiune statement allowed in loops -- like C/Java

while True:
    option = int(input("\n0. exit\n1. add\n2. subtract\n3. multiply\nenter option: "))
    if option == 0:
        break

    num1 = int(input("enter first number: "))
    num2 = int(input("enter second number: "))
    if option == 1:
        res = num1 + num2
        print(f"addition: {res}")
    elif option == 2:
        res = num1 - num2
        print(f"subtraction: {res}")
    elif option == 3:
        res = num1 * num2
        print(f"multiplication: {res}")
    else:
        print("invalid option")
