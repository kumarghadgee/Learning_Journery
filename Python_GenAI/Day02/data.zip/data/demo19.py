# activate venv
# cmd> pip install requests
# cmd> pip install dotenv

import requests
import os
from dotenv import load_dotenv

load_dotenv() # read settings from .env file as OS env variables
WEATHER_API_KEY = os.getenv("WEATHER_API_KEY")
INPUT_PROMPT = os.getenv("INPUT_PROMPT")

try:
    city = input(INPUT_PROMPT)
    url = "https://api.openweathermap.org/data/2.5/weather"
    # params => query string
    # url?key1=value1&key2=value2
    params = {
        "q": city,
        "appid": WEATHER_API_KEY,
        "units": "metric"
    }
    resp = requests.get(url, params)
    resp.raise_for_status()
    print(resp.text)
except Exception as e:
    print("ERROR:", e)















