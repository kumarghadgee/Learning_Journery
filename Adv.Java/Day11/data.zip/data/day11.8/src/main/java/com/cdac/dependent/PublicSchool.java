package com.cdac.dependent;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

//singleton & eager , id="public_school"
import com.cdac.dependency.Coach;
import com.cdac.dependency.Teacher;

import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;

/*
 * School
 * dependencies
 *  
 *  - Teacher 
 *  - Sports coach
 *
 */
@Component("public_school")
public class PublicSchool implements School {
	//Field Level D.I
	@Autowired //SC tries to match - by type 
	private Teacher[] subjectTeachers;
	@Autowired //SC tries to match - by type 
	private Coach[] sportsCoaches;

	public PublicSchool() {
		System.out.println("in ctor " + getClass());		
	}

	// B.L method
	@Override
	public void manageAcademics() {
		System.out.println("Managing academics here -");
		for (Teacher t : subjectTeachers)
			t.teach();
	}

	@Override
	public void organizeSportsEvent() {
		System.out.println("Organizing Sports Event - ");
		for(Coach c : sportsCoaches)
		 System.out.println(c.getDailyWorkout());
	}
	@PostConstruct
	public void myInit() {
		System.out.println("in init");
	}
	@PreDestroy
	public void myDestroy() {
		System.out.println("in destroy");
	}

}
