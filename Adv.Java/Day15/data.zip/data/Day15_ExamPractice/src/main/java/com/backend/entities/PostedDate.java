package com.backend.entities;

public enum PostedDate {
	AVAILABLE , UNAVAILABLE;
}
