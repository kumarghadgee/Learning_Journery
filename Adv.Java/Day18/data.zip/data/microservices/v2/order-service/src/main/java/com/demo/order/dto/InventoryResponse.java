package com.demo.order.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class InventoryResponse {
    private String skuCode;
    private String productName;
    private boolean inStock;
    private Integer quantity;
    private Integer price;
}
