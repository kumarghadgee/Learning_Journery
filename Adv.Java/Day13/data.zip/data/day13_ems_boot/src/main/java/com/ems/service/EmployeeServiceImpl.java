package com.ems.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ems.entities.Employee;
import com.ems.repository.EmployeeRepository;
@Service
@Transactional(readOnly = true)
public class EmployeeServiceImpl implements EmployeeService {
	@Autowired
	private EmployeeRepository empRepo;

	@Override
	public List<Employee> getAvailableEmpsByDeptId(Long deptId) {
		// TODO Auto-generated method stub
		return empRepo.findByMyDepartmentIdAndStatusTrue(deptId);
	}
	
	@Override
	@Transactional //readOnly=false
	public String deleteEmpDetailsById(Long empId) {
		/*
		 *  1.GET emp details by its id
		 * 
		 *  java.util.Optional<T>
		 *  - Generic class,that may or may not contain the value
		 *  Method
		 *  public T orElseThrow()
		 *  - Returns T (value) in case of non empty Optional
		 *  - or else it will throw - NoSuchElementException
		 */
		
		Employee emp = empRepo.findById(empId)
					   .orElseThrow();
		// => Emp: PERSISTENT employee reference
		// 2. If found , setter-set status : false
		
		emp.setStatus(false);
		return "Emp soft deleted";
	}
	
	/*
	 *  Transaction Manager - Checks for RunTimeException
	 *  -tx.rollback
	 *  
	 */
}
