
import streamlit as st

options = ["Upper", "Lower", "Capitalize", "SwapCase"]
cur_option = "Upper"
conversation = list()

st.title("Sunbeam Fake Chatbot")
with st.sidebar:
    st.header("Settings")
    cur_option = st.selectbox("Choose One:", options, 0)
    if cur_option:
        st.write(f"You selected: {cur_option}")

user_text = st.chat_input("Enter text...")
if user_text:
    ai_text = ""
    if cur_option == "Upper":
        ai_text = user_text.upper()
    elif cur_option == "Lower":
        ai_text = user_text.lower()
    elif cur_option == "Capitalize":
        ai_text = user_text.capitalize()
    elif cur_option == "SwapCase":
        ai_text = user_text.swapcase()
    else:
        ai_text = "Sorry! I can't."

    conversation.append({"role": "user", "content": user_text})
    conversation.append({"role": "ai", "content": ai_text})

for msg in conversation:
    with st.chat_message(msg["role"]):
        st.write(msg["content"])
