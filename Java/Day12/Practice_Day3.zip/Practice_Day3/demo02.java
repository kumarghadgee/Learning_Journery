import java.util.Scanner;

class string
{
    public void swap()
    {
        try {
            Scanner sc = new Scanner(System.in);
            System.out.print("Enter the First String : ");
            String a = sc.next();
            System.out.print("Enter the Second String : ");
            String b = sc.next();

            System.out.println("Strings Before Swap : " + " a  = "+ a + ", b =  " + b);

            a = a + b;
            b = a.substring(0,a.length() - b.length());
            a = a.substring(b.length());

            System.out.println("Strings After Swap : " + " a  = "+ a + ", b =  " + b);

            sc.close();
        } catch (Exception e) {
            System.out.println("You Entered the Wrong Values");
        }
    }
}

public class demo02 {
    public static void main(String[] args) {
        string st = new string();
        st.swap();
    }
}
