<%@page import="java.util.HashMap"%>
<%@page import="com.user.pojo.User" %>
<%@page import="java.time.LocalDate" %>
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Validation</title>
</head>
<%!

    HashMap<String,User> hs = new HashMap<>();

	public void jspInit(){
	hs.put("anil@gmail.com",new User("Anil","anil@gmail.com","anil",LocalDate.parse("1999-01-02")));
	hs.put("mukesh@gmail.com",new User("Mukesh","mukesh@gmail.com","mukesh",LocalDate.parse("2002-12-14")));
	hs.put("anant@gmail.com",new User("Anant","anant@gmail.com","anant",LocalDate.parse("2004-11-14")));
	hs.put("akash@gmail.com",new User("Akash","akash@gmail.com","akash",LocalDate.parse("2007-09-16")));
	hs.put("nita@gmail.com",new User("Nita","nita@gmail.com","nita",LocalDate.parse("2003-10-03")));
}
%>
<body>
<%
	String email = request.getParameter("em");
	String password = request.getParameter("pass");
	
	User us = hs.get(email);
	
	if(us.getPassword().equals(password)){
		session.setAttribute("users",us);
		
		String enUrl = response.encodeRedirectURL("details.jsp");
		response.sendRedirect(enUrl);
	}
	else
	{
		out.print("<h2>Invalid Login </h2>");
		out.print("<h4><a href='login.jsp'>Please Retry Again</a></h4>");
	}
%>
	
</body>
</html>