<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<%@ taglib uri="jakarta.tags.core" prefix="c"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
	<c:set var="sal" value="${param.salary}" />
	<c:choose>
		<c:when test="${sal > 40000 and sal < 60000}">
	   Good Salary
	 </c:when>
		<c:when test="${sal > 60000 and sal < 80000}">
	   Better Salary
	 </c:when>
		<c:otherwise>
		Best or worst Salary !!!!
		</c:otherwise>
	</c:choose>
</body>
</html>