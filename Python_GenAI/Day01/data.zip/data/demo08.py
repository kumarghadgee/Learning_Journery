# function -- reusable block of statements
#   input to funtion -- arguments
#   output from function -- return value
#   the first line of function can be a string literal -> docstring
#       function documentation
#       optional, but recommnded

# function defn
def can_vote(age):
    """
        fn check if user can vote or not
        argument: age
        returns: True or False
    """
    if age >= 18:
        return True
    else:
        return False

# function call
age = 18    # may input from user
flag = can_vote(age)
print(f"Can Vote: {flag}")
