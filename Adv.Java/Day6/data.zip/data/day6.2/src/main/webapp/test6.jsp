<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<%@ taglib uri="jakarta.tags.core" prefix="c"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
	<%-- Display product price > 500 --%>
	<c:if test="${param.price > 500}">
	  <h5>Product Price - ${param.price}</h5>
	</c:if>
</body>
</html>