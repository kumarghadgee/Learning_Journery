package com.demo.inventory.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.demo.inventory.dto.StockRequest;
import com.demo.inventory.service.InventoryServiceImpl;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/inventory")
@RequiredArgsConstructor
public class InventoryController {

    private final InventoryServiceImpl inventoryService;

    /**
     * GET /inventory/check/SKU-001/2
     *
     * 
     * Returns stock availability for a single SKU.
     */
    @GetMapping("/check/{skuCode}/{quantity}")
    public ResponseEntity<?> checkStock(
            @PathVariable String skuCode,
            @PathVariable int quantity) {

        return ResponseEntity.ok(inventoryService.checkStock(skuCode, quantity));
    }

    /**
     * POST /inventory/check-bulk
     * Body: ["SKU-001", "SKU-002", "SKU-003"]
     *
     * Bulk find stocks of order items — more efficient for multi-item orders.
     */
    @PostMapping("/check-bulk")
    public ResponseEntity<?> findStockBulk(
            @RequestBody List<String> skuCodes) {

        return ResponseEntity.ok(inventoryService.checkStockBulk(skuCodes));
    }

    /**
     * PUT /inventory/deduct
	    Payload - request body (skuCode & quantity)
     *
     * Reduce stock after order is confirmed.
     * Called by Order Service after a successful order placement.
     */
    @PutMapping("/deduct")
    public ResponseEntity<?> deductStock(
            @RequestBody StockRequest request) {        
        return ResponseEntity.ok(inventoryService.deductStock(request));
    }
}
