package com.empDept.dao;

public interface DepartmentDao {
	String addNewDepartment(String name,String location);
}
