import java.util.Scanner;

class pattern
{
    public void star()
    {
        Scanner sc = new Scanner(System.in);
        try
        {
            System.out.print("Please Enter the value of Rows : ");
            int n = sc.nextInt();

            for(int i = n ; i >= 1 ; i--)
            {
                for(int j = 1 ; j <= n - i ; j++){
                    System.out.print(" ");
                }

                for(int j = i ; j >= 1 ; j--){
                    System.out.print("*");
                }
                System.out.println();
            }
        }
        catch(Exception e)
        {
            System.out.println("Your Entered Value is Incorrect......");
        }
        finally
        {
            sc.close();
        }
    }
}

public class demo03 {
    public static void main(String[] args) {
        pattern pt = new pattern();
        pt.star();
    }
}
