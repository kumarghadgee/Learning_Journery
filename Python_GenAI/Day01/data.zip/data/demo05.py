# control structs -- if, if-else, if-elif-else

age = int(input("Enter age: "))
if age >= 18:
    print("You can vote")
else:
    print("You cannot vote")

marks = float(input("Enter marks: "))
if marks >= 75.0:
    print("Distinction")
elif marks >= 60.0 and marks < 75.0:
    print("First class")
elif marks >= 50.0 and marks < 60.0:
    print("Second class")
else:
    print("Failed")
