<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>JSTL Demo</title>
</head>
<body>
	<h5>
		<a href="test1.jsp?id=100&price=200">JSTL c:set n c:remove</a>
	</h5>
	<h5>
		<a href="test3.jsp">c:forEach as for loop</a>
	</h5>
	<h5>
		<a href="test4.jsp">c:forEach as for - each </a>
	</h5>
	<h5>
		<a href="test6.jsp?price=100">c:if </a>
	</h5>
	<h5>
		<a href="test7.jsp?salary=86000">c:choose when otherwise </a>
	</h5>
</body>
</html>