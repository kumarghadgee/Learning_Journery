from fastapi import FastAPI
from pydantic import BaseModel
from typing import Optional

class User(BaseModel):
    id: int
    email: str
    passwd: str

class UserResp(BaseModel):
    id: int
    email: str

app = FastAPI()
users = list()

@app.get("/users")
def all_users():
    return users

@app.get("/users/{id}", response_model=Optional[UserResp])
def get_user(id:int):
    user = [u for u in users if u.id == id]
    if len(user) > 0:
        return user[0]
    else:
        return None

@app.post("/users")
def add_user(u:User):
    users.append(u)
    return {
        "status": "success",
        "data": "user is saved"
    }
