
# Stateful UI Chatbot - Model Selection

import os
from groq import Groq
import streamlit as st
from dotenv import load_dotenv

load_dotenv()
if "messages" not in st.session_state:
    st.session_state.messages = list()

temp = 0.7
GROQ_MODEL = "llama-3.1-8b-instant"
GROQ_API_KEY = os.getenv("GROQ_API_KEY")
client = Groq(api_key=GROQ_API_KEY)

with st.sidebar:
    models = ["llama-3.1-8b-instant", "llama-3.3-70b-versatile", "openai/gpt-oss-120b", "openai/gpt-oss-20b", "qwen/qwen3.6-27b"]
    GROQ_MODEL = st.selectbox("Groq Model", options=models)
    temp = st.slider("Temperature", min_value=0.0, max_value=1.0, value=0.7, step=0.1)

st.title("Sunbeam Chatbot")

user_prompt = st.chat_input("Ask anything?")
if user_prompt:
    st.session_state.messages.append({"role": "user", "content": user_prompt})
    response = client.chat.completions.create(
                        model=GROQ_MODEL,
                        messages=st.session_state.messages,
                        temperature=temp,
                        stream=False
                    )
    ai_answer = response.choices[0].message.content
    st.session_state.messages.append({"role": "assistant", "content": ai_answer})

    for msg in st.session_state.messages:
        with st.chat_message(name=msg["role"]):
            st.write(msg["content"])   
