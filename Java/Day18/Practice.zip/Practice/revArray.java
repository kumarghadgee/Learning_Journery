class rev
{
    public void revArr()
    {
        int[] nums = {1,2,3,4,5,6,7};

        int start = 0;
        int end = nums.length - 1;
        int temp = 0;

        while(start < end)
        {
            temp = nums[start];
            nums[start] = nums[end];
            nums[end] = temp;

            start++;
            end--;
        }

        for(int i = 0 ; i < nums.length ; i++)
        {
            System.out.print(nums[i] +  " ,");
        }
    }
}

public class revArray {
    public static void main(String[] args) {
        rev r = new rev();
        r.revArr();
    }
}
