package com.voting.controller;

import java.io.IOException;

import com.voting.dao.CandidateDao;
import com.voting.dao.CandidateDaoImpl;
import com.voting.dao.UserDao;
import com.voting.dao.UserDaoImpl;
import com.voting.entities.User;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

/**
 * Servlet implementation class VoterDashboardServlet
 */
@WebServlet(value = "/logout", loadOnStartup = 3)
public class LogoutServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private UserDao userDao;
	private CandidateDao candidateDao;

	@Override
	public void init() throws ServletException {
		try {
			userDao = new UserDaoImpl();
			candidateDao = new CandidateDaoImpl();
		} catch (Exception e) {
			throw new ServletException("err in init " + getClass(), e);
		}
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		HttpSession session = request.getSession(false);
		if (session != null) {
			// store user details from session -> request scope
			request.setAttribute("user_dtls", session.getAttribute("user_details"));
			request.setAttribute("message", "You have already voted !!!!!!");
			
			// invalidate session
			session.invalidate();
			/*
			 * forward the client in the same request to view layer logout.jsp
			 */
			RequestDispatcher rd = request.getRequestDispatcher("/WEB-INF/views/logout.jsp");
			rd.forward(request, response);
		} else {
			response.sendRedirect(
					request.getContextPath() + "?message=" + "You have to accept the cookies to continue....");
		}
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// voter has submitted the form with POST

		try {
			// 3. Get HttpSession from WC
			HttpSession session = req.getSession(false);
			if (session != null) {
				// 4. get user details from session
				User details = (User) session.getAttribute("user_details");
				// 5. invoke user dao's method to change voting status
				String updateVotingStatus = userDao.updateVotingStatus(details.getUserId());
				// get candidate id from request parameter
				int cId = Integer.parseInt(req.getParameter("candidateId"));
				// invoke candidate dao's method - increment votes
				String incrementVotesStatus = candidateDao.incrementCandidateVotes(cId);
				//add status messages under request scope
				req.setAttribute("voting_sts", updateVotingStatus);
				req.setAttribute("incr_sts",incrementVotesStatus);
					// get user details from session -> store it under request scope
				req.setAttribute("user_dtls", session.getAttribute("user_details"));
				// 7. invalidate session
				session.invalidate();
				/*
				 * forward the client in the same request to view layer logout.jsp
				 */
				RequestDispatcher rd = req.getRequestDispatcher("/WEB-INF/views/logout.jsp");
				rd.forward(req, resp);
			} else {
				resp.sendRedirect(
						req.getContextPath() + "?message=" + "You have to accept the cookies to continue....");
			}

		} catch (Exception e) {
			throw new ServletException("err in doPost " + getClass(), e);
		}
	}

	@Override
	public void destroy() {
		try {
			userDao.cleanUp();
			candidateDao.cleanUp();
		} catch (Exception e) {
			System.out.println("in destory " + getClass() + " " + e);
		}

	}

}
