package com.healthcare.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.healthcare.dtos.AppointmentResp;
import com.healthcare.entities.Appointment;
import com.healthcare.entities.Status;

public interface AppointmentRepository extends JpaRepository<Appointment, Long> {
//custom query method - List<DTO> 
	@Query("""
			SELECT new com.healthcare.dtos.AppointmentResp
			(a.id,a.myDoctor.userDetails.firstName,a.myDoctor.userDetails.lastName,a.startDateTime) 
			FROM Appointment a 
			WHERE a.myPatient.id=:pid AND a.status=:sts
			""")
	List<AppointmentResp> getPatientUpcomingAppointments(@Param("pid")Long patientId,@Param("sts")Status sts);
}
