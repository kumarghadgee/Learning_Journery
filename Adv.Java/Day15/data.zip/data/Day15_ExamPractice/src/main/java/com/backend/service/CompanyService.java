package com.backend.service;

import java.util.List;

import com.backend.dtos.CompanyDTO;

public interface CompanyService {

	List<CompanyDTO> getAllCompanyDetails();

	String deleteCompanyDetailsById(Long id);
	
}
