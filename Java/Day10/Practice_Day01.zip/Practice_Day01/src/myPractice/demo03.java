package myPractice;

import java.util.Scanner;

class pattern2
{
	public void star()
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the value of i : ");
		for(int i = sc.nextInt(); i > 0 ; i--) {
			for(int j = i; j > 0; j--) {
				System.out.print("* ");
			}
			System.out.println();
		}
		
		sc.close();
	}
}

public class demo03 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		pattern2 pt2 = new pattern2();
		pt2.star();
	}

}
