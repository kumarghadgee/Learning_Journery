<%@page import="com.ecommerce.pojos.Product"%>
<%@page import="java.util.List"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<%@ taglib uri="jakarta.tags.core" prefix="c"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
	<%
	//generating list of products
	List<Product> products = List.of(new Product(10, "Product-1", 100), new Product(11, "Product-2", 200),
			new Product(12, "Product-3", 300));
	%>
	<c:set var="product_list" value="<%=products%>" scope="session" />
	<c:redirect url="test5.jsp" />

</body>
</html>