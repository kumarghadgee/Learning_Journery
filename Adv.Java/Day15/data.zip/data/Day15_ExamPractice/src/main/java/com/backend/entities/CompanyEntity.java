package com.backend.entities;

import java.time.LocalDateTime;

import org.hibernate.annotations.CreationTimestamp;

import jakarta.persistence.AttributeOverride;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
@Entity
@Table(name="company")
@AttributeOverride(name="id",column=@Column(name="company_id"))

public class CompanyEntity extends BaseEntity {
	/*
	 * name (unique)
 - email (unique)
 - location
 - industry (enum - Education , Pharmaceutical , Hospitality , Information Technology (IT)  
 Banking , Healthcare)
 - created on :  date
	 */
	@Column(length = 20,unique = true)
	private String name;
	
	@Column(length = 50, unique = true)
	private String email;
	
	@Enumerated(EnumType.STRING)
	private Industry industry;
	
	@CreationTimestamp
	@Column(name = "created_on")
	private LocalDateTime createdOn;
}
