import tiktoken
import torch
from transformers import AutoTokenizer, AutoModelForCausalLM

def ex01_tokenizer():
    text = "I love ChatGPT!"
    # get the encoder
    enc = tiktoken.get_encoding("cl100k_base")
    # encoding
    tokens = enc.encode(text)
    print("Tokens:", tokens)
    # decoding
    dec_tokens = [enc.decode([t]) for t in tokens]
    print("Decoded Tokens:", dec_tokens)
    # https://tiktokenizer.vercel.app/

# ex01_tokenizer()

def ex02_vocab():
    # get the encoder
    enc = tiktoken.get_encoding("cl100k_base")
    # check vocabulary size
    print("encoder vocab:", enc.n_vocab)
    # View the a few entries (token bytes -> rank ID)
    m = 10
    n = 25
    for token_bytes, rank in list(enc._mergeable_ranks.items())[m:n]:
        print(f"Token: {token_bytes} -> ID: {rank}")
    # Reverse map to find text/bytes for a specific ID (e.g., ID 1000)
    sample_id = 1000
    print(f"\nID {sample_id} decodes to:", enc.decode_single_token_bytes(sample_id))

# ex02_vocab()

def ex03_next_token_prediction():
    tokenizer = AutoTokenizer.from_pretrained("gpt2")
    model = AutoModelForCausalLM.from_pretrained("gpt2")

    text = "The capital of France is"
    inputs = tokenizer(text, return_tensors="pt")

    with torch.no_grad():
        outputs = model(**inputs)

    logits = outputs.logits

    next_logits = logits[0, -1]
    print("Next Logits: ", next_logits)

    probs = torch.softmax(next_logits, dim=-1)

    values, indices = torch.topk(probs, 10)

    for p, idx in zip(values, indices):
        print(tokenizer.decode(idx), p.item())

# ex03_next_token_prediction()

def ex04_model_loop():
    tokenizer = AutoTokenizer.from_pretrained("gpt2")
    model = AutoModelForCausalLM.from_pretrained("gpt2")

    text = "The capital of France is"
    tokens = tokenizer.encode(text)

    for _ in range(20):

        input_ids = torch.tensor([tokens])

        logits = model(input_ids).logits

        # next_token = logits[0,-1].argmax().item()
        probs = torch.softmax(logits[0, -1], dim=-1)
        next_token = torch.multinomial(probs, num_samples=1).item()

        tokens.append(next_token)

    print(tokenizer.decode(tokens))

ex04_model_loop()
