<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<%!String message1 = "hello";//private instance var.
%>
<body>
	<%
	String message2 = "hi";//method local var
	pageContext.setAttribute("message3", "how are you?");//page scoped attribute
	%>
	<%@ include file="test8.jsp"%>
</body>
</html>