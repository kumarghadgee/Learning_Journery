package com.healthcare.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.healthcare.entities.User;


public interface UserRepository extends JpaRepository<User,Long> {
//derived finder for user auth
	Optional<User>  findByEmailAndPassword(String email, String password);
}
