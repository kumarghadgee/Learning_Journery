package com.healthcare.service;

import java.util.List;

import com.healthcare.dtos.AppointmentResp;

public interface AppointmentService {
//add a method to list patient's upcoming(scheduled) appointments
	List<AppointmentResp> getPatientsScheduledAppointments(Long patientId);
}
