from fastapi import FastAPI
from pydantic import BaseModel
from typing import Optional, Literal, Any

class User(BaseModel):
    id: int
    email: str
    passwd: str

class UserResp(BaseModel):
    id: int
    email: str

class ApiResp(BaseModel):
    status: Literal["success", "failed"]
    data: Any = None
    message: str | None = None

app = FastAPI()
users = list()

@app.get("/users")
def all_users():
    return users

@app.get("/users/{id}", response_model=ApiResp)
def get_user(id:int):
    user = [u for u in users if u.id == id]
    if len(user) > 0:
        return ApiResp(status="success", data=user)
    else:
        return ApiResp(status="failed", message="User not found")

@app.post("/users")
def add_user(u:User):
    users.append(u)
    return {
        "status": "success",
        "data": "user is saved"
    }
