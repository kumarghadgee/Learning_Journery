package com.backend.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.function.EntityResponse;

import com.backend.service.CompanyService;

import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
@RequestMapping("/company")
public class CompanyController {
	
	private final CompanyService companyService;
	
	@GetMapping("/list")
	public ResponseEntity<?> getAllCompanyDetails(){
		return ResponseEntity.ok(companyService.getAllCompanyDetails());
	}
	
	@DeleteMapping("/{companyId}")
	public ResponseEntity<?> deleteCompanyDetailsById(@PathVariable Long companyId){
		return ResponseEntity.ok(companyService.deleteCompanyDetailsById(companyId));
	}
}
