package com.ems.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ems.entities.Department;
import com.ems.repository.DepartmentRepository;

@Service //Spring bean - B.L
@Transactional(readOnly=true) //automatic Tx management - import it from o.s.transaction
public class DepartmentServiceImpl implements DepartmentService {
	//dependency 
	@Autowired //SC matches by data type - Field Level D.I
	private DepartmentRepository departmentRepo;

	@Override
	public List<Department> getAllDepartments() {
		// TODO Auto-generated method stub
		return departmentRepo.findAll();
	}

}
