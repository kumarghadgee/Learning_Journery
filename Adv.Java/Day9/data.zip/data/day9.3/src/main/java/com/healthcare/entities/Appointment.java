package com.healthcare.entities;

import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;

import jakarta.persistence.AttributeOverride;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
@Entity
@Table(name="appointments")
//how to customize name of PK - appointment_id ?
@AttributeOverride(name="id",column = @Column(name="appointment_id"))
//Lombok
@NoArgsConstructor
@Getter
@Setter
@ToString(exclude = {"myDoctor","myPatient"},callSuper = true)
public class Appointment extends BaseClass {
	@Column(name="start_time")
	private LocalDateTime startDateTime;
	@Column(name="end_time")
	private LocalDateTime endDateTime;
	@Enumerated(EnumType.STRING)
	private Status status=Status.SCHEDULED;
	//Appointment  *------>1  Doctor
	@ManyToOne
	@JoinColumn(name="doctor_id",nullable = false)
	private Doctor myDoctor;
	//Appointment *---->1  Patient
	@ManyToOne
	@JoinColumn(name="patient_id",nullable = false)
	private Patient myPatient;
	//Appointment *------>* DiagTest
	@ManyToMany //mandatory - otherwise MappingException
	@JoinTable(name="appointments_tests", joinColumns = @JoinColumn(name="appointment_id"),inverseJoinColumns = @JoinColumn(name="test_id")) //optional
	
	private Set<DiagTest> diagTests=new HashSet<>();
	
	public Appointment(LocalDateTime startDateTime, LocalDateTime endDateTime) {
		super();
		this.startDateTime = startDateTime;
		this.endDateTime = endDateTime;
	}
	

}
