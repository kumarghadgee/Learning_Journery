import java.util.Scanner;

class tri
{
    Scanner sc = new Scanner(System.in);

    public void star()
    {
        System.out.print("Please Entre the Number of Rows : ");
        int n = sc.nextInt();

        for(int i = n ; i > 0 ; i--)
        {
            for(int j = i ; j > 0 ; j--)
            {
                System.out.print("* ");
            }

            System.out.println();
        }

        sc.close();
    }
} 

public class star {
    public static void main(String[] args) {
        tri t = new tri();
        t.star();
    }
}
