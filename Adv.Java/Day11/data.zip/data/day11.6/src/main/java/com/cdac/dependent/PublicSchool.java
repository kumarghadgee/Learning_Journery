package com.cdac.dependent;

import com.cdac.dependency.Coach;
import com.cdac.dependency.Teacher;

/*
 * School
 * dependencies
 *  
 *  - Teacher 
 *  - Sports coach
 *  autowire=byName
 */
public class PublicSchool implements School {
	private Teacher subjectTeacher;
	private Coach sportsCoach;
	


	public PublicSchool(Teacher subjectTeacher, Coach sportsCoach) {
		System.out.println("in ctor "+getClass());
		this.subjectTeacher = subjectTeacher;
		this.sportsCoach = sportsCoach;
	}

	// B.L method
	@Override
	public void manageAcademics() {
		System.out.println("Managing academics here -");
		subjectTeacher.teach();
	}

	@Override
	public void organizeSportsEvent() {
		System.out.println("Organizing Sports Event - ");
		System.out.println(sportsCoach.getDailyWorkout());
	}

	

	public void myInit() {
		System.out.println("in init");
	}

	public void myDestroy() {
		System.out.println("in destroy");
	}	

}
