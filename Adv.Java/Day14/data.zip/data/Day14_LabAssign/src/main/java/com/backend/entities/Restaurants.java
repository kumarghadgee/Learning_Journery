package com.backend.entities;

import java.time.LocalDate;
import java.time.LocalDateTime;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;


@NoArgsConstructor
@Getter
@Setter
@ToString
@Entity 
public class Restaurants {
//created_on, last_updated, address, city, description, name,status
	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Long id;
	@CreationTimestamp
	@Column(name = "created_on")
	private LocalDate createdOn;
	@Column(name = "last_updated")
	@UpdateTimestamp
	private LocalDateTime lastUpdated;
	private String address;
	private String city;
	private String description;
	private String name;
	private boolean status;
	public Restaurants(String address, String city, String description, String name, boolean status) {
		super();
		this.address = address;
		this.city = city;
		this.description = description;
		this.name = name;
		this.status = status;
	}
}
