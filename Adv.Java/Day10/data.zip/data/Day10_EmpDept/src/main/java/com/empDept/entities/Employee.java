package com.empDept.entities;

import jakarta.persistence.AttributeOverride;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@NoArgsConstructor
@Getter
@Setter
@ToString
@Entity
@Table(name="employee")
@AttributeOverride(name="id",column=@Column(name="emp_id"))
public class Employee extends BaseClass{
	@Column(name = "first_name" , length = 25)
	private String firstName;
	@Column(name = "last_name" , length = 30)
	private String lastName;
	@Column(length = 50 , unique = true)
	private String email;
	private Double salary;
	
	@ManyToOne
	@JoinColumn(name = "dept_id")
	private Department department;
}	
