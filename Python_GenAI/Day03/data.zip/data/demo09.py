import pandas as pd
import pandasql as ps
import streamlit as st

st.title("Products SQL Explorer")

file_path="products.csv"
df = pd.read_csv(file_path)

try:
    sql = st.chat_input("Enter SQL query for 'products' table")
    if sql:
        result_df = ps.sqldf(sql, {"products": df})
        st.dataframe(result_df)
except Exception as e:
    st.markdown(f"**{str(e)}**")
