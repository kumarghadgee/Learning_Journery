1. Inventory MS (Spring boot app)
 - DB 
  inventory_db
 - Table
  - inventory
Layers
 - Controller , Service , Repository , Entities ,
  - DTOs , custom_exceptions , GlobalExceptionHandler
- application.properties
 spring.application.name - inventory-service (Unique service ID)

2.  Order MS
 - DB 
  order_db
 - Table
  - orders
Layers
 - Controller , Service , Repository , Entities ,
  - DTOs , custom_exceptions , GlobalExceptionHandler
- application.properties
 spring.application.name - order-service (Unique service ID)

