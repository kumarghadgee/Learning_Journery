package com.product.utilis;

import java.sql.*;

public class DButilis {

		private final static String dbURL = "jdbc:mysql://localhost:3306/product_catalog";
		private final static String userName = "root";
		private final static String password = "ghadgedeveloper";
		
		//add static method to return DB connection to the caller
		public static Connection getConnection() throws SQLException
		{
			return DriverManager.getConnection(dbURL, userName, password);
		}

}
