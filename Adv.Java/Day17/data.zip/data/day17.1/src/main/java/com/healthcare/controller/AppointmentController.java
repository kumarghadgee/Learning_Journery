package com.healthcare.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.healthcare.dtos.AppointmentResp;
import com.healthcare.dtos.BookAppointment;
import com.healthcare.dtos.CompleteAppointment;
import com.healthcare.service.AppointmentService;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/appointments")
@RequiredArgsConstructor
public class AppointmentController {
	//depcy
	private final AppointmentService appointmentService;
	/* Desc - Get specific patient's upcoming appointments
	 * URI - /appointments/patients/{patientId}/upcoming
	 * Method - GET
	 * Input - patient id : path var
	 * Succesful Resp - SC 200 + List<dto>
	 * No appointments - SC 204 , no body
	 *  - ROLE_PATIENT
	 */
	//Method level authorization rule - only Patient can access this end point
	@PreAuthorize("hasRole('PATIENT')")
	@GetMapping("/patients/{patientId}/upcoming")
	public ResponseEntity<?> getPatientsScheculedAppointments(@PathVariable Long patientId )
	{
		System.out.println("in patient upcoming apps "+patientId);
		List<AppointmentResp> list = appointmentService.getPatientsScheduledAppointments(patientId);
		if(list.isEmpty())
			 return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
		return ResponseEntity.ok(list);
	}
	/*
	 * URI - /appointments
	 * Method - POST
	 * Input - patient id ,doc id , start datetime - requestbody - DTO
	 * Succesful Resp - SC 201 + Apiresp 
	 * Failed - invalid patient | doc - SC 404
	 *  , appointment full - SC 409 
	 */
	@PostMapping
	public ResponseEntity<?> bookPatientAppointment(@RequestBody @Valid BookAppointment dto)
	{
		System.out.println("in book app "+dto);
		return ResponseEntity.status(HttpStatus.CREATED)
				.body(appointmentService.bookNewAppointment(dto));
	}
	/*
	 * Desc - Doctor wants to mark appointment as complete (from doctor's dashboard)
	 * i/p - request body - doctorId , appointmentId , diag test ids 
	 * URI - /appointments/complete 
	 * Method - PATCH
	 * Error Response - SC 400 
	 * Success Response - SC 200 + Apiresp - success mesg
	 * 
	 */
	@PatchMapping("/complete")
	public ResponseEntity<?> completeAppointmentByDoctor(@RequestBody CompleteAppointment completeRequest) {
		return ResponseEntity.ok(appointmentService.completeAppointmentByDoctor(completeRequest));
	}
	
	/*
	 * Desc - Get all appointment details (Admin only)
	 * URI -  /appointments
	 * 
	 * 
	 * Success Response - SC 200 + List of complete appointment details
	 * 
	 */
	@GetMapping	
	public ResponseEntity<?> getAllAppointments() {
		return ResponseEntity.ok(appointmentService.getAllAppointments());
	}

	


}
