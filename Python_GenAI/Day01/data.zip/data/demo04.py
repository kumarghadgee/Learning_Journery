# input/output and operators
#   input() fn returns string
#   if you need other type, do casting using int() or float()

# input string and print it back
name = input("Enter your name: ")
print(f"Hello, {name}")

# input two ints, divide it and print result
num1 = int(input("Enter number1: "))
num2 = int(input("Enter number2: "))
result = num1 / num2
print(f"{num1} div {num2} = {result}") # 3.142857142857143
result = num1 // num2
print(f"{num1} floor div {num2} = {result}") # 3

# input age and check if user can vote
age = int(input("Enter age: "))
print(f"Age: {age}, Can vote: {age >= 18}")

answer = input("SIR is done (yes/no)? ")
print(f"Age: {age}\nSIR: {answer}\nCan vote: {age >= 18 and answer == 'yes'}")

