package com.healthcare.service;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.healthcare.custom_exceptions.ResourceNotFoundException;
import com.healthcare.dtos.PatientResp;
import com.healthcare.entities.Patient;
import com.healthcare.repository.PatientRepository;

import lombok.RequiredArgsConstructor;
@Service
@Transactional(readOnly = true)
@RequiredArgsConstructor
public class PatientServiceImpl implements PatientService {
	//depcy - repo
	private final PatientRepository patientRepository;
	private final ModelMapper mapper;

	@Override
	public PatientResp getPatientDetails(Long patientId) {
		// 1. Get patient details by id
		Patient entity=patientRepository.findById(patientId) //Optional
				.orElseThrow(() -> new ResourceNotFoundException("Invalid patient id !!!"));
		//2. map entity -> dto
		return mapper.map(entity, PatientResp.class);
				
	}

}
