package com.healthcare.value_types;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;

@Embeddable //mandatory
public class AdhaarCard {
	@Column(name = "card_number", unique = true)
	private String cardNumber;
	@Column(name = "creation_date_time")
	private LocalDateTime creationDateTime;
	private String location;
}
