package myPractice;

import java.util.Scanner;

class pattern9
{
	public void star()
	{
		char a = 'a';
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter the number : ");
		int k = sc.nextInt();
		for(int i = 1 ; i <= k ; i++) {
			for(int j = 1 ; j <= i ; j++) {
				System.out.print(a + " ");
				a++;
			}
			System.out.println();
		}
		
		sc.close();
	}
}

public class demo10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		pattern9 pt = new pattern9();
		pt.star();
	}

}
