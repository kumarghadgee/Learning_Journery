
# list of dictionary
conversation = [
    {
        "role": "user",
        "content": "What is capital of France?"
    },
    {
        "role": "ai",
        "content": "Paris"
    },
    {
        "role": "user",
        "content": "What is famous there?"
    },
    {
        "role": "ai",
        "content": "Eifel Tower"
    }
]

# each msg is a dictionary
for msg in conversation:
    print(msg["role"], ":", msg["content"])
