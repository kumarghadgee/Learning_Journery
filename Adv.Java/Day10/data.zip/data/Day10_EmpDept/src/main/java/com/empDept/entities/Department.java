package com.empDept.entities;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.AttributeOverride;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@NoArgsConstructor
@Getter
@Setter
@ToString
@Entity
@Table(name="department")
@AttributeOverride(name="id",column=@Column(name="dept_id"))
public class Department extends BaseClass{
	@Column(name = "dept_name",unique = true)
	private String name;
	@Column(name = "location",length = 200)
	private String location;
	
	@OneToMany(mappedBy="department")
	private List<Employee> emps = new ArrayList<>();

	public Department(String name, String location) {
		super();
		this.name = name;
		this.location = location;
	}
	
	
}
