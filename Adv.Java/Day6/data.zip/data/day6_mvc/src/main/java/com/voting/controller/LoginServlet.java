package com.voting.controller;

import java.io.IOException;
import java.io.PrintWriter;

import com.voting.dao.UserDao;
import com.voting.dao.UserDaoImpl;
import com.voting.entities.User;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.Servlet;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

/**
 * Servlet implementation class LoginServlet WC creates a URL Map Key - /auth
 * Value - com.voting.pages.LoginServlet
 */
@WebServlet(value = "/auth", loadOnStartup = 1)
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	// dependency - dao layer interface
	private UserDao userDao;

	/**
	 * @see Servlet#init()
	 */
	public void init() throws ServletException {
		try {
			// create dao instance
			userDao = new UserDaoImpl();
		} catch (Exception e) {
		//throw ServletException(String mesg,Throwable rootCause) -> to WC
			throw new ServletException("err in init of "+getClass(),e);
		}
	}

	/**
	 * @see Servlet#destroy()
	 */
	public void destroy() {
		try {
		// dao's cleanup
		userDao.cleanUp();
		} catch (Exception e) {
			System.out.println("err in destroy "+e);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		System.out.println("in do-post "+getClass());
		try {
			//1. Read email & password sent form client
			String email=request.getParameter("em");
			String password=request.getParameter("pass");
		// 4. Call dao's authenticate - for user authentication
			User user = userDao.authenticateUser(email, password);
			//5 . In case of success - render user details otherwise render retry link with err mesg
			if(user == null) {
				//login failed -> forward to login.jsp , with error message
				String queryString="?message=Invalid Email or password";
				RequestDispatcher rd=request.getRequestDispatcher("/WEB-INF/views/login.jsp"+queryString);
				rd.forward(request, response);
			} else {
				//successful login
				//6. Get Session from WC
				HttpSession session=request.getSession();
				//7. Save user details - under Session scope(multiple reqs from the same clnt)
				session.setAttribute("user_details", user);
				//role based navigation
				if(user.getRole().equals("admin")) {
					//admin logged in
					response.sendRedirect("admin_dashboard");
				} else if (user.isStatus()) {
					//voter has already voted 
					response.sendRedirect("logout");
				} else {
					//voter - not yet voted -> redirect to  VoterDashboardServlet - via
					//FrontController
					response.sendRedirect("voter");
				}
			}
				
		}  catch (Exception e) {
			//inform WC - servicing has failed - for this request
			throw new ServletException("err in do-post of"+getClass(), e);
		}
	}

//	@Override
//	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
//		doPost(req, resp);
//	}

}
