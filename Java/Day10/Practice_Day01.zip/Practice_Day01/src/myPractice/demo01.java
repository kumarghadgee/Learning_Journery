package myPractice;

import java.util.Scanner;

class swap
{
	private int a;
	private int b;
	
	public swap() {
		super();
	}

	public swap(int a, int b) {
		super();
		this.a = a;
		this.b = b;
	}
	
	public void swapping() 
	{
		a = a + b;
		b = a - b;
		a = a - b;
		
		System.out.println("___________________AFTER SWAPPING_____________________");
		System.out.println("Value of a : "+ a);
		System.out.println("Value of b : "+ b);
	}

	public int getA() {
		return a;
	}

	public void setA(int a) {
		this.a = a;
	}

	public int getB() {
		return b;
	}

	public void setB(int b) {
		this.b = b;
	}
}

public class demo01 {

	public static void main(String[] args) {
		swap s = new swap();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Value of a: ");
		s.setA(sc.nextInt());
		System.out.println("Enter the Value of b: ");
		s.setB(sc.nextInt());
		s.swapping();
	}

}
