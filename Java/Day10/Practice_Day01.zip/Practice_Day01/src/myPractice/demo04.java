package myPractice;

import java.util.Scanner;

class pattern3
{
	public void star3()
	{
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter the Number you want the Rectangle : ");
		int k = sc.nextInt();
		for(int i = 1;i <= k; i++) {
			for(int j = 1 ; j <= k ; j++) {
			System.out.print("* ");
			}
			System.out.println();
		}
		
		sc.close();
	}
}

public class demo04 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		pattern3 pt3 = new pattern3();
		pt3.star3();
	}

}
