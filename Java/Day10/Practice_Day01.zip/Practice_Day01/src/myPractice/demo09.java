package myPractice;

import java.util.Scanner;

class pattern8
{
	public void star()
	{
		int l = 1;
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter the numbers you want : ");
		int k = sc.nextInt();
		for(int i = 1 ; i <= k ; i++) {
			for(int j = 1 ; j <= i ; j++) {
				System.out.print(l + " ");
				l++;
			}
			System.out.println();
		}
		
		sc.close();
	}
			
}

public class demo09 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		pattern8 pt = new pattern8();
		pt.star();
	}

}
