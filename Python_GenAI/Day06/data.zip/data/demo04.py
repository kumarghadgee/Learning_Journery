# Question --> Chroma --> Retrieval of related docs/pages

from langchain.embeddings import init_embeddings
import chromadb
import json

embed_model = init_embeddings(model="ollama:nomic-embed-text")

question = input("Your question: ")
question_embedding = embed_model.embed_query(question)

try:
    DB_DIR_PATH="my_chroma_db"
    db = chromadb.PersistentClient(DB_DIR_PATH)

    COLLECTION="science-book-ix"
    collection = db.get_or_create_collection(COLLECTION)

    results = collection.query(question_embedding, n_results=3)
    print(json.dumps(results, indent=2))
except Exception as e:
    print("ERROR:", e)
