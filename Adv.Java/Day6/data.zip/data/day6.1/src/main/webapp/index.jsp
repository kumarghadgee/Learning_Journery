<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Home Page</title>
</head>
<body>
	<h5>
		<a href="login.jsp">Testing Scripting Elements</a>
	</h5>
	<h5>
		<a href="test1.jsp">Testing Scopes</a>
	</h5>
	<h5>
		<a href="test3.jsp">Testing JSP Declaration</a>
	</h5>
	<h5>
		<a href="test4.jsp?pid=123&name=pen&price=50">URL Rewriting</a>
	</h5>
	<h5>
		<a href="test6.jsp">Error Handling in JSP</a>
	</h5>
	<h5>
		<a href="test7.jsp">JSP include directive</a>
	</h5>
	<h5>
		<a href="test9.jsp?pid=123&name=pen&price=50">JSP Actions forward and include</a>
	</h5>
</body>
</html>