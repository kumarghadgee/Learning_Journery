<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<%@ taglib uri="jakarta.tags.core" prefix="c"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
	<c:set var="user" value="${requestScope.user_dtls}" />
	<h5>Hello , ${user.firstName} ${user.lastName}</h5>
	<c:if test="${not empty requestScope.message}">
		<h5>${requestScope.message}</h5>
	</c:if>
	<c:if test="${empty requestScope.message}">
		<h5>${requestScope.voting_sts}</h5>
		<h5>${requestScope.incr_sts}</h5>
	</c:if>
	<h6>You have logged out here....</h6>
</body>
</html>