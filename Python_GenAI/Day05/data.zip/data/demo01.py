from langchain.chat_models import init_chat_model
from langchain.agents import create_agent
from dotenv import load_dotenv

load_dotenv()

SYSTEM_PROMPT="""
    You are a helpful assistant.
"""
llm = init_chat_model("groq:llama-3.3-70b-versatile")
agent = create_agent(model=llm, tools=[], system_prompt=SYSTEM_PROMPT)

# stateless chatbot
# while True:
#     user_prompt = input("\nAsk anything: ")
#     if user_prompt == "exit":
#         break
#     result = agent.invoke({
#         "messages": [
#             {"role": "user", "content": user_prompt}
#         ]
#     })
#     ai_msg = result["messages"][-1]
#     print("Answer:", ai_msg.content)

# stateful chatbot - conversation history is updated from agent's result (line 36)
conversation = []
while True:
    user_prompt = input("\nAsk anything: ")
    if user_prompt == "exit":
        break
    conversation.append({"role": "user", "content": user_prompt})
    result = agent.invoke({
        "messages": conversation
    })
    conversation = result["messages"]
    ai_msg = conversation[-1]
    print("Answer:", ai_msg.content)
