package com.ems.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.ems.service.EmployeeService;

import jakarta.servlet.http.HttpSession;

@Controller
@RequestMapping("/employees")
public class EmployeeController {
	//depcy
	@Autowired //by type - Filed Level D.I
	private EmployeeService empService;
	
	public EmployeeController() {
		System.out.println("in ctor "+getClass());
	}
	/*
	 * URL - http://localhost:8080/ems/employees/list
	 * Method - POST
	Payload 
      - deptId - 2
    Response 
    - render list of available emps from specified department by dept id
    
      
    - @RequestParam
    - annotation at method argument level
    - Used to bind incoming request parameter to method argument(in GET | POST)
    - @RequestParam Long deptId 
    - SC - Long deptId = Long.parseLong(request.getParameter("dept_id")
	 */
	@RequestMapping("/list")
	public String renderEmpList(Model map,@RequestParam Long deptId,HttpSession session) {
		System.out.println("in render emp list "+map);
		session.setAttribute("dept_id",deptId);
		map.addAttribute("emp_list",empService.getAvailableEmpsByDeptId(deptId));
		return "emps/list";
	}
	
	@GetMapping("/delete")
	public String softDeleteById(Model map,@RequestParam Long empId,HttpSession session) {
		System.out.println("in softDelete empById :"+map);
		map.addAttribute(empService.deleteEmpDetailsById(empId));
		/*
		 *  Instead of directly forwarding the client to view layer
		 *  -> redirect client in the next request to the view
		 *  Replace Forward by redirect
		 */
		return "redirect:/employees/list?deptId="+session.getAttribute("dept_id");
		
	}
	/*
	 * D.S
	 * response.sendRedirect(response.encodeRedirectURL("employees/list")
	 * -> temp redirect response
	 * -> SC 302 , Location : employees/list , Body - empty
	 * -> web browser -> http://host:port/ems/employees/list,
	 * Method-GET
	 */
}
