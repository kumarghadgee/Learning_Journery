package com.backend.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.backend.dtos.JobDTO;
import com.backend.entities.JobType;
import com.backend.service.JobService;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/job")
@RequiredArgsConstructor
public class JobController {
	
	private final JobService jobService;
	
	@PostMapping("/add")
	public ResponseEntity<?> addNewJobOpening(@RequestBody JobDTO jobDto){
		return ResponseEntity.ok(jobService.addNewJobOpening(jobDto));
	}
	
	@GetMapping("/{location}")
	public ResponseEntity<?> getListOfJobByLocation(@PathVariable String location){
		return ResponseEntity.ok(jobService.getListOfJobByLocation(location));
	}
	
	@DeleteMapping("/{jobType}/{name}")
	public ResponseEntity<?> deleteAllJobOfSpecifiedTypeAndCompany(@PathVariable JobType jobType,@PathVariable String name){
		int deletedCount = jobService.deleteAllJobOfSpecifiedTypeAndCompany(jobType, name);
		return ResponseEntity.ok(jobService.deleteAllJobOfSpecifiedTypeAndCompany(jobType,name));
	}
}
