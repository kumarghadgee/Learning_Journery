package com.backend.dtos;

import com.backend.entities.Industry;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class CompanyDTO {
	private String name;
	private String email;
	private String location;
	private Industry industry;
}
