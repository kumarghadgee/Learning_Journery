import java.util.Scanner;

class palindrome
{
    Scanner sc = new Scanner(System.in);
    public void palin()
    {
        System.out.print("Enter the number to check whether it is Palindrome or not :");
        int n = sc.nextInt();
        int sum = 0;
        int a = n;

        while(n > 0)
        {
            int m = n % 10;
            sum = (sum *10) + m;
            n /= 10;
        }

            if(sum == a)
            {
                System.out.println("Your given number is palindrome....");
            }
            else
            {
                System.out.println("Your given number is not palindrome....");
            }
        sc.close();
    }
}

public class demo03 {
    public static void main(String[] args) {
        palindrome pl = new palindrome();
        pl.palin();
    }
}
