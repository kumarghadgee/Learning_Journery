package com.healthcare.repository;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.healthcare.dtos.AppointmentResp;
import com.healthcare.dtos.CompleteAppointmentDetails;
import com.healthcare.entities.Appointment;
import com.healthcare.entities.Status;

public interface AppointmentRepository extends JpaRepository<Appointment, Long> {
//custom query method - List<DTO> 
	/*
	 * private Long id; //appointments
	//for patient dashboard - doc's name
	//for doc's dashboard - patient's name
	private String firstName;
	private String lastName;
	private LocalDateTime appointmentDateTime;
	 */
	@Query("""			
			select new com.healthcare.dtos.AppointmentResp
			(a.id,a.myDoctor.userDetails.firstName,a.myDoctor.userDetails.lastName,
			a.startDateTime) 
			from Appointment a 
			where a.myPatient.id=:pid and a.status=:sts			
			"""
			)
	List<AppointmentResp> getPatientUpcomingAppointments(@Param("pid")Long patientId,@Param("sts") Status sts);
	/*
	 * String jpql = """
				select a.id from Appointment a
				where a.myDoctor.id=:docId
				and
				a.status=:sts
				and
				a.startDateTime < :end
				and
				a.endDateTime > :start
				""";
	 */
	//to check doctor's availability
	boolean existsByMyDoctorIdAndStatusAndStartDateTimeLessThanAndEndDateTimeGreaterThan(Long docId,Status sts,LocalDateTime newEnd,LocalDateTime newStart);
	//to check patient's availability
		boolean existsByMyPatientIdAndStatusAndStartDateTimeLessThanAndEndDateTimeGreaterThan(Long patientId,Status sts,LocalDateTime newEnd,LocalDateTime newStart);
		/*
		 * Custom query to get complete appointment details
		 */
		@Query("""		
			select new com.healthcare.dtos.CompleteAppointmentDetails
			(a.id,a.startDateTime,a.endDateTime,a.status,d.firstName,d.lastName,p.firstName,p.lastName) 
			from Appointment a join a.myPatient.userDetails p
			join a.myDoctor.userDetails d
				""")
		List<CompleteAppointmentDetails> getAllAppointments();
}
