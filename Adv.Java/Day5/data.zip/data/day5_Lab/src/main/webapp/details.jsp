<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Details Page</title>
</head>
<body>
	<h1>This is Details Page</h1>
	<h3>
	Welcome, ${sessionScope.users.name} <br/>
    Email: ${sessionScope.users.email}  <br/>
    Date Of Birth: ${sessionScope.users.dob}
    </h3>
    
    <h4><a href='logout.jsp'>Log me Out</a></h4>
</body>
</html>