# Langchain ChatBot

import os
from langchain.chat_models import init_chat_model
from langchain.messages import HumanMessage, AIMessage, SystemMessage
from dotenv import load_dotenv

load_dotenv()
MODEL="groq:llama-3.1-8b-instant" # "ollama:llama3.2"
API_KEY=os.getenv("GROQ_API_KEY") # "not-required"
llm = init_chat_model(model=MODEL, api_key=API_KEY)

conversation = [
    # role="system", content="system_prompt"
    SystemMessage(content="You are helpful assistant. Talk to the point.")
]
while True:
    user_prompt = input("Ask anything: ")
    if user_prompt == "exit":
        break
    conversation.append(HumanMessage(content=user_prompt))
    response = llm.invoke(input=conversation)
    print("Answer:", response.content)
    conversation.append(response)
