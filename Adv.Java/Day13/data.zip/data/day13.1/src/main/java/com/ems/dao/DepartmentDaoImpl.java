package com.ems.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ems.entities.Department;

import jakarta.persistence.EntityManager;

@Repository // declares spring bean with DAO layer
public class DepartmentDaoImpl implements DepartmentDao {
	//dependency - EntityManager (super i/f of Session)
	@Autowired //SC tries to match by data type - 
	private EntityManager manager;

	@Override
	public List<Department> getAllDepartments() {
		// TODO Auto-generated method stub
		return manager
				.createQuery("select d from Department d", Department.class)
				.getResultList();
	}

}
