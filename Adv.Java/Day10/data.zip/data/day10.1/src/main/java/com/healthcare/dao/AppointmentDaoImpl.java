package com.healthcare.dao;

import com.healthcare.entities.Status;
import java.time.LocalDateTime;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.healthcare.custom_exceptions.AppointmentException;
import com.healthcare.custom_exceptions.ResourceNotFoundException;
import com.healthcare.entities.Appointment;
import com.healthcare.entities.Doctor;
import com.healthcare.entities.Patient;
import com.healthcare.utils.HibernateUtils;

public class AppointmentDaoImpl implements AppointmentDao {

	@Override
	public String bookAppointment(Long patientId, Long doctorId, LocalDateTime appointmentStart) {
		String mesg = "Failed";
		// 1. Get Session from SessionFactory
		Session session = HibernateUtils.getSessionFactory().getCurrentSession();
		// 2. Begin a Transaction
		Transaction tx = session.beginTransaction();
		try {
			// 3. Get doctor details by its id
			Doctor doctor = session.find(Doctor.class, doctorId);
			if (doctor == null)
				throw new ResourceNotFoundException("Invalid Doctor ID!!!!");
			// 4. Get Patient details by its id
			Patient patient = session.find(Patient.class, patientId);
			if (patient == null)
				throw new ResourceNotFoundException("Invalid Patient ID!!!!");
			// doctor : persistent, patient - persistent
			LocalDateTime appointmentEnd = appointmentStart.plusMinutes(doctor.getAppointmentTime());
			// 5. check doc's availability
			if (!isDocAvailable(doctorId, appointmentStart, appointmentEnd))
				throw new AppointmentException("Doctor is un available !!!");
			// 6. check patient's availability
			if (!isPatientAvailable(patientId, appointmentStart, appointmentEnd))
				throw new AppointmentException("Patient is un available !!!");
			
			//=> validations successful -> create appointment 
			//7. Create Appointment instance
			Appointment appointment=new Appointment(appointmentStart, appointmentEnd);
			//8 Establish  Appointment *<--->1 Doctor
			appointment.setMyDoctor(doctor);
			doctor.getAppointments().add(appointment);
			//9 Establish  Appointment *--->1 Patient
			appointment.setMyPatient(patient);
			//10. transient -> persistent : persist
			session.persist(appointment);
			tx.commit();
			mesg = "Appointment booked with ID ";
		} catch (RuntimeException e) {
			if (tx != null) {
				tx.rollback();
			}
			// re throw the same exception to the caller
			throw e;
		}
		return mesg;
	}

	private boolean isPatientAvailable(Long patientId, LocalDateTime appointmentStart, LocalDateTime appointmentEnd) {
		// TODO - lab work
		return true;
	}

	private boolean isDocAvailable(Long doctorId, LocalDateTime appointmentStart, LocalDateTime appointmentEnd) {
		/*
		 * Checking if there exists scheduled appointment with specified doctor -
		 * overlapping with new appointment
		 */
		String jpql = """
				select a.id from Appointment a
				where a.myDoctor.id=:docId
				and
				a.status=:sts
				and
				a.startDateTime < :end
				and
				a.endDateTime > :start
				""";
		// 1. Get Session from SessionFactory
		Session session = HibernateUtils.getSessionFactory().getCurrentSession();
		// 2. Begin a Transaction
		Transaction tx = session.beginTransaction();
		List<Long> ids = session.createQuery(jpql, Long.class).setParameter("docId", doctorId)
				.setParameter("sts", Status.SCHEDULED).setParameter("end", appointmentEnd)
				.setParameter("start", appointmentStart).getResultList();
	//	tx.commit();
		return ids.size() == 0;
	}

}
