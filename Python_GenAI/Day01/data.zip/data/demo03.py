
# python string literals
company = "OpenAI"  # double quotes
model = 'GPT-5.0'   # single quotes
# multi-line strings in triple-double quotes
user_prompt = """
    You are helpful assistant.
    Tell me what is happing in 'Capital of India'?
"""
# multi-line strings in triple-single quotes
ai_prompt = '''
    No comments.
    I still want to do business in "India".
'''
# formatted string
description = f"{company} model is {model}"
print(description)
