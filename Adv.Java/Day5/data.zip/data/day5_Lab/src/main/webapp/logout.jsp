<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>LogOut Page</title>
</head>
<body>
	<h1>This is the Logout Page</h1>
	<h3>
	Hello, ${sessionScope.users.name} <br/>
	Age: ${sessionScope.users.age}
	</h3>
</body>
<%
	if(request.getSession(false)!=null){
		session.invalidate();
	}
%>
<h3>Logging Out......</h3>
<h4><a href='index.jsp'>Visit Again</a></h4>
</html>