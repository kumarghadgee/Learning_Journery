Inter MS communication
- synchronus communication
- RestTemplate
- Spring Cloud framework
 - ServiceRegistry

