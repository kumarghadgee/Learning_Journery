package com.healthcare.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.MapsId;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "patients")
//@AttributeOverride(name="id",column = @Column(name="patient_id"))
//Lombok
@NoArgsConstructor
@Getter
@Setter
@ToString(exclude ="userDetails" ,callSuper = true)
public class Patient extends BaseClass {
	@Enumerated(EnumType.STRING)
	private Gender gender;
	@Enumerated(EnumType.STRING)
	@Column(name = "blood_group")
	private BloodGroup bloodGroup;
	@Column(name = "family_history")
	private String familyHistory;
	//Patient 1----->1 User
	@OneToOne
	@JoinColumn(name="patient_id")
	@MapsId
	private User userDetails;
	public Patient(Gender gender, BloodGroup bloodGroup, String familyHistory) {
		super();
		this.gender = gender;
		this.bloodGroup = bloodGroup;
		this.familyHistory = familyHistory;
	}
	
}
