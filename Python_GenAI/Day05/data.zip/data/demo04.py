import json
import os
import requests
from ollama import Client
from crewai import Agent, Task, Crew, Process, LLM
from crewai.tools import tool


llm = LLM(
    model="ollama/llama3.2",
    base_url="http://localhost:11434",
    temperature=0
)

@tool
def get_current_weather(city: str) -> str:
    """
    Get the current weather for a specified city.

    Use this tool whenever the user asks about weather,
    temperature, humidity, rainfall, wind etc.

    Returns JSON.
    """
    try:
        api_key = os.getenv("OPENWEATHER_API_KEY")

        url = (
            "https://api.openweathermap.org/data/2.5/weather"
            f"?appid={api_key}&units=metric&q={city}"
        )

        response = requests.get(url)
        response.raise_for_status()

        return response.text

    except Exception as e:
        return json.dumps({"ERROR": str(e)})


@tool
def web_search(query: str) -> str:
    """
    Search the live web.

    Use this tool whenever the answer requires
    current information or general knowledge.

    Returns JSON.
    """
    try:
        client = Client()

        response = client.web_search(
            query,
            max_results=2
        )

        results = []

        for result in response.results:
            results.append(
                {
                    "title": result.title,
                    "url": result.url,
                    "content": result.content
                }
            )

        return json.dumps(results, indent=2)

    except Exception as e:
        return json.dumps({"ERROR": str(e)})


# Retriever Agent
retriever_agent = Agent(
    role="Information Retriever",
    goal="""
        Retrieve information using the provided tools only.
    """,
    backstory="""
        You specialize in finding information.
        Never fabricate information.
        Never answer the user directly.
    """,
    llm=llm,
    tools=[
        web_search,
        get_current_weather
    ],
    verbose=True,
    allow_delegation=False
)

# Answer Generator
answerer_agent = Agent(
    role="Answer Generator",
    goal="""
        Produce a clear answer ONLY from the provided evidence.

        Never invent facts.
    """,
    backstory="""
        You are an expert analyst.

        You can carefully analyze the evidence to find the answer of the question. 
    """,
    llm=llm,
    verbose=True,
    allow_delegation=False
)

# Tasks
retriever_task = Task(
    description="""
        User Question:
        {question}

        Determine which tool should be used.

        Rules:
        - Only Current/Live Weather question -> get_current_weather()
        - All other questions -> web_search()

        Call the appropriate tool.

        Return ONLY the raw JSON returned by the tool.
        """,
    expected_output="""
        Raw JSON returned by the selected tool.
        """,
    agent=retriever_agent
)


answer_task = Task(
    description="""
        Original Question:
        {question}

        Produce a complete answer,
        using ONLY the provided evidence.
        If evidence doesn't contain the answer,
        report the error accordingly.

        Do not use your own knowledge.
        """,
    expected_output="""
        A complete answer based only on the provided evidence.
        """,
    agent=answerer_agent,
    context=[retriever_task]
)


# Crew
crew = Crew(
    agents=[
        retriever_agent,
        answerer_agent
    ],
    tasks=[
        retriever_task,
        answer_task
    ],
    process=Process.sequential,
    verbose=True
)


# Chat Loop
if __name__ == "__main__":

    while True:
        question = input("Ask Anything: ")
        if question.lower() == "exit":
            break

        result = crew.kickoff(
            inputs={
                "question": question
            }
        )

        print("\nFINAL ANSWER\n")
        print(result)
        print("=" * 80)
