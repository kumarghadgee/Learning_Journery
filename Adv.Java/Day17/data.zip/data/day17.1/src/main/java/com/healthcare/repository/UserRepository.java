package com.healthcare.repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.healthcare.dtos.UserDTO;
import com.healthcare.entities.User;
import com.healthcare.entities.UserRole;


public interface UserRepository extends JpaRepository<User,Long> {
//derived finder for user auth
	Optional<User>  findByEmailAndPassword(String email, String password);
	/*
	 * Get All Users from specified role , with reg amount <= specified amount
	 */
	List<User> findByUserRoleAndRegAmountIsLessThanEqual(UserRole role, int amount);

	/*
	 * Return count of users born after specified date
	 */
	int countByDobAfter(LocalDate date);

	/*
	 * Delete all users from specified role
	 */
	int deleteByUserRole(UserRole role);

	/*
	 * Get firstname , last name , dob of users from specified role , born
	 * between specified start & end date
	 */
	@Query("select new com.healthcare.dtos.UserDTO(u.firstName,u.lastName,u.dob)  from User u where u.userRole=:rl and u.dob between :start and :end")
	List<UserDTO> getSelectedUserDetails(@Param("rl") UserRole role, @Param("start") LocalDate strt,
			@Param("end") LocalDate end1);

	
	 //check if user already exists by same email or phone
	 
	boolean existsByEmailOrPhone(String email,String phoneNo);
	
	boolean existsByEmail(String email);

	
}

